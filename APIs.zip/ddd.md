# LiveMenu - Diseño DDD y Microservicios

## Subdominios
- **Core Menu (Dominio principal):** Gestión de restaurantes, categorías y platos, orden visual, disponibilidad y slugs públicos.
- **Identidad y Acceso:** Usuarios propietarios, autenticación, refresh tokens y control de permisos públicos (rol anon).
- **Medios (Media):** Gestión de imágenes procesadas (logos y platos) y sus variantes de tamaño.
- **Analytics:** Captura de eventos de escaneo del menú y agregados de métricas.

## Bounded Contexts y Microservicios
- **Identity BC / Auth Service:** Usuarios, login, refresh/revoke tokens, rol anon para lectura pública.
- **Menu BC / Menu Service:** Restaurantes, categorías, platos, vistas públicas del menú por slug.
- **Media BC / Media Service:** Imágenes asociadas a restaurantes y platos; validaciones de tipo y peso.
- **Analytics BC / Analytics Service:** Eventos de escaneo y vistas agregadas (resumen y por hora).

## Context Map (Mermaid)
```mermaid
flowchart LR
  Identity[Identity BC\nAuth Service]
  Menu[Menu BC\nMenu Service]
  Media[Media BC\nMedia Service]
  Analytics[Analytics BC\nAnalytics Service]
  Gateway[API Gateway]

  Identity -- provides usuario_id --> Menu
  Identity -- provides usuario_id --> Media
  Menu -- exposes restaurante_id --> Media
  Menu -- exposes restaurante_id --> Analytics
  Menu -- exposes slug publico --> Gateway
  Analytics -- metrics --> Gateway
```

## Aggregates
- **Usuario (Identity):** Root `usuario` (id, email, password_hash, activo). Invariante: email único; password hasheada.
- **Restaurante (Menu):** Root `restaurante` (id, usuario_id, slug, activo, horarios). Hijos: `categoria` (posicion) y `plato` (posicion, disponible, eliminado_en soft delete). Invariante: slug único; posiciones >= 0; precio_oferta < precio.
- **Imagen (Media):** Root `imagen` (restaurante_id, plato_id?, tipo, urls, mime, tamaño). Invariante: tipo_mime permitido; tamaño <= 5MB; reglas tipo/plato.
- **EventoEscaneo (Analytics):** Root `evento` (restaurante_id, timestamp, ip_hash, user_agent, referrer). Invariante: FK restaurante.
- **TokenRefresh (Identity):** Root `token` (usuario_id, token_hash, expira_en, revocado). Invariante: token_hash único; expira_en futuro.

## Entidades y Objetos de Valor
- **Entidades:** Usuario, Restaurante, Categoria, Plato, Imagen, EventoEscaneo, TokenRefresh.
- **Objetos de Valor:**
  - `Slug` (formato URL seguro, único por restaurante).
  - `Horarios` (JSONB de tramos por día).
  - `PrecioOferta` (precio_oferta < precio regular).
  - `Etiquetas` (colección acotada: vegetariano, vegano, sin_gluten, etc.).
  - `ImagenTamanos` (thumbnail, medium, large URLs coherentes).
  - `IPHash` (anonimización de IP).

## Relaciones entre Contextos
- **Identity → Menu:** Menu confía en usuario_id para propiedad de restaurante (Customer/Supplier).
- **Identity → Media:** Media valida dueño via usuario_id del restaurante.
- **Menu → Media:** Media referencia restaurante/plato; reglas de tipo dependen de Menu.
- **Menu → Analytics:** Eventos referencian restaurante_id; vistas agregadas consumen datos de eventos.

## Decisiones Clave
- Slugs generados automáticamente para URLs públicas.
- Soft delete en platos para preservar histórico.
- Imágenes tipificadas (logo vs imagen_plato) con validaciones de consistencia.
- IP anonimizada en analytics para privacidad.

## Diagrama de Dependencias de Microservicios (Mermaid)
```mermaid
flowchart LR
  Gateway[API Gateway]
  Auth[Auth Service]
  Menu[Menu Service]
  Media[Media Service]
  Analytics[Analytics Service]

  Gateway --> Auth
  Gateway --> Menu
  Gateway --> Media
  Gateway --> Analytics

  Menu --> Auth
  Media --> Auth
  Media --> Menu
  Analytics --> Menu
```

## Eventos y Operaciones
- **Auth:** login, refresh, revoke tokens.
- **Menu:** CRUD restaurantes/categorías/platos; vista pública por slug.
- **Media:** Registrar metadatos de imágenes procesadas (upload fuera de alcance aquí).
- **Analytics:** Registrar eventos y consultar agregados.

## Modelo de Datos alineado
- Tablas: usuarios, restaurantes, categorias, platos, imagenes, eventos_escaneo, tokens_refresh.
- Vistas: v_menu_completo, v_analytics_resumen, v_analytics_por_hora.

## Estrategia de implementación
- Cuatro microservicios ligeros, cada uno con su propio esquema lógico pero compartiendo la misma DB en este prototipo (o separados por schema en una futura fase).
- API Gateway REST en AWS para exponer rutas unificadas y aplicar auth.
