# LiveMenu Menu Service - Node.js + TypeScript

## Arquitectura Hexagonal Implementada

Este microservicio implementa el patrón de **Arquitectura Hexagonal (Ports & Adapters)** con TypeScript y Express.

## Estructura del Proyecto

```
nodejs/
├── src/
│   ├── domain/                    # Capa de Dominio (Core)
│   │   ├── entities/
│   │   │   ├── Restaurante.ts
│   │   │   ├── Categoria.ts
│   │   │   └── Plato.ts
│   │   ├── value-objects/
│   │   │   ├── Slug.ts
│   │   │   └── Precio.ts
│   │   ├── repositories/          # Interfaces (Ports)
│   │   │   ├── IRestauranteRepository.ts
│   │   │   ├── ICategoriaRepository.ts
│   │   │   └── IPlatoRepository.ts
│   │   ├── services/              # Interfaces
│   │   │   ├── ICacheService.ts
│   │   │   └── IStorageService.ts
│   │   └── errors/
│   │       ├── DomainError.ts
│   │       ├── NotFoundError.ts
│   │       └── ValidationError.ts
│   │
│   ├── application/               # Casos de Uso
│   │   ├── use-cases/
│   │   │   ├── restaurante/
│   │   │   │   ├── CreateRestauranteUseCase.ts
│   │   │   │   ├── GetRestauranteUseCase.ts
│   │   │   │   ├── UpdateRestauranteUseCase.ts
│   │   │   │   ├── DeleteRestauranteUseCase.ts
│   │   │   │   └── ListRestaurantesUseCase.ts
│   │   │   ├── categoria/
│   │   │   │   ├── CreateCategoriaUseCase.ts
│   │   │   │   └── ListCategoriasUseCase.ts
│   │   │   ├── plato/
│   │   │   │   ├── CreatePlatoUseCase.ts
│   │   │   │   ├── UpdatePlatoUseCase.ts
│   │   │   │   └── DeletePlatoUseCase.ts
│   │   │   └── menu/
│   │   │       └── GetMenuBySlugUseCase.ts
│   │   └── dtos/
│   │       ├── RestauranteDTO.ts
│   │       ├── CategoriaDTO.ts
│   │       └── PlatoDTO.ts
│   │
│   ├── infrastructure/            # Implementaciones (Adapters)
│   │   ├── persistence/
│   │   │   ├── PostgresRestauranteRepository.ts
│   │   │   ├── PostgresCategoriaRepository.ts
│   │   │   ├── PostgresPlatoRepository.ts
│   │   │   └── PostgresConnection.ts
│   │   ├── cache/
│   │   │   ├── RedisCacheService.ts
│   │   │   └── RedisConnection.ts
│   │   ├── storage/
│   │   │   └── S3StorageService.ts
│   │   └── logging/
│   │       └── WinstonLogger.ts
│   │
│   ├── adapters/                  # HTTP Adapter
│   │   ├── http/
│   │   │   ├── controllers/
│   │   │   │   ├── RestauranteController.ts
│   │   │   │   ├── CategoriaController.ts
│   │   │   │   ├── PlatoController.ts
│   │   │   │   └── MenuController.ts
│   │   │   ├── middleware/
│   │   │   │   ├── authMiddleware.ts
│   │   │   │   ├── validationMiddleware.ts
│   │   │   │   ├── errorHandler.ts
│   │   │   │   └── loggerMiddleware.ts
│   │   │   ├── routes/
│   │   │   │   ├── restauranteRoutes.ts
│   │   │   │   ├── categoriaRoutes.ts
│   │   │   │   ├── platoRoutes.ts
│   │   │   │   └── menuRoutes.ts
│   │   │   └── validators/
│   │   │       ├── restauranteValidators.ts
│   │   │       ├── categoriaValidators.ts
│   │   │       └── platoValidators.ts
│   │   └── express-app.ts
│   │
│   ├── shared/                    # Utilidades compartidas
│   │   ├── config/
│   │   │   └── env.ts
│   │   └── utils/
│   │       ├── slugGenerator.ts
│   │       └── responseFormatter.ts
│   │
│   └── index.ts                   # Entry Point
│
├── tests/
│   ├── unit/
│   │   └── domain/
│   ├── integration/
│   │   └── use-cases/
│   └── e2e/
│       └── api/
│
├── .env.example
├── .eslintrc.json
├── .gitignore
├── Dockerfile
├── package.json
├── tsconfig.json
└── README.md
```

## Instalación

```bash
npm install
```

## Configuración

Crear archivo `.env` basado en `.env.example`:

```bash
# Server
PORT=3000
NODE_ENV=development

# Database
DATABASE_URL=postgresql://livemenu:livemenu_pass@localhost:5432/livemenu

# Redis
REDIS_URL=redis://localhost:6379
REDIS_TTL=3600

# AWS S3
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=your_access_key
AWS_SECRET_ACCESS_KEY=your_secret_key
S3_BUCKET_NAME=livemenu-images

# JWT
JWT_SECRET=your_jwt_secret_key

# Logging
LOG_LEVEL=info
```

## Ejecutar en Desarrollo

```bash
npm run dev
```

El servidor estará disponible en `http://localhost:3000`

## Comandos Disponibles

```bash
npm run dev          # Desarrollo con hot-reload
npm run build        # Compilar TypeScript
npm start            # Ejecutar en producción
npm test             # Tests unitarios
npm run test:watch   # Tests en modo watch
npm run test:coverage # Cobertura de tests
npm run lint         # Linter
npm run lint:fix     # Fix automático de linter
```

## Endpoints Implementados

Según especificación OpenAPI `openapi-menu.yaml`:

### Restaurantes
- `GET /restaurantes` - Listar todos
- `POST /restaurantes` - Crear nuevo
- `GET /restaurantes/:id` - Obtener por ID
- `PATCH /restaurantes/:id` - Actualizar
- `DELETE /restaurantes/:id` - Desactivar

### Categorías
- `GET /restaurantes/:restauranteId/categorias` - Listar por restaurante
- `POST /restaurantes/:restauranteId/categorias` - Crear
- `PATCH /categorias/:id` - Actualizar
- `DELETE /categorias/:id` - Eliminar

### Platos
- `GET /categorias/:categoriaId/platos` - Listar por categoría
- `POST /categorias/:categoriaId/platos` - Crear
- `PATCH /platos/:id` - Actualizar
- `DELETE /platos/:id` - Soft delete

### Menú Público
- `GET /menu/:slug` - Obtener menú completo por slug (con cache)

## Flujo de Datos (Ejemplo: Crear Restaurante)

```typescript
// 1. HTTP Request llega al Controller
POST /restaurantes
Authorization: Bearer <token>
Body: { nombre: "La Trattoria", ... }

// 2. Controller valida y delega al Use Case
const useCase = new CreateRestauranteUseCase(repository, cache, logger);
const dto = await useCase.execute(createDTO, usuarioId);

// 3. Use Case crea entidad de dominio
const restaurante = new Restaurante(...);
restaurante.slug = generateSlug(restaurante.nombre);

// 4. Persiste via Repository
await repository.save(restaurante);

// 5. Invalida cache
await cache.invalidate('restaurantes:*');

// 6. Retorna DTO
return RestauranteMapper.toDTO(restaurante);
```

## Integración con Cache (Redis)

```typescript
// GET /menu/:slug con cache
async getMenuBySlug(slug: string): Promise<MenuCompletoDTO> {
  const cacheKey = `menu:${slug}`;
  
  // 1. Intentar leer de cache
  const cached = await this.cache.get<MenuCompletoDTO>(cacheKey);
  if (cached) {
    this.logger.info('Cache hit', { slug });
    return cached;
  }
  
  // 2. Cache miss: leer de BD
  const restaurante = await this.repository.findBySlugWithCategoriasPlatos(slug);
  if (!restaurante) {
    throw new NotFoundError('Restaurante no encontrado');
  }
  
  const menu = MenuMapper.toDTO(restaurante);
  
  // 3. Guardar en cache
  await this.cache.set(cacheKey, menu, 3600);
  
  return menu;
}
```

## Upload de Imágenes a S3

```typescript
// POST /imagenes con multipart
const file = req.file; // multer
const key = `restaurantes/${restauranteId}/logo.jpg`;

const imageUrl = await this.storage.uploadImage(file.buffer, key, {
  contentType: file.mimetype,
  metadata: {
    originalName: file.originalname,
    uploadedBy: usuarioId
  }
});

// Guardar metadatos en BD
await this.imagenRepository.save(new Imagen(..., imageUrl));
```

## Logging Estructurado

```typescript
// Winston logger con formato JSON
logger.info('Restaurante creado', {
  restauranteId: restaurante.id,
  usuarioId,
  slug: restaurante.slug,
  timestamp: new Date().toISOString()
});

// Output:
{
  "level": "info",
  "message": "Restaurante creado",
  "restauranteId": "uuid...",
  "usuarioId": "uuid...",
  "slug": "la-trattoria",
  "timestamp": "2026-01-24T10:30:00.000Z"
}
```

## Testing

### Unit Tests (Domain)
```typescript
describe('Restaurante', () => {
  it('should update nombre correctly', () => {
    const restaurante = new Restaurante(...);
    restaurante.actualizar({ nombre: 'Nuevo Nombre' });
    expect(restaurante.nombre).toBe('Nuevo Nombre');
    expect(restaurante.actualizadoEn).not.toBe(restaurante.creadoEn);
  });
});
```

### Integration Tests (Use Cases)
```typescript
describe('CreateRestauranteUseCase', () => {
  it('should create restaurante and invalidate cache', async () => {
    const mockRepo = createMockRepository();
    const mockCache = createMockCache();
    const useCase = new CreateRestauranteUseCase(mockRepo, mockCache);
    
    const dto = await useCase.execute(createDTO, usuarioId);
    
    expect(mockRepo.save).toHaveBeenCalled();
    expect(mockCache.invalidate).toHaveBeenCalledWith('restaurantes:*');
    expect(dto.id).toBeDefined();
  });
});
```

## Docker

```bash
# Build
docker build -t livemenu/menu-service-nodejs .

# Run
docker run -p 3000:3000 \
  -e DATABASE_URL=... \
  -e REDIS_URL=... \
  livemenu/menu-service-nodejs
```

## Buenas Prácticas de Node.js/TypeScript

### 1. **Tipado Estricto**
- Habilitar `strict: true` en tsconfig.json
- Evitar `any`, usar tipos específicos o `unknown`
- Definir interfaces para todas las estructuras de datos

```typescript
// ❌ Malo
function processData(data: any) { ... }

// ✅ Bueno
interface RestauranteData {
  nombre: string;
  usuarioId: string;
}
function processData(data: RestauranteData) { ... }
```

### 2. **Manejo de Errores Asíncrono**
- Usar try/catch en funciones async
- Middleware de error centralizado
- No swallow errors silenciosamente

```typescript
// ✅ Bueno
async function createRestaurante(dto: CreateRestauranteDTO) {
  try {
    const restaurante = await repository.save(dto);
    return restaurante;
  } catch (error) {
    logger.error('Error creating restaurante', { error, dto });
    throw new ApplicationError('Failed to create restaurante');
  }
}
```

### 3. **Inyección de Dependencias**
- Pasar dependencias en constructores
- Facilita testing con mocks
- Evita singletons globales

```typescript
class CreateRestauranteUseCase {
  constructor(
    private readonly repository: IRestauranteRepository,
    private readonly cache: ICacheService,
    private readonly logger: ILogger
  ) {}
}
```

### 4. **Inmutabilidad**
- Usar `readonly` en propiedades que no deben cambiar
- Preferir `const` sobre `let`
- Evitar mutaciones de objetos compartidos

```typescript
class Restaurante {
  constructor(
    public readonly id: string,  // No puede cambiar
    public nombre: string         // Puede cambiar con método
  ) {}
}
```

### 5. **Validación de Entrada**
- Validar en capa HTTP antes de llegar a dominio
- Usar express-validator o joi
- Retornar errores claros y específicos

```typescript
const createRestauranteValidator = [
  body('nombre').isString().isLength({ min: 2, max: 100 }),
  body('telefono').optional().matches(/^\+?[0-9\s-]+$/),
  body('horarios').optional().isObject()
];
```

### 6. **Logging Consistente**
- Usar logger estructurado (Winston)
- Incluir contexto relevante (IDs, usuario, timestamp)
- Niveles apropiados: ERROR, WARN, INFO, DEBUG

```typescript
logger.info('Request received', {
  method: req.method,
  path: req.path,
  userId: req.user.id
});
```

### 7. **Gestión de Conexiones**
- Pool de conexiones para PostgreSQL
- Reusar cliente Redis
- Cerrar conexiones gracefully en shutdown

```typescript
// Graceful shutdown
process.on('SIGTERM', async () => {
  await pgPool.end();
  await redisClient.quit();
  server.close();
});
```

### 8. **Seguridad**
- Usar Helmet para headers HTTP seguros
- Rate limiting con express-rate-limit
- Validar y sanitizar inputs
- No exponer stack traces en producción

```typescript
app.use(helmet());
app.use(cors({ origin: process.env.ALLOWED_ORIGINS }));
app.use(express.json({ limit: '10mb' }));
```

### 9. **Performance**
- Comprimir respuestas HTTP
- Implementar paginación en listados
- Usar índices en queries frecuentes
- Cache estratégico con TTL apropiado

```typescript
app.use(compression());

// Paginación
const limit = Math.min(parseInt(req.query.limit as string) || 20, 100);
const offset = parseInt(req.query.offset as string) || 0;
```

### 10. **Estructura de Archivos**
- Un concepto por archivo (single responsibility)
- Nombres descriptivos en PascalCase para clases
- Agrupar por feature, no por tipo técnico

```
✅ Bueno:
src/application/use-cases/restaurante/CreateRestauranteUseCase.ts

❌ Malo:
src/use-cases/create-restaurante.ts
```

### 11. **Tests**
- Tests unitarios para dominio (entities, value objects)
- Tests de integración para use cases (con mocks)
- Tests E2E para API completa
- Cobertura mínima 80%

```bash
npm test -- --coverage
```

### 12. **Environment Variables**
- Nunca commitear .env
- Validar variables requeridas al inicio
- Usar dotenv solo en desarrollo

```typescript
// src/shared/config/env.ts
export const env = {
  PORT: parseInt(process.env.PORT || '3000'),
  DATABASE_URL: requireEnv('DATABASE_URL'),
  NODE_ENV: process.env.NODE_ENV || 'development'
};

function requireEnv(key: string): string {
  const value = process.env[key];
  if (!value) throw new Error(`Missing env: ${key}`);
  return value;
}
```

## Recursos Adicionales

- [Express Best Practices](https://expressjs.com/en/advanced/best-practice-performance.html)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/handbook/intro.html)
- [Node.js Best Practices](https://github.com/goldbergyoni/nodebestpractices)
- [Hexagonal Architecture](https://alistair.cockburn.us/hexagonal-architecture/)

---

**Versión**: 1.0  
**Autor**: LiveMenu Team  
**Última actualización**: 24 de enero de 2026
