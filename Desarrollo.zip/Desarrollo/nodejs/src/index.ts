import express, { Application } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import { errorHandler } from './adapters/http/middleware/errorHandler';
import { PostgresConnection } from './infrastructure/database/PostgresConnection';
import { RedisCacheService } from './infrastructure/cache/RedisCacheService';
import { S3StorageService } from './infrastructure/storage/S3StorageService';
import { PostgresRestauranteRepository } from './infrastructure/repositories/PostgresRestauranteRepository';
import { PostgresCategoriaRepository } from './infrastructure/repositories/PostgresCategoriaRepository';
import { PostgresPlatoRepository } from './infrastructure/repositories/PostgresPlatoRepository';
import { CreateRestauranteUseCase } from './application/use-cases/restaurante/CreateRestauranteUseCase';
import { GetRestauranteUseCase } from './application/use-cases/restaurante/GetRestauranteUseCase';
import { UpdateRestauranteUseCase } from './application/use-cases/restaurante/UpdateRestauranteUseCase';
import { DeleteRestauranteUseCase } from './application/use-cases/restaurante/DeleteRestauranteUseCase';
import { ListRestaurantesUseCase } from './application/use-cases/restaurante/ListRestaurantesUseCase';
import { CreateCategoriaUseCase } from './application/use-cases/categoria/CreateCategoriaUseCase';
import { ListCategoriasUseCase } from './application/use-cases/categoria/ListCategoriasUseCase';
import { CreatePlatoUseCase } from './application/use-cases/plato/CreatePlatoUseCase';
import { GetMenuBySlugUseCase } from './application/use-cases/menu/GetMenuBySlugUseCase';
import { RestauranteController } from './adapters/http/controllers/RestauranteController';
import { CategoriaController } from './adapters/http/controllers/CategoriaController';
import { PlatoController } from './adapters/http/controllers/PlatoController';
import { MenuController } from './adapters/http/controllers/MenuController';

// Dependency Injection Container
class Container {
  // Infrastructure
  private db = PostgresConnection.getInstance();
  private cache = new RedisCacheService();
  private storage = new S3StorageService();

  // Repositories
  private restauranteRepo = new PostgresRestauranteRepository(this.db);
  private categoriaRepo = new PostgresCategoriaRepository(this.db);
  private platoRepo = new PostgresPlatoRepository(this.db);

  // Use Cases - Restaurante
  createRestauranteUseCase = new CreateRestauranteUseCase(this.restauranteRepo, this.cache);
  getRestauranteUseCase = new GetRestauranteUseCase(this.restauranteRepo, this.cache);
  updateRestauranteUseCase = new UpdateRestauranteUseCase(this.restauranteRepo, this.cache);
  deleteRestauranteUseCase = new DeleteRestauranteUseCase(this.restauranteRepo, this.cache);
  listRestaurantesUseCase = new ListRestaurantesUseCase(this.restauranteRepo, this.cache);

  // Use Cases - Categoria
  createCategoriaUseCase = new CreateCategoriaUseCase(
    this.categoriaRepo,
    this.restauranteRepo,
    this.cache
  );
  listCategoriasUseCase = new ListCategoriasUseCase(this.categoriaRepo, this.cache);

  // Use Cases - Plato
  createPlatoUseCase = new CreatePlatoUseCase(
    this.platoRepo,
    this.categoriaRepo,
    this.restauranteRepo,
    this.cache
  );

  // Use Cases - Menu
  getMenuBySlugUseCase = new GetMenuBySlugUseCase(
    this.restauranteRepo,
    this.categoriaRepo,
    this.platoRepo,
    this.cache
  );

  // Controllers
  restauranteController = new RestauranteController(
    this.createRestauranteUseCase,
    this.getRestauranteUseCase,
    this.updateRestauranteUseCase,
    this.deleteRestauranteUseCase,
    this.listRestaurantesUseCase
  );

  categoriaController = new CategoriaController(
    this.createCategoriaUseCase,
    this.listCategoriasUseCase
  );

  platoController = new PlatoController(this.createPlatoUseCase);

  menuController = new MenuController(this.getMenuBySlugUseCase);

  async init(): Promise<void> {
    await this.cache.connect();
  }

  async close(): Promise<void> {
    await this.db.close();
    await this.cache.disconnect();
  }
}

// Application
export async function createApp(): Promise<Application> {
  const app = express();
  const container = new Container();

  await container.init();

  // Middleware
  app.use(helmet());
  app.use(cors());
  app.use(compression());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Health check
  app.get('/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // Routes
  app.use('/restaurantes', container.restauranteController.getRouter());
  app.use('/', container.categoriaController.getRouter());
  app.use('/', container.platoController.getRouter());
  app.use('/', container.menuController.getRouter());

  // Error handler (must be last)
  app.use(errorHandler);

  return app;
}

// Start server
const PORT = process.env.PORT || 3000;

createApp()
  .then((app) => {
    app.listen(PORT, () => {
      console.log(`🚀 Server running on port ${PORT}`);
      console.log(`📝 Environment: ${process.env.NODE_ENV || 'development'}`);
    });
  })
  .catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM signal received: closing HTTP server');
  process.exit(0);
});
