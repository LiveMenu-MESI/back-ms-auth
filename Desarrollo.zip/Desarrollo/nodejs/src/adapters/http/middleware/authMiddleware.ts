import { Request, Response, NextFunction } from 'express';
import { verify } from 'jsonwebtoken';
import { UnauthorizedError } from '../../../domain/errors/DomainError';

interface JWTPayload {
  usuarioId: string;
  email: string;
}

declare global {
  namespace Express {
    interface Request {
      usuarioId?: string;
    }
  }
}

export const authMiddleware = (req: Request, res: Response, next: NextFunction) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new UnauthorizedError('Token no proporcionado');
    }

    const token = authHeader.substring(7);
    const secret = process.env.JWT_SECRET || 'your-secret-key';
    
    const decoded = verify(token, secret) as JWTPayload;
    req.usuarioId = decoded.usuarioId;
    
    next();
  } catch (error) {
    next(new UnauthorizedError('Token inválido o expirado'));
  }
};
