import { Request, Response, Router } from 'express';
import { authMiddleware } from '../middleware/authMiddleware';
import { CreateRestauranteUseCase } from '../../../application/use-cases/restaurante/CreateRestauranteUseCase';
import { GetRestauranteUseCase } from '../../../application/use-cases/restaurante/GetRestauranteUseCase';
import { UpdateRestauranteUseCase } from '../../../application/use-cases/restaurante/UpdateRestauranteUseCase';
import { DeleteRestauranteUseCase } from '../../../application/use-cases/restaurante/DeleteRestauranteUseCase';
import { ListRestaurantesUseCase } from '../../../application/use-cases/restaurante/ListRestaurantesUseCase';

export class RestauranteController {
  constructor(
    private readonly createUseCase: CreateRestauranteUseCase,
    private readonly getUseCase: GetRestauranteUseCase,
    private readonly updateUseCase: UpdateRestauranteUseCase,
    private readonly deleteUseCase: DeleteRestauranteUseCase,
    private readonly listUseCase: ListRestaurantesUseCase
  ) {}

  async create(req: Request, res: Response): Promise<void> {
    const dto = await this.createUseCase.execute(req.body, req.usuarioId!);
    res.status(201).json(dto);
  }

  async getById(req: Request, res: Response): Promise<void> {
    const dto = await this.getUseCase.execute(req.params.id);
    res.json(dto);
  }

  async update(req: Request, res: Response): Promise<void> {
    const dto = await this.updateUseCase.execute(req.params.id, req.body, req.usuarioId!);
    res.json(dto);
  }

  async delete(req: Request, res: Response): Promise<void> {
    await this.deleteUseCase.execute(req.params.id, req.usuarioId!);
    res.status(204).send();
  }

  async list(req: Request, res: Response): Promise<void> {
    const dtos = await this.listUseCase.execute(req.usuarioId!);
    res.json(dtos);
  }

  getRouter(): Router {
    const router = Router();

    router.get('/', authMiddleware, (req, res, next) => 
      this.list(req, res).catch(next)
    );

    router.post('/', authMiddleware, (req, res, next) => 
      this.create(req, res).catch(next)
    );

    router.get('/:id', authMiddleware, (req, res, next) => 
      this.getById(req, res).catch(next)
    );

    router.patch('/:id', authMiddleware, (req, res, next) => 
      this.update(req, res).catch(next)
    );

    router.delete('/:id', authMiddleware, (req, res, next) => 
      this.delete(req, res).catch(next)
    );

    return router;
  }
}
