import { Request, Response, Router } from 'express';
import { authMiddleware } from '../middleware/authMiddleware';
import { CreatePlatoUseCase } from '../../../application/use-cases/plato/CreatePlatoUseCase';

export class PlatoController {
  constructor(
    private readonly createUseCase: CreatePlatoUseCase
  ) {}

  async create(req: Request, res: Response): Promise<void> {
    const { categoriaId } = req.params;
    const dto = await this.createUseCase.execute(categoriaId, req.body, req.usuarioId!);
    res.status(201).json(dto);
  }

  getRouter(): Router {
    const router = Router();

    router.post('/categorias/:categoriaId/platos', authMiddleware, (req, res, next) =>
      this.create(req, res).catch(next)
    );

    return router;
  }
}
