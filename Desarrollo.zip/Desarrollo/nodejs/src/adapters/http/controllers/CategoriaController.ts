import { Request, Response, Router } from 'express';
import { authMiddleware } from '../middleware/authMiddleware';
import { CreateCategoriaUseCase } from '../../../application/use-cases/categoria/CreateCategoriaUseCase';
import { ListCategoriasUseCase } from '../../../application/use-cases/categoria/ListCategoriasUseCase';

export class CategoriaController {
  constructor(
    private readonly createUseCase: CreateCategoriaUseCase,
    private readonly listUseCase: ListCategoriasUseCase
  ) {}

  async create(req: Request, res: Response): Promise<void> {
    const { restauranteId } = req.params;
    const dto = await this.createUseCase.execute(restauranteId, req.body, req.usuarioId!);
    res.status(201).json(dto);
  }

  async list(req: Request, res: Response): Promise<void> {
    const { restauranteId } = req.params;
    const dtos = await this.listUseCase.execute(restauranteId);
    res.json(dtos);
  }

  getRouter(): Router {
    const router = Router();

    // Rutas para categorías de un restaurante
    router.get('/restaurantes/:restauranteId/categorias', authMiddleware, (req, res, next) =>
      this.list(req, res).catch(next)
    );

    router.post('/restaurantes/:restauranteId/categorias', authMiddleware, (req, res, next) =>
      this.create(req, res).catch(next)
    );

    return router;
  }
}
