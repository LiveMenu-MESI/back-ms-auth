import { Request, Response, Router } from 'express';
import { GetMenuBySlugUseCase } from '../../../application/use-cases/menu/GetMenuBySlugUseCase';

export class MenuController {
  constructor(
    private readonly getMenuUseCase: GetMenuBySlugUseCase
  ) {}

  async getBySlug(req: Request, res: Response): Promise<void> {
    const menu = await this.getMenuUseCase.execute(req.params.slug);
    res.json(menu);
  }

  getRouter(): Router {
    const router = Router();

    // Ruta pública (sin authMiddleware)
    router.get('/menu/:slug', (req, res, next) =>
      this.getBySlug(req, res).catch(next)
    );

    return router;
  }
}
