export interface IStorageService {
  uploadImage(file: Buffer, key: string, contentType: string): Promise<string>;
  deleteImage(key: string): Promise<void>;
  generateKey(prefix: string, filename: string): string;
}