export class Plato {
  constructor(
    public readonly id: string,
    public readonly categoriaId: string,
    public nombre: string,
    public descripcion: string,
    public precio: number,
    public imagenUrl: string | null,
    public disponible: boolean,
    public orden: number,
    public activo: boolean,
    public readonly creadoEn: Date,
    public actualizadoEn: Date
  ) {}

  actualizar(
    nombre: string,
    descripcion: string,
    precio: number,
    disponible: boolean,
    orden: number
  ): void {
    this.nombre = nombre;
    this.descripcion = descripcion;
    this.precio = precio;
    this.disponible = disponible;
    this.orden = orden;
    this.actualizadoEn = new Date();
  }

  actualizarImagen(imagenUrl: string): void {
    this.imagenUrl = imagenUrl;
    this.actualizadoEn = new Date();
  }

  desactivar(): void {
    this.activo = false;
    this.actualizadoEn = new Date();
  }
}