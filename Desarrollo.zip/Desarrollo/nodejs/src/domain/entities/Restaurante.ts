// Domain Entity: Restaurante
export class Restaurante {
  constructor(
    public readonly id: string,
    public readonly usuarioId: string,
    public nombre: string,
    public slug: string,
    public descripcion: string | null,
    public logoUrl: string | null,
    public telefono: string | null,
    public direccion: string | null,
    public horarios: Record<string, any> | null,
    public activo: boolean,
    public readonly creadoEn: Date,
    public actualizadoEn: Date
  ) {}

  actualizar(datos: Partial<Pick<Restaurante, 'nombre' | 'descripcion' | 'logoUrl' | 'telefono' | 'direccion' | 'horarios'>>): void {
    if (datos.nombre) this.nombre = datos.nombre;
    if (datos.descripcion !== undefined) this.descripcion = datos.descripcion;
    if (datos.logoUrl !== undefined) this.logoUrl = datos.logoUrl;
    if (datos.telefono !== undefined) this.telefono = datos.telefono;
    if (datos.direccion !== undefined) this.direccion = datos.direccion;
    if (datos.horarios !== undefined) this.horarios = datos.horarios;
    this.actualizadoEn = new Date();
  }

  desactivar(): void {
    this.activo = false;
    this.actualizadoEn = new Date();
  }
}
