export class Categoria {
  constructor(
    public readonly id: string,
    public readonly restauranteId: string,
    public nombre: string,
    public descripcion: string,
    public orden: number,
    public activo: boolean,
    public readonly creadoEn: Date,
    public actualizadoEn: Date
  ) {}

  actualizar(nombre: string, descripcion: string, orden: number): void {
    this.nombre = nombre;
    this.descripcion = descripcion;
    this.orden = orden;
    this.actualizadoEn = new Date();
  }

  desactivar(): void {
    this.activo = false;
    this.actualizadoEn = new Date();
  }
}