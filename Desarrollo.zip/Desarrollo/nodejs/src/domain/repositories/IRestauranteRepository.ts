import { Restaurante } from '../entities/Restaurante';

export interface IRestauranteRepository {
  findById(id: string): Promise<Restaurante | null>;
  findBySlug(slug: string): Promise<Restaurante | null>;
  findByUsuarioId(usuarioId: string): Promise<Restaurante[]>;
  findAll(): Promise<Restaurante[]>;
  save(restaurante: Restaurante): Promise<Restaurante>;
  update(restaurante: Restaurante): Promise<Restaurante>;
  delete(id: string): Promise<void>;
}