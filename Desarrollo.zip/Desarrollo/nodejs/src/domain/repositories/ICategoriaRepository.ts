import { Categoria } from '../entities/Categoria';

export interface ICategoriaRepository {
  findById(id: string): Promise<Categoria | null>;
  findByRestauranteId(restauranteId: string): Promise<Categoria[]>;
  save(categoria: Categoria): Promise<Categoria>;
  update(categoria: Categoria): Promise<Categoria>;
  delete(id: string): Promise<void>;
}