import { Plato } from '../entities/Plato';

export interface IPlatoRepository {
  findById(id: string): Promise<Plato | null>;
  findByCategoriaId(categoriaId: string): Promise<Plato[]>;
  save(plato: Plato): Promise<Plato>;
  update(plato: Plato): Promise<Plato>;
  delete(id: string): Promise<void>;
}