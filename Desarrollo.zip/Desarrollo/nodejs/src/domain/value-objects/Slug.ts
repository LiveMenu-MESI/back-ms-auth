export class Slug {
  private constructor(public readonly value: string) {
    if (!Slug.isValid(value)) {
      throw new Error('Invalid slug format');
    }
  }

  static fromString(value: string): Slug {
    const normalized = value
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '') // Remove accents
      .replace(/[^a-z0-9]+/g, '-') // Replace non-alphanumeric with -
      .replace(/^-+|-+$/g, ''); // Remove leading/trailing -
    
    return new Slug(normalized);
  }

  static fromNombre(nombre: string): Slug {
    return Slug.fromString(nombre);
  }

  private static isValid(value: string): boolean {
    return /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(value);
  }

  toString(): string {
    return this.value;
  }
}