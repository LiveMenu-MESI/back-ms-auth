import { Restaurante } from '../../domain/entities/Restaurante';
import { Slug } from '../../domain/value-objects/Slug';
import { IRestauranteRepository } from '../../domain/repositories/IRestauranteRepository';
import { PostgresConnection } from '../database/PostgresConnection';

export class PostgresRestauranteRepository implements IRestauranteRepository {
  constructor(private readonly db: PostgresConnection) {}

  async findById(id: string): Promise<Restaurante | null> {
    const query = `
      SELECT * FROM restaurantes 
      WHERE id = $1 AND activo = true
    `;
    const result = await this.db.query(query, [id]);
    
    return result.rows.length > 0 ? this.mapToEntity(result.rows[0]) : null;
  }

  async findBySlug(slug: string): Promise<Restaurante | null> {
    const query = `
      SELECT * FROM restaurantes 
      WHERE slug = $1 AND activo = true
    `;
    const result = await this.db.query(query, [slug]);
    
    return result.rows.length > 0 ? this.mapToEntity(result.rows[0]) : null;
  }

  async findByUsuarioId(usuarioId: string): Promise<Restaurante[]> {
    const query = `
      SELECT * FROM restaurantes 
      WHERE usuario_id = $1 AND activo = true
      ORDER BY creado_en DESC
    `;
    const result = await this.db.query(query, [usuarioId]);
    
    return result.rows.map(row => this.mapToEntity(row));
  }

  async findAll(): Promise<Restaurante[]> {
    const query = `
      SELECT * FROM restaurantes 
      WHERE activo = true
      ORDER BY creado_en DESC
    `;
    const result = await this.db.query(query);
    
    return result.rows.map(row => this.mapToEntity(row));
  }

  async save(restaurante: Restaurante): Promise<Restaurante> {
    const query = `
      INSERT INTO restaurantes (
        id, usuario_id, nombre, slug, descripcion, direccion, 
        telefono, logo_url, horarios, activo, creado_en, actualizado_en
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      RETURNING *
    `;
    
    const values = [
      restaurante.id,
      restaurante.usuarioId,
      restaurante.nombre,
      restaurante.slug.toString(),
      restaurante.descripcion,
      restaurante.direccion,
      restaurante.telefono,
      restaurante.logoUrl,
      JSON.stringify(restaurante.horarios),
      restaurante.activo,
      restaurante.creadoEn,
      restaurante.actualizadoEn,
    ];
    
    const result = await this.db.query(query, values);
    return this.mapToEntity(result.rows[0]);
  }

  async update(restaurante: Restaurante): Promise<Restaurante> {
    const query = `
      UPDATE restaurantes 
      SET nombre = $1, descripcion = $2, direccion = $3, telefono = $4,
          logo_url = $5, horarios = $6, activo = $7, actualizado_en = $8
      WHERE id = $9
      RETURNING *
    `;
    
    const values = [
      restaurante.nombre,
      restaurante.descripcion,
      restaurante.direccion,
      restaurante.telefono,
      restaurante.logoUrl,
      JSON.stringify(restaurante.horarios),
      restaurante.activo,
      restaurante.actualizadoEn,
      restaurante.id,
    ];
    
    const result = await this.db.query(query, values);
    return this.mapToEntity(result.rows[0]);
  }

  async delete(id: string): Promise<void> {
    const query = `
      UPDATE restaurantes 
      SET activo = false, actualizado_en = NOW()
      WHERE id = $1
    `;
    await this.db.query(query, [id]);
  }

  private mapToEntity(row: any): Restaurante {
    return new Restaurante(
      row.id,
      row.usuario_id,
      row.nombre,
      Slug.fromString(row.slug),
      row.descripcion,
      row.direccion,
      row.telefono,
      row.logo_url,
      typeof row.horarios === 'string' ? JSON.parse(row.horarios) : row.horarios,
      row.activo,
      new Date(row.creado_en),
      new Date(row.actualizado_en)
    );
  }
}
