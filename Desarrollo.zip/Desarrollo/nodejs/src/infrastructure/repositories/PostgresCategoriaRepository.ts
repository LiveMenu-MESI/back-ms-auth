import { Categoria } from '../../domain/entities/Categoria';
import { ICategoriaRepository } from '../../domain/repositories/ICategoriaRepository';
import { PostgresConnection } from '../database/PostgresConnection';

export class PostgresCategoriaRepository implements ICategoriaRepository {
  constructor(private readonly db: PostgresConnection) {}

  async findById(id: string): Promise<Categoria | null> {
    const query = `
      SELECT * FROM categorias 
      WHERE id = $1 AND activo = true
    `;
    const result = await this.db.query(query, [id]);
    
    return result.rows.length > 0 ? this.mapToEntity(result.rows[0]) : null;
  }

  async findByRestauranteId(restauranteId: string): Promise<Categoria[]> {
    const query = `
      SELECT * FROM categorias 
      WHERE restaurante_id = $1 AND activo = true
      ORDER BY orden ASC, creado_en ASC
    `;
    const result = await this.db.query(query, [restauranteId]);
    
    return result.rows.map(row => this.mapToEntity(row));
  }

  async save(categoria: Categoria): Promise<Categoria> {
    const query = `
      INSERT INTO categorias (
        id, restaurante_id, nombre, descripcion, orden, activo, creado_en, actualizado_en
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING *
    `;
    
    const values = [
      categoria.id,
      categoria.restauranteId,
      categoria.nombre,
      categoria.descripcion,
      categoria.orden,
      categoria.activo,
      categoria.creadoEn,
      categoria.actualizadoEn,
    ];
    
    const result = await this.db.query(query, values);
    return this.mapToEntity(result.rows[0]);
  }

  async update(categoria: Categoria): Promise<Categoria> {
    const query = `
      UPDATE categorias 
      SET nombre = $1, descripcion = $2, orden = $3, activo = $4, actualizado_en = $5
      WHERE id = $6
      RETURNING *
    `;
    
    const values = [
      categoria.nombre,
      categoria.descripcion,
      categoria.orden,
      categoria.activo,
      categoria.actualizadoEn,
      categoria.id,
    ];
    
    const result = await this.db.query(query, values);
    return this.mapToEntity(result.rows[0]);
  }

  async delete(id: string): Promise<void> {
    const query = `
      UPDATE categorias 
      SET activo = false, actualizado_en = NOW()
      WHERE id = $1
    `;
    await this.db.query(query, [id]);
  }

  private mapToEntity(row: any): Categoria {
    return new Categoria(
      row.id,
      row.restaurante_id,
      row.nombre,
      row.descripcion,
      row.orden,
      row.activo,
      new Date(row.creado_en),
      new Date(row.actualizado_en)
    );
  }
}
