import { Plato } from '../../domain/entities/Plato';
import { IPlatoRepository } from '../../domain/repositories/IPlatoRepository';
import { PostgresConnection } from '../database/PostgresConnection';

export class PostgresPlatoRepository implements IPlatoRepository {
  constructor(private readonly db: PostgresConnection) {}

  async findById(id: string): Promise<Plato | null> {
    const query = `
      SELECT * FROM platos 
      WHERE id = $1 AND activo = true
    `;
    const result = await this.db.query(query, [id]);
    
    return result.rows.length > 0 ? this.mapToEntity(result.rows[0]) : null;
  }

  async findByCategoriaId(categoriaId: string): Promise<Plato[]> {
    const query = `
      SELECT * FROM platos 
      WHERE categoria_id = $1 AND activo = true
      ORDER BY orden ASC, creado_en ASC
    `;
    const result = await this.db.query(query, [categoriaId]);
    
    return result.rows.map(row => this.mapToEntity(row));
  }

  async save(plato: Plato): Promise<Plato> {
    const query = `
      INSERT INTO platos (
        id, categoria_id, nombre, descripcion, precio, imagen_url, 
        disponible, orden, activo, creado_en, actualizado_en
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      RETURNING *
    `;
    
    const values = [
      plato.id,
      plato.categoriaId,
      plato.nombre,
      plato.descripcion,
      plato.precio,
      plato.imagenUrl,
      plato.disponible,
      plato.orden,
      plato.activo,
      plato.creadoEn,
      plato.actualizadoEn,
    ];
    
    const result = await this.db.query(query, values);
    return this.mapToEntity(result.rows[0]);
  }

  async update(plato: Plato): Promise<Plato> {
    const query = `
      UPDATE platos 
      SET nombre = $1, descripcion = $2, precio = $3, imagen_url = $4,
          disponible = $5, orden = $6, activo = $7, actualizado_en = $8
      WHERE id = $9
      RETURNING *
    `;
    
    const values = [
      plato.nombre,
      plato.descripcion,
      plato.precio,
      plato.imagenUrl,
      plato.disponible,
      plato.orden,
      plato.activo,
      plato.actualizadoEn,
      plato.id,
    ];
    
    const result = await this.db.query(query, values);
    return this.mapToEntity(result.rows[0]);
  }

  async delete(id: string): Promise<void> {
    const query = `
      UPDATE platos 
      SET activo = false, actualizado_en = NOW()
      WHERE id = $1
    `;
    await this.db.query(query, [id]);
  }

  private mapToEntity(row: any): Plato {
    return new Plato(
      row.id,
      row.categoria_id,
      row.nombre,
      row.descripcion,
      parseFloat(row.precio),
      row.imagen_url,
      row.disponible,
      row.orden,
      row.activo,
      new Date(row.creado_en),
      new Date(row.actualizado_en)
    );
  }
}
