import { IRestauranteRepository } from '../../../domain/repositories/IRestauranteRepository';
import { ICategoriaRepository } from '../../../domain/repositories/ICategoriaRepository';
import { IPlatoRepository } from '../../../domain/repositories/IPlatoRepository';
import { ICacheService } from '../../../domain/services/ICacheService';
import { NotFoundError } from '../../../domain/errors/DomainError';
import { RestauranteMapper } from '../../dtos/RestauranteDTO';
import { CategoriaMapper } from '../../dtos/CategoriaDTO';
import { PlatoMapper } from '../../dtos/PlatoDTO';

export interface MenuCompletoDTO {
  restaurante: {
    id: string;
    nombre: string;
    slug: string;
    descripcion: string;
    direccion: string;
    telefono: string;
    logoUrl: string | null;
    horarios: Record<string, any>;
  };
  categorias: Array<{
    id: string;
    nombre: string;
    descripcion: string;
    orden: number;
    platos: Array<{
      id: string;
      nombre: string;
      descripcion: string;
      precio: number;
      imagenUrl: string | null;
      disponible: boolean;
      orden: number;
    }>;
  }>;
}

export class GetMenuBySlugUseCase {
  constructor(
    private readonly restauranteRepository: IRestauranteRepository,
    private readonly categoriaRepository: ICategoriaRepository,
    private readonly platoRepository: IPlatoRepository,
    private readonly cacheService: ICacheService
  ) {}

  async execute(slug: string): Promise<MenuCompletoDTO> {
    const cacheKey = `menu:${slug}:completo`;
    
    const cached = await this.cacheService.get<MenuCompletoDTO>(cacheKey);
    if (cached) {
      return cached;
    }

    const restaurante = await this.restauranteRepository.findBySlug(slug);
    if (!restaurante || !restaurante.activo) {
      throw new NotFoundError('Restaurante', slug);
    }

    const categorias = await this.categoriaRepository.findByRestauranteId(restaurante.id);
    const categoriasActivas = categorias.filter(c => c.activo).sort((a, b) => a.orden - b.orden);

    const menu: MenuCompletoDTO = {
      restaurante: {
        id: restaurante.id,
        nombre: restaurante.nombre,
        slug: restaurante.slug.toString(),
        descripcion: restaurante.descripcion,
        direccion: restaurante.direccion,
        telefono: restaurante.telefono,
        logoUrl: restaurante.logoUrl,
        horarios: restaurante.horarios,
      },
      categorias: await Promise.all(
        categoriasActivas.map(async (categoria) => {
          const platos = await this.platoRepository.findByCategoriaId(categoria.id);
          const platosActivos = platos
            .filter(p => p.activo)
            .sort((a, b) => a.orden - b.orden);

          return {
            id: categoria.id,
            nombre: categoria.nombre,
            descripcion: categoria.descripcion,
            orden: categoria.orden,
            platos: platosActivos.map(plato => ({
              id: plato.id,
              nombre: plato.nombre,
              descripcion: plato.descripcion,
              precio: plato.precio,
              imagenUrl: plato.imagenUrl,
              disponible: plato.disponible,
              orden: plato.orden,
            })),
          };
        })
      ),
    };

    await this.cacheService.set(cacheKey, menu, 3600); // 1 hora

    return menu;
  }
}
