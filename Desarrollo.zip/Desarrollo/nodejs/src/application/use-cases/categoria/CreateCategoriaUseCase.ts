import { v4 as uuidv4 } from 'uuid';
import { Categoria } from '../../../domain/entities/Categoria';
import { ICategoriaRepository } from '../../../domain/repositories/ICategoriaRepository';
import { IRestauranteRepository } from '../../../domain/repositories/IRestauranteRepository';
import { ICacheService } from '../../../domain/services/ICacheService';
import { NotFoundError, UnauthorizedError } from '../../../domain/errors/DomainError';
import { CategoriaDTO, CategoriaMapper } from '../../dtos/CategoriaDTO';

export interface CreateCategoriaInput {
  nombre: string;
  descripcion: string;
  orden?: number;
}

export class CreateCategoriaUseCase {
  constructor(
    private readonly categoriaRepository: ICategoriaRepository,
    private readonly restauranteRepository: IRestauranteRepository,
    private readonly cacheService: ICacheService
  ) {}

  async execute(restauranteId: string, input: CreateCategoriaInput, usuarioId: string): Promise<CategoriaDTO> {
    const restaurante = await this.restauranteRepository.findById(restauranteId);
    if (!restaurante) {
      throw new NotFoundError('Restaurante', restauranteId);
    }

    if (restaurante.usuarioId !== usuarioId) {
      throw new UnauthorizedError('No tienes permiso para crear categorías en este restaurante');
    }

    const categoria = new Categoria(
      uuidv4(),
      restauranteId,
      input.nombre,
      input.descripcion,
      input.orden || 0,
      true,
      new Date(),
      new Date()
    );

    const saved = await this.categoriaRepository.save(categoria);
    
    await this.cacheService.invalidatePattern(`menu:${restaurante.slug}*`);
    await this.cacheService.invalidatePattern(`restaurante:${restauranteId}:categorias`);

    return CategoriaMapper.toDTO(saved);
  }
}
