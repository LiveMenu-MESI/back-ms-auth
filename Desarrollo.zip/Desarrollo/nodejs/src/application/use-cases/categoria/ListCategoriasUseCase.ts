import { ICategoriaRepository } from '../../../domain/repositories/ICategoriaRepository';
import { ICacheService } from '../../../domain/services/ICacheService';
import { CategoriaDTO, CategoriaMapper } from '../../dtos/CategoriaDTO';

export class ListCategoriasUseCase {
  constructor(
    private readonly categoriaRepository: ICategoriaRepository,
    private readonly cacheService: ICacheService
  ) {}

  async execute(restauranteId: string): Promise<CategoriaDTO[]> {
    const cacheKey = `restaurante:${restauranteId}:categorias`;
    
    const cached = await this.cacheService.get<CategoriaDTO[]>(cacheKey);
    if (cached) {
      return cached;
    }

    const categorias = await this.categoriaRepository.findByRestauranteId(restauranteId);
    const dtos = categorias
      .sort((a, b) => a.orden - b.orden)
      .map(CategoriaMapper.toDTO);
    
    await this.cacheService.set(cacheKey, dtos, 3600);

    return dtos;
  }
}
