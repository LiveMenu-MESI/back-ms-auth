import { v4 as uuidv4 } from 'uuid';
import { Plato } from '../../../domain/entities/Plato';
import { IPlatoRepository } from '../../../domain/repositories/IPlatoRepository';
import { ICategoriaRepository } from '../../../domain/repositories/ICategoriaRepository';
import { IRestauranteRepository } from '../../../domain/repositories/IRestauranteRepository';
import { ICacheService } from '../../../domain/services/ICacheService';
import { NotFoundError, UnauthorizedError } from '../../../domain/errors/DomainError';
import { PlatoDTO, PlatoMapper } from '../../dtos/PlatoDTO';

export interface CreatePlatoInput {
  nombre: string;
  descripcion: string;
  precio: number;
  imagenUrl?: string;
  disponible?: boolean;
  orden?: number;
}

export class CreatePlatoUseCase {
  constructor(
    private readonly platoRepository: IPlatoRepository,
    private readonly categoriaRepository: ICategoriaRepository,
    private readonly restauranteRepository: IRestauranteRepository,
    private readonly cacheService: ICacheService
  ) {}

  async execute(categoriaId: string, input: CreatePlatoInput, usuarioId: string): Promise<PlatoDTO> {
    const categoria = await this.categoriaRepository.findById(categoriaId);
    if (!categoria) {
      throw new NotFoundError('Categoria', categoriaId);
    }

    const restaurante = await this.restauranteRepository.findById(categoria.restauranteId);
    if (!restaurante) {
      throw new NotFoundError('Restaurante', categoria.restauranteId);
    }

    if (restaurante.usuarioId !== usuarioId) {
      throw new UnauthorizedError('No tienes permiso para crear platos en esta categoría');
    }

    const plato = new Plato(
      uuidv4(),
      categoriaId,
      input.nombre,
      input.descripcion,
      input.precio,
      input.imagenUrl || null,
      input.disponible ?? true,
      input.orden || 0,
      true,
      new Date(),
      new Date()
    );

    const saved = await this.platoRepository.save(plato);
    
    await this.cacheService.invalidatePattern(`menu:${restaurante.slug}*`);
    await this.cacheService.invalidatePattern(`categoria:${categoriaId}:platos`);

    return PlatoMapper.toDTO(saved);
  }
}
