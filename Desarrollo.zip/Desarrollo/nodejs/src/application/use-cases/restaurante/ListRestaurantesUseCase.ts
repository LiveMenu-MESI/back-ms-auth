import { IRestauranteRepository } from '../../../domain/repositories/IRestauranteRepository';
import { ICacheService } from '../../../domain/services/ICacheService';
import { RestauranteDTO, RestauranteMapper } from '../../dtos/RestauranteDTO';

export class ListRestaurantesUseCase {
  constructor(
    private readonly restauranteRepository: IRestauranteRepository,
    private readonly cacheService: ICacheService
  ) {}

  async execute(usuarioId: string): Promise<RestauranteDTO[]> {
    const cacheKey = `usuario:${usuarioId}:restaurantes`;
    
    const cached = await this.cacheService.get<RestauranteDTO[]>(cacheKey);
    if (cached) {
      return cached;
    }

    const restaurantes = await this.restauranteRepository.findByUsuarioId(usuarioId);
    const dtos = restaurantes.map(RestauranteMapper.toDTO);
    
    await this.cacheService.set(cacheKey, dtos, 1800); // 30 minutos

    return dtos;
  }
}
