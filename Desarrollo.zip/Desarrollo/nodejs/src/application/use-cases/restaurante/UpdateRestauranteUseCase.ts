import { IRestauranteRepository } from '../../../domain/repositories/IRestauranteRepository';
import { ICacheService } from '../../../domain/services/ICacheService';
import { NotFoundError, UnauthorizedError } from '../../../domain/errors/DomainError';
import { RestauranteDTO, RestauranteMapper } from '../../dtos/RestauranteDTO';

export interface UpdateRestauranteInput {
  nombre?: string;
  descripcion?: string;
  direccion?: string;
  telefono?: string;
  logoUrl?: string;
  horarios?: Record<string, any>;
}

export class UpdateRestauranteUseCase {
  constructor(
    private readonly restauranteRepository: IRestauranteRepository,
    private readonly cacheService: ICacheService
  ) {}

  async execute(id: string, input: UpdateRestauranteInput, usuarioId: string): Promise<RestauranteDTO> {
    const restaurante = await this.restauranteRepository.findById(id);
    if (!restaurante) {
      throw new NotFoundError('Restaurante', id);
    }

    // Verificar que el restaurante pertenece al usuario
    if (restaurante.usuarioId !== usuarioId) {
      throw new UnauthorizedError('No tienes permiso para actualizar este restaurante');
    }

    // Actualizar campos
    if (input.nombre) restaurante.nombre = input.nombre;
    if (input.descripcion !== undefined) restaurante.descripcion = input.descripcion;
    if (input.direccion) restaurante.direccion = input.direccion;
    if (input.telefono) restaurante.telefono = input.telefono;
    if (input.logoUrl !== undefined) restaurante.logoUrl = input.logoUrl;
    if (input.horarios) restaurante.horarios = input.horarios;
    
    restaurante.actualizadoEn = new Date();

    const updated = await this.restauranteRepository.update(restaurante);
    
    // Invalidar cache
    await this.cacheService.delete(`restaurante:${id}`);
    await this.cacheService.invalidatePattern(`menu:${restaurante.slug}*`);
    await this.cacheService.invalidatePattern(`usuario:${usuarioId}:restaurantes`);

    return RestauranteMapper.toDTO(updated);
  }
}
