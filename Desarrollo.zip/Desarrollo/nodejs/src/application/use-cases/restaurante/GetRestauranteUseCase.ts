import { IRestauranteRepository } from '../../../domain/repositories/IRestauranteRepository';
import { ICacheService } from '../../../domain/services/ICacheService';
import { NotFoundError } from '../../../domain/errors/DomainError';
import { RestauranteDTO, RestauranteMapper } from '../../dtos/RestauranteDTO';

export class GetRestauranteUseCase {
  constructor(
    private readonly restauranteRepository: IRestauranteRepository,
    private readonly cacheService: ICacheService
  ) {}

  async execute(id: string): Promise<RestauranteDTO> {
    const cacheKey = `restaurante:${id}`;
    
    // Intentar obtener del cache
    const cached = await this.cacheService.get<RestauranteDTO>(cacheKey);
    if (cached) {
      return cached;
    }

    const restaurante = await this.restauranteRepository.findById(id);
    if (!restaurante) {
      throw new NotFoundError('Restaurante', id);
    }

    const dto = RestauranteMapper.toDTO(restaurante);
    
    // Guardar en cache (1 hora)
    await this.cacheService.set(cacheKey, dto, 3600);

    return dto;
  }
}
