import { v4 as uuidv4 } from 'uuid';
import { Restaurante } from '../../../domain/entities/Restaurante';
import { Slug } from '../../../domain/value-objects/Slug';
import { IRestauranteRepository } from '../../../domain/repositories/IRestauranteRepository';
import { ICacheService } from '../../../domain/services/ICacheService';
import { RestauranteDTO, RestauranteMapper } from '../../dtos/RestauranteDTO';

export interface CreateRestauranteInput {
  nombre: string;
  descripcion: string;
  direccion: string;
  telefono: string;
  logoUrl?: string;
  horarios: Record<string, any>;
}

export class CreateRestauranteUseCase {
  constructor(
    private readonly restauranteRepository: IRestauranteRepository,
    private readonly cacheService: ICacheService
  ) {}

  async execute(input: CreateRestauranteInput, usuarioId: string): Promise<RestauranteDTO> {
    const slug = Slug.fromNombre(input.nombre);
    
    // Verificar que el slug no exista
    const existing = await this.restauranteRepository.findBySlug(slug.toString());
    if (existing) {
      throw new Error('Ya existe un restaurante con ese nombre');
    }

    const restaurante = new Restaurante(
      uuidv4(),
      usuarioId,
      input.nombre,
      slug,
      input.descripcion,
      input.direccion,
      input.telefono,
      input.logoUrl || null,
      input.horarios,
      true,
      new Date(),
      new Date()
    );

    const saved = await this.restauranteRepository.save(restaurante);
    
    // Invalidar cache
    await this.cacheService.invalidatePattern('restaurantes:*');
    await this.cacheService.invalidatePattern(`usuario:${usuarioId}:restaurantes`);

    return RestauranteMapper.toDTO(saved);
  }
}
