import { IRestauranteRepository } from '../../../domain/repositories/IRestauranteRepository';
import { ICacheService } from '../../../domain/services/ICacheService';
import { NotFoundError, UnauthorizedError } from '../../../domain/errors/DomainError';

export class DeleteRestauranteUseCase {
  constructor(
    private readonly restauranteRepository: IRestauranteRepository,
    private readonly cacheService: ICacheService
  ) {}

  async execute(id: string, usuarioId: string): Promise<void> {
    const restaurante = await this.restauranteRepository.findById(id);
    if (!restaurante) {
      throw new NotFoundError('Restaurante', id);
    }

    if (restaurante.usuarioId !== usuarioId) {
      throw new UnauthorizedError('No tienes permiso para eliminar este restaurante');
    }

    restaurante.desactivar();
    await this.restauranteRepository.update(restaurante);
    
    // Invalidar cache
    await this.cacheService.delete(`restaurante:${id}`);
    await this.cacheService.invalidatePattern(`menu:${restaurante.slug}*`);
    await this.cacheService.invalidatePattern(`usuario:${usuarioId}:restaurantes`);
  }
}
