import { Categoria } from '../../domain/entities/Categoria';

export interface CategoriaDTO {
  id: string;
  restauranteId: string;
  nombre: string;
  descripcion: string;
  orden: number;
  activo: boolean;
  creadoEn: string;
  actualizadoEn: string;
}

export class CategoriaMapper {
  static toDTO(categoria: Categoria): CategoriaDTO {
    return {
      id: categoria.id,
      restauranteId: categoria.restauranteId,
      nombre: categoria.nombre,
      descripcion: categoria.descripcion,
      orden: categoria.orden,
      activo: categoria.activo,
      creadoEn: categoria.creadoEn.toISOString(),
      actualizadoEn: categoria.actualizadoEn.toISOString(),
    };
  }
}
