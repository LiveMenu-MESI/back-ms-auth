import { Restaurante } from '../../domain/entities/Restaurante';

export interface RestauranteDTO {
  id: string;
  usuarioId: string;
  nombre: string;
  slug: string;
  descripcion: string;
  direccion: string;
  telefono: string;
  logoUrl: string | null;
  horarios: Record<string, any>;
  activo: boolean;
  creadoEn: string;
  actualizadoEn: string;
}

export class RestauranteMapper {
  static toDTO(restaurante: Restaurante): RestauranteDTO {
    return {
      id: restaurante.id,
      usuarioId: restaurante.usuarioId,
      nombre: restaurante.nombre,
      slug: restaurante.slug.toString(),
      descripcion: restaurante.descripcion,
      direccion: restaurante.direccion,
      telefono: restaurante.telefono,
      logoUrl: restaurante.logoUrl,
      horarios: restaurante.horarios,
      activo: restaurante.activo,
      creadoEn: restaurante.creadoEn.toISOString(),
      actualizadoEn: restaurante.actualizadoEn.toISOString(),
    };
  }
}
