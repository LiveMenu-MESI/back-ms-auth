import { Plato } from '../../domain/entities/Plato';

export interface PlatoDTO {
  id: string;
  categoriaId: string;
  nombre: string;
  descripcion: string;
  precio: number;
  imagenUrl: string | null;
  disponible: boolean;
  orden: number;
  activo: boolean;
  creadoEn: string;
  actualizadoEn: string;
}

export class PlatoMapper {
  static toDTO(plato: Plato): PlatoDTO {
    return {
      id: plato.id,
      categoriaId: plato.categoriaId,
      nombre: plato.nombre,
      descripcion: plato.descripcion,
      precio: plato.precio,
      imagenUrl: plato.imagenUrl,
      disponible: plato.disponible,
      orden: plato.orden,
      activo: plato.activo,
      creadoEn: plato.creadoEn.toISOString(),
      actualizadoEn: plato.actualizadoEn.toISOString(),
    };
  }
}
