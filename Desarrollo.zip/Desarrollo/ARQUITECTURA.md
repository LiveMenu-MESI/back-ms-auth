# LiveMenu - Arquitectura Hexagonal de Microservicios

## Visión General

Los microservicios de LiveMenu implementan **Arquitectura Hexagonal (Ports & Adapters)** para lograr:
- Separación clara entre lógica de negocio y detalles técnicos
- Testabilidad mediante inversión de dependencias
- Intercambiabilidad de adaptadores (PostgreSQL, Redis, S3)
- Independencia tecnológica por capa

## Principios Fundamentales

### 1. Domain-Driven Design (DDD)
- **Entidades**: Restaurante, Categoria, Plato con identidad única
- **Value Objects**: Slug, Horarios, Precio
- **Aggregates**: Restaurante como raíz agregada de Categorías y Platos
- **Domain Services**: Lógica que no pertenece a una entidad específica

### 2. Dependency Inversion
```
Domain (Core) ← Application ← Infrastructure
     ↑                           ↓
     └──────── Adapters ─────────┘
```

## Diagrama Arquitectura Hexagonal

```mermaid
graph TB
  subgraph "HTTP Adapter"
    API[REST API<br/>Express/Spring/Flask]
  end
    
  subgraph "Application Layer"
    UC1[RestauranteUseCase]
    UC2[CategoriaUseCase]
    UC3[PlatoUseCase]
  end
    
  subgraph "Domain Layer"
    ENT[Restaurante<br/>Categoria<br/>Plato]
    VO[ValueObjects<br/>Slug, Horarios]
    REPO[IRestauranteRepo<br/>ICategoriaRepo<br/>IPlatoRepo]
    CACHE[ICacheService]
    STORAGE[IStorageService]
  end
    
  subgraph "Infrastructure Adapters"
    PG[(PostgreSQL<br/>Repository)]
    RD[(Redis<br/>Cache)]
    S3[(S3<br/>Storage)]
  end
    
  API --> UC1
  API --> UC2
  API --> UC3
    
  UC1 --> ENT
  UC2 --> ENT
  UC3 --> ENT
    
  UC1 --> REPO
  UC1 --> CACHE
  UC1 --> STORAGE
    
  REPO -.implements.-> PG
  CACHE -.implements.-> RD
  STORAGE -.implements.-> S3
    
  PG --> DB[Database]
  RD --> REDIS[Redis Server]
  S3 --> AWS[AWS S3]
```

## Diagrama de Paquetes (Package Structure)

```mermaid
graph TB
  subgraph "src/"
    subgraph "domain/"
      D1[entities/]
      D2[value-objects/]
      D3[repositories/]
      D4[services/]
      D5[errors/]
    end
        
    subgraph "application/"
      A1[use-cases/]
      A2[dtos/]
      A3[mappers/]
    end
        
    subgraph "infrastructure/"
      I1[database/]
      I2[repositories/]
      I3[cache/]
      I4[storage/]
    end
        
    subgraph "adapters/"
      AD1[http/]
      AD2[controllers/]
      AD3[middleware/]
      AD4[validators/]
    end
        
    CONFIG[config/]
    SHARED[shared/]
  end
    
  AD1 --> A1
  AD2 --> A1
  A1 --> D1
  A1 --> D3
  A1 --> D4
  A2 --> D1
  I2 --> D3
  I3 --> D4
  I4 --> D4
    
  style D1 fill:#e1f5ff
  style D2 fill:#e1f5ff
  style D3 fill:#e1f5ff
  style D4 fill:#e1f5ff
  style D5 fill:#e1f5ff
```

### Descripción de Paquetes

#### **domain/** (Capa de Dominio)
- **entities/**: Entidades con identidad única (Restaurante, Categoria, Plato)
- **value-objects/**: Objetos inmutables sin identidad (Slug, Precio, Horarios)
- **repositories/**: Interfaces (Ports) para persistencia (IRestauranteRepository, etc.)
- **services/**: Interfaces para servicios externos (ICacheService, IStorageService)
- **errors/**: Excepciones de dominio (DomainError, NotFoundError, ValidationError)

#### **application/** (Capa de Aplicación)
- **use-cases/**: Casos de uso del negocio organizados por entidad
  - `restaurante/`: CreateRestauranteUseCase, UpdateRestauranteUseCase, etc.
  - `categoria/`: CreateCategoriaUseCase, ListCategoriasUseCase
  - `plato/`: CreatePlatoUseCase, UpdatePlatoUseCase
  - `menu/`: GetMenuBySlugUseCase (consulta pública)
- **dtos/**: Data Transfer Objects para entrada/salida
- **mappers/**: Conversión entre Domain Entities y DTOs

#### **infrastructure/** (Capa de Infraestructura)
- **database/**: Configuración de conexión (PostgresConnection, SessionFactory)
- **repositories/**: Implementaciones concretas de interfaces de dominio
  - `PostgresRestauranteRepository implements IRestauranteRepository`
- **cache/**: Implementación de servicios de cache
  - `RedisCacheService implements ICacheService`
- **storage/**: Implementación de almacenamiento
  - `S3StorageService implements IStorageService`

#### **adapters/** (Capa de Adaptadores HTTP)
- **http/**: Configuración de servidor (Express, Spring, Flask)
- **controllers/**: Controladores REST que invocan use cases
- **middleware/**: Middleware de autenticación, logs, validación
- **validators/**: Validadores de requests basados en OpenAPI spec

#### **config/**
- Configuración de servicios (database, redis, s3, logger)
- Variables de entorno
- Dependency Injection container

#### **shared/**
- Utilidades comunes
- Logger configurado
- Helpers transversales

## Diagrama de Clases (Domain Model)

```mermaid
classDiagram
  class Restaurante {
    +UUID id
    +UUID usuarioId
    +String nombre
    +Slug slug
    +String descripcion
    +String direccion
    +String telefono
    +String logoUrl
    +Horarios horarios
    +Boolean activo
    +DateTime creadoEn
    +DateTime actualizadoEn
    +actualizar(nombre, descripcion, direccion, telefono)
    +desactivar()
    +perteneceA(usuarioId) Boolean
  }
    
  class Categoria {
    +UUID id
    +UUID restauranteId
    +String nombre
    +String descripcion
    +Integer orden
    +Boolean activo
    +DateTime creadoEn
    +DateTime actualizadoEn
    +actualizar(nombre, descripcion, orden)
    +desactivar()
  }
    
  class Plato {
    +UUID id
    +UUID categoriaId
    +String nombre
    +String descripcion
    +Decimal precio
    +String imagenUrl
    +Boolean disponible
    +Integer orden
    +Boolean activo
    +DateTime creadoEn
    +DateTime actualizadoEn
    +actualizar(nombre, descripcion, precio, disponible, orden)
    +actualizarImagen(imagenUrl)
    +desactivar()
  }
    
  class Slug {
    -String value
    +fromString(value) Slug
    +fromNombre(nombre) Slug
    +toString() String
    -isValid(value) Boolean
  }
    
  class IRestauranteRepository {
    <<interface>>
    +findById(id) Restaurante
    +findBySlug(slug) Restaurante
    +findByUsuarioId(usuarioId) List~Restaurante~
    +save(restaurante) Restaurante
    +update(restaurante) Restaurante
    +delete(id)
  }
    
  class ICategoriaRepository {
    <<interface>>
    +findById(id) Categoria
    +findByRestauranteId(restauranteId) List~Categoria~
    +save(categoria) Categoria
    +update(categoria) Categoria
    +delete(id)
  }
    
  class IPlatoRepository {
    <<interface>>
    +findById(id) Plato
    +findByCategoriaId(categoriaId) List~Plato~
    +save(plato) Plato
    +update(plato) Plato
    +delete(id)
  }
    
  class ICacheService {
    <<interface>>
    +get~T~(key) T
    +set(key, value, ttl)
    +delete(key)
    +invalidatePattern(pattern)
  }
    
  class IStorageService {
    <<interface>>
    +uploadImage(file, key, contentType) String
    +deleteImage(key)
    +generateKey(prefix, filename) String
  }
    
  class CreateRestauranteUseCase {
    -IRestauranteRepository repository
    -ICacheService cacheService
    +execute(input, usuarioId) RestauranteDTO
  }
    
  class GetMenuBySlugUseCase {
    -IRestauranteRepository restauranteRepo
    -ICategoriaRepository categoriaRepo
    -IPlatoRepository platoRepo
    -ICacheService cacheService
    +execute(slug) MenuCompletoDTO
  }
    
  class PostgresRestauranteRepository {
    -PostgresConnection db
    +findById(id) Restaurante
    +findBySlug(slug) Restaurante
    +save(restaurante) Restaurante
    -mapToEntity(row) Restaurante
  }
    
  class RedisCacheService {
    -RedisClient client
    +get~T~(key) T
    +set(key, value, ttl)
    +invalidatePattern(pattern)
  }
    
  class S3StorageService {
    -S3Client client
    -String bucket
    +uploadImage(file, key, contentType) String
    +deleteImage(key)
  }
    
  class RestauranteController {
    -CreateRestauranteUseCase createUseCase
    -GetRestauranteUseCase getUseCase
    -UpdateRestauranteUseCase updateUseCase
    +create(request) Response
    +getById(id) Response
    +update(id, request) Response
  }
    
  Restaurante "1" --> "1" Slug : tiene
  Restaurante "1" --> "*" Categoria : contiene
  Categoria "1" --> "*" Plato : contiene
    
  CreateRestauranteUseCase --> IRestauranteRepository : usa
  CreateRestauranteUseCase --> ICacheService : usa
  CreateRestauranteUseCase --> Restaurante : crea
    
  GetMenuBySlugUseCase --> IRestauranteRepository : usa
  GetMenuBySlugUseCase --> ICategoriaRepository : usa
  GetMenuBySlugUseCase --> IPlatoRepository : usa
  GetMenuBySlugUseCase --> ICacheService : usa
    
  PostgresRestauranteRepository ..|> IRestauranteRepository : implements
  RedisCacheService ..|> ICacheService : implements
  S3StorageService ..|> IStorageService : implements
    
  RestauranteController --> CreateRestauranteUseCase : invoca
```

### Relaciones Entre Clases

#### **Agregación (Aggregate Root)**
- `Restaurante` es el Aggregate Root que contiene `Categorias`
- `Categoria` contiene `Platos`
- Modificaciones a Categorias/Platos deben pasar por Restaurante

#### **Composición (Value Objects)**
- `Restaurante` tiene un `Slug` (inmutable)
- `Slug` se genera automáticamente desde el nombre
- No puede existir `Slug` sin `Restaurante`

#### **Dependencia (Use Cases → Repositories)**
- Use Cases dependen de **interfaces** (Ports), no implementaciones
- Permite inyectar mocks para testing
- Implementaciones concretas se proveen en tiempo de ejecución

#### **Implementación (Adapters → Ports)**
- `PostgresRestauranteRepository` implementa `IRestauranteRepository`
- `RedisCacheService` implementa `ICacheService`
- Adaptadores pueden ser reemplazados sin cambiar Use Cases

## Convenciones de Nomenclatura

### Archivos y Clases

#### **Node.js/TypeScript**
```
Restaurante.ts                      → PascalCase para entidades
IRestauranteRepository.ts           → Prefijo I para interfaces
CreateRestauranteUseCase.ts         → Sufijo UseCase
PostgresRestauranteRepository.ts    → Prefijo con tecnología
RestauranteController.ts            → Sufijo Controller
authMiddleware.ts                   → camelCase para middleware/utils
```

#### **Java**
```
Restaurante.java                    → PascalCase para clases
RestauranteRepository.java          → Sin prefijo I (convención Java)
CreateRestauranteUseCase.java       → Sufijo UseCase
PostgresRestauranteRepositoryAdapter.java → Sufijo Adapter
RestauranteController.java          → Sufijo Controller
AuthenticationFilter.java           → Sufijo Filter
```

#### **Python**
```
restaurante.py                      → snake_case para archivos
class Restaurante                   → PascalCase para clases
class RestauranteRepository         → Sin prefijo I (protocolo/ABC)
class CreateRestauranteUseCase      → Sufijo UseCase
class PostgresRestauranteRepository → Prefijo con tecnología
class RestauranteController         → Sufijo Controller
auth_middleware.py                  → snake_case para módulos
```

### Métodos

#### **CRUD Operations**
```
findById(id)        → Lectura por ID
findBySlug(slug)    → Lectura por campo único
findAll()           → Lectura de todos
save(entity)        → Creación
update(entity)      → Actualización
delete(id)          → Eliminación (soft delete)
```

#### **Use Cases**
```
execute(input, context) → Método principal de Use Case
validate(input)         → Validación de entrada
buildEntity(data)       → Construcción de entidad
```

#### **Domain Methods**
```
actualizar(campos)      → Modificar estado
desactivar()            → Cambiar a inactivo
validar()               → Validar reglas de negocio
```

## Mapeo Tecnología-Capas

### Node.js + TypeScript
| Capa | Herramientas |
|------|-------------|
| Domain | TypeScript puro (clases, interfaces) |
| Application | TypeScript + DTOs |
| Infrastructure | pg (PostgreSQL), ioredis (Redis), @aws-sdk/client-s3 |
| Adapters | Express, express-validator, helmet, cors |
| Config | dotenv, dependency injection manual |

### Java + Spring Boot
| Capa | Herramientas |
|------|-------------|
| Domain | Java POJOs + Lombok, interfaces |
| Application | Spring @Service, DTOs |
| Infrastructure | Spring Data JPA, Lettuce (Redis), AWS SDK v2 |
| Adapters | Spring Web MVC, @RestController, Bean Validation |
| Config | Spring @Configuration, @Bean, application.yml |

### Python + Flask
| Capa | Herramientas |
|------|-------------|
| Domain | Dataclasses, Protocols/ABC |
| Application | Python puro, Marshmallow (DTOs) |
| Infrastructure | psycopg2 (PostgreSQL), redis-py, boto3 (AWS SDK) |
| Adapters | Flask Blueprints, marshmallow validation |
| Config | python-dotenv, dependency-injector |

## Capas de la Arquitectura

### 1. **Domain (Core)**
**Responsabilidad**: Lógica de negocio pura sin dependencias externas

**Componentes**:
- **Entities**: `Restaurante`, `Categoria`, `Plato` con comportamiento
- **Value Objects**: `Slug`, `Horarios`, `Precio`
- **Interfaces (Ports)**: `IRestauranteRepository`, `ICacheService`, `IStorageService`
- **Domain Services**: `SlugGenerator`, `ImageProcessor`
- **Exceptions**: `RestauranteNotFoundError`, `InvalidSlugError`

**Ejemplo (pseudocódigo)**:
```
class Restaurante {
  id: UUID
  nombre: string
  slug: Slug
  categorias: Categoria[]
  
  agregarCategoria(categoria: Categoria): void {
    validarPosicionUnica(categoria.posicion)
    this.categorias.push(categoria)
  }
}
```

### 2. **Application (Use Cases)**
**Responsabilidad**: Orquestación de casos de uso, transacciones

**Componentes**:
- **Use Cases**: `CrearRestauranteUseCase`, `ActualizarPlatoUseCase`
- **DTOs**: `RestauranteCreateDTO`, `PlatoUpdateDTO`
- **Mappers**: `RestauranteMapper.toDomain()`, `.toDTO()`

**Flujo típico**:
```
1. Recibir DTO desde HTTP adapter
2. Validar entrada
3. Mapear a entidad de dominio
4. Ejecutar lógica de negocio
5. Persistir via Repository
6. Invalidar cache
7. Retornar DTO de respuesta
```

### 3. **Infrastructure (Adapters)**
**Responsabilidad**: Implementación de interfaces de dominio

**Adaptadores**:

#### PostgreSQL Repository
```
PostgresRestauranteRepository implements IRestauranteRepository {
  findById(id: UUID): Promise<Restaurante>
  save(restaurante: Restaurante): Promise<void>
  findBySlug(slug: string): Promise<Restaurante>
}
```

#### Redis Cache
```
RedisCacheService implements ICacheService {
  get<T>(key: string): Promise<T | null>
  set(key: string, value: any, ttl: number): Promise<void>
  invalidate(pattern: string): Promise<void>
}
```

#### S3 Storage
```
S3StorageService implements IStorageService {
  uploadImage(file: Buffer, key: string): Promise<string>
  deleteImage(key: string): Promise<void>
  generatePresignedUrl(key: string): Promise<string>
}
```

### 4. **HTTP Adapter (API Layer)**
**Responsabilidad**: Exponer casos de uso via REST API

**Componentes**:
- **Controllers/Handlers**: Mapeo de HTTP request/response
- **Middleware**: Autenticación, validación, logs
- **DTOs de entrada/salida**: Coinciden con OpenAPI spec

**Stack por tecnología**:
- **Node.js**: Express + express-validator
- **Java**: Spring Boot + Bean Validation
- **Python**: Flask + marshmallow

## Flujo de Datos End-to-End

```mermaid
sequenceDiagram
    participant Client
    participant API as HTTP Controller
    participant UC as Use Case
    participant Domain as Domain Entity
    participant Cache as Redis Cache
    participant Repo as PostgreSQL Repo
    participant S3 as S3 Storage

    Client->>API: POST /restaurantes
    API->>API: Validar JWT & Body
    API->>UC: execute(createDTO)
    UC->>Domain: new Restaurante(...)
    Domain->>Domain: generar slug único
    UC->>Repo: save(restaurante)
    Repo->>Repo: INSERT INTO restaurantes
    UC->>Cache: invalidate('restaurantes:*')
    UC->>API: RestauranteDTO
    API->>Client: 201 Created

    Client->>API: GET /menu/{slug}
    API->>UC: getMenuBySlug(slug)
    UC->>Cache: get('menu:slug')
    alt Cache Hit
        Cache-->>UC: MenuCompletoDTO
    else Cache Miss
        UC->>Repo: findBySlugWithCategoriasPlatos(slug)
        Repo-->>UC: Restaurante aggregate
        UC->>Cache: set('menu:slug', data, 3600)
    end
    UC->>API: MenuCompletoDTO
    API->>Client: 200 OK

    Client->>API: POST /imagenes (multipart)
    API->>API: Validar archivo
    API->>UC: uploadImageUseCase(file)
    UC->>S3: uploadImage(buffer, key)
    S3-->>UC: imageUrl
    UC->>Repo: saveImageMetadata(...)
    UC->>API: ImagenDTO
    API->>Client: 201 Created
```

## Patrones Implementados

### 1. Repository Pattern
- Abstrae persistencia de datos
- Permite cambiar BD sin afectar dominio
- Incluye métodos específicos de dominio (no CRUD genérico)

### 2. Dependency Injection
- Inyección de dependencias en constructores
- Configuración en capa de infraestructura
- Facilita testing con mocks

### 3. Unit of Work (transacciones)
- Java: `@Transactional`
- Node.js: `pg` transactions
- Python: SQLAlchemy sessions

### 4. Cache-Aside Pattern
```
1. Intentar leer de cache
2. Si no existe (cache miss):
   a. Leer de BD
   b. Guardar en cache con TTL
3. Retornar dato
```

### 5. Command-Query Separation (CQS)
- **Commands**: Modifican estado (POST, PATCH, DELETE)
- **Queries**: Retornan datos sin modificar (GET)

## Estrategias de Cache

### Keys de Redis
```
restaurantes:{id}           → TTL 1h
menu:{slug}                 → TTL 1h
categorias:restaurante:{id} → TTL 30min
platos:categoria:{id}       → TTL 30min
```

### Invalidación
- **Write-through**: Actualizar BD y cache simultáneamente
- **Invalidation on write**: Borrar cache al modificar, lazy load en siguiente GET
- **Pattern matching**: `DEL menu:*` cuando se modifica restaurante

## Gestión de Imágenes en S3

### Convenciones de Naming
```
restaurantes/{uuid}/logo.jpg
platos/{uuid}/original.jpg
platos/{uuid}/thumbnail.jpg
platos/{uuid}/medium.jpg
platos/{uuid}/large.jpg
```

### Flujo de Upload
1. Cliente envía imagen (multipart/form-data)
2. Validar: tipo MIME, tamaño < 5MB
3. Generar UUID para imagen
4. Procesar variantes (thumbnail, medium, large)
5. Upload a S3 en paralelo
6. Guardar metadatos en tabla `imagenes`
7. Retornar URLs firmadas

## Logging y Observabilidad

### Niveles de Log
- **ERROR**: Errores inesperados, excepciones
- **WARN**: Comportamiento anómalo recuperable
- **INFO**: Eventos importantes (login, creación de recursos)
- **DEBUG**: Flujo detallado para desarrollo

### Formato Estructurado (JSON)
```json
{
  "timestamp": "2026-01-24T10:30:00Z",
  "level": "INFO",
  "service": "menu-service",
  "traceId": "abc123",
  "message": "Restaurante creado",
  "context": {
    "restauranteId": "uuid...",
    "usuarioId": "uuid..."
  }
}
```

### Herramientas sugeridas
- **Node.js**: Winston, Pino
- **Java**: Logback, SLF4J
- **Python**: Python logging (con JSON formatter)

## Seguridad

### Autenticación
- JWT en header `Authorization: Bearer <token>`
- Validación de firma y expiración
- Extracción de `usuario_id` del token

### Autorización
- Validar que usuario es propietario del restaurante
- Middleware `requireOwnership(restauranteId)`

### Validación de Entrada
- Validar schemas contra OpenAPI spec
- Sanitizar inputs (XSS, SQL injection)
- Rate limiting (Redis)

## Testing

### Pirámide de Testing
```
         /\
        /  \  E2E (Pocos)
       /────\
      / Inte-\
     / gración\  (Moderados)
    /──────────\
   /  Unitarios \  (Muchos)
  /──────────────\
```

### Unit Tests (Domain)
- Testear entidades y value objects aisladamente
- Sin dependencias externas
- Ejemplo: `Restaurante.agregarCategoria()` valida posición

### Integration Tests (Application)
- Mockear repositories, cache, storage
- Testear use cases con datos simulados

### E2E Tests
- Levantar BD en contenedor (testcontainers)
- Probar flujo completo desde HTTP hasta BD

## Variables de Entorno

```bash
# Database
DATABASE_URL=postgresql://livemenu:password@localhost:5432/livemenu

# Redis
REDIS_URL=redis://localhost:6379
REDIS_TTL=3600

# AWS S3
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=...
AWS_SECRET_ACCESS_KEY=...
S3_BUCKET_NAME=livemenu-images

# App
PORT=3000
NODE_ENV=production
LOG_LEVEL=info
JWT_SECRET=...
```

## Comandos de Desarrollo

### Node.js
```bash
npm install
npm run dev        # Desarrollo con hot-reload
npm test           # Tests unitarios
npm run test:e2e   # Tests E2E
npm run build      # Build para producción
npm start          # Ejecutar producción
```

### Java
```bash
./mvnw clean install
./mvnw spring-boot:run
./mvnw test
./mvnw package
```

### Python
```bash
pip install -r requirements.txt
flask run
pytest
gunicorn app:app
```

## Docker

### Build
```bash
docker build -t livemenu/menu-service-nodejs .
docker build -t livemenu/menu-service-java .
docker build -t livemenu/menu-service-python .
```

### Run
```bash
docker run -p 3000:3000 \
  -e DATABASE_URL=... \
  -e REDIS_URL=... \
  livemenu/menu-service-nodejs
```

## Decisiones de Diseño

### ¿Por qué Hexagonal?
- **Testabilidad**: Domain aislado, fácil de mockear adapters
- **Mantenibilidad**: Cambios en BD/cache no afectan lógica de negocio
- **Claridad**: Capas con responsabilidades bien definidas

### ¿Por qué PostgreSQL directo en vez de PostgREST?
- Mayor control sobre queries complejas
- Transacciones ACID nativas
- Joins eficientes para `MenuCompleto`
- PostgREST sigue disponible para consultas de solo lectura

### ¿Por qué Redis para cache?
- Latencia <1ms para queries frecuentes
- TTL automático
- Pattern matching para invalidación masiva
- Reduce carga en PostgreSQL

### ¿Por qué S3 para imágenes?
- Escalabilidad ilimitada
- CDN integrado (CloudFront)
- Versionado de objetos
- Lifecycle policies para archivos antiguos

## Próximos Pasos

1. **Implementar CQRS**: Separar modelos de lectura/escritura
2. **Event Sourcing**: Guardar eventos de dominio para auditoría
3. **Saga Pattern**: Transacciones distribuidas entre microservicios
4. **Circuit Breaker**: Resiliencia ante fallos de S3/Redis
5. **API Gateway**: Centralizar autenticación y rate limiting

---

**Versión**: 1.0  
**Fecha**: 24 de enero de 2026
