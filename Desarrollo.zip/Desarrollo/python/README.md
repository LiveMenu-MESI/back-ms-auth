# LiveMenu Menu Service - Python Flask

## Arquitectura Hexagonal Implementada

Microservicio Python con Flask implementando patrón Hexagonal (Ports & Adapters).

## Estructura del Proyecto

```
python/
├── src/
│   ├── domain/                        # Capa de Dominio
│   │   ├── entities/
│   │   │   ├── __init__.py
│   │   │   ├── restaurante.py
│   │   │   ├── categoria.py
│   │   │   └── plato.py
│   │   ├── value_objects/
│   │   │   ├── __init__.py
│   │   │   ├── slug.py
│   │   │   └── precio.py
│   │   ├── repositories/              # Ports (Interfaces)
│   │   │   ├── __init__.py
│   │   │   ├── restaurante_repository.py
│   │   │   ├── categoria_repository.py
│   │   │   └── plato_repository.py
│   │   ├── services/
│   │   │   ├── __init__.py
│   │   │   ├── cache_service.py
│   │   │   └── storage_service.py
│   │   └── exceptions/
│   │       ├── __init__.py
│   │       ├── domain_exception.py
│   │       ├── not_found_exception.py
│   │       └── validation_exception.py
│   │
│   ├── application/                   # Casos de Uso
│   │   ├── use_cases/
│   │   │   ├── __init__.py
│   │   │   ├── restaurante/
│   │   │   │   ├── create_restaurante_use_case.py
│   │   │   │   ├── get_restaurante_use_case.py
│   │   │   │   └── update_restaurante_use_case.py
│   │   │   ├── categoria/
│   │   │   │   └── create_categoria_use_case.py
│   │   │   └── plato/
│   │   │       └── create_plato_use_case.py
│   │   └── dtos/
│   │       ├── __init__.py
│   │       ├── restaurante_dto.py
│   │       ├── categoria_dto.py
│   │       └── plato_dto.py
│   │
│   ├── infrastructure/                # Adaptadores
│   │   ├── persistence/
│   │   │   ├── __init__.py
│   │   │   ├── models/
│   │   │   │   ├── __init__.py
│   │   │   │   ├── restaurante_model.py
│   │   │   │   ├── categoria_model.py
│   │   │   │   └── plato_model.py
│   │   │   ├── database.py
│   │   │   └── repositories/
│   │   │       ├── __init__.py
│   │   │       ├── postgres_restaurante_repository.py
│   │   │       ├── postgres_categoria_repository.py
│   │   │       └── postgres_plato_repository.py
│   │   ├── cache/
│   │   │   ├── __init__.py
│   │   │   └── redis_cache_service.py
│   │   └── storage/
│   │       ├── __init__.py
│   │       └── s3_storage_service.py
│   │
│   ├── adapters/                      # HTTP Adapter
│   │   └── http/
│   │       ├── __init__.py
│   │       ├── controllers/
│   │       │   ├── __init__.py
│   │       │   ├── restaurante_controller.py
│   │       │   ├── categoria_controller.py
│   │       │   └── plato_controller.py
│   │       ├── middleware/
│   │       │   ├── __init__.py
│   │       │   ├── auth_middleware.py
│   │       │   ├── error_handler.py
│   │       │   └── logger_middleware.py
│   │       └── validators/
│   │           ├── __init__.py
│   │           └── request_validators.py
│   │
│   ├── config/
│   │   ├── __init__.py
│   │   ├── settings.py
│   │   ├── database_config.py
│   │   ├── redis_config.py
│   │   └── s3_config.py
│   │
│   ├── shared/
│   │   ├── __init__.py
│   │   ├── logger.py
│   │   └── utils.py
│   │
│   └── app.py                         # Flask application
│
├── tests/
│   ├── unit/
│   │   ├── domain/
│   │   └── use_cases/
│   └── integration/
│
├── requirements.txt
├── requirements-dev.txt
├── Dockerfile
├── .env.example
└── README.md
```

## Instalación

```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# venv\Scripts\activate   # Windows

pip install -r requirements.txt
```

## Configuración

Archivo `.env`:

```bash
# Flask
FLASK_ENV=development
FLASK_DEBUG=True
SECRET_KEY=your-secret-key-here

# Database
DATABASE_URL=postgresql://livemenu:livemenu_pass@localhost:5432/livemenu

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_DB=0

# AWS S3
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=your-access-key
AWS_SECRET_ACCESS_KEY=your-secret-key
S3_BUCKET_NAME=livemenu-images

# JWT
JWT_SECRET=your-jwt-secret-here
JWT_EXPIRATION_HOURS=1

# Logging
LOG_LEVEL=DEBUG
LOG_FORMAT=json
```

## Ejecutar en Desarrollo

```bash
python src/app.py
# o con Flask CLI
flask run --reload
```

## Comandos Disponibles

```bash
pip install -r requirements.txt        # Instalar dependencias
python src/app.py                      # Ejecutar servidor
pytest                                 # Tests unitarios
pytest tests/integration               # Tests de integración
pylint src                             # Linter
black src                              # Formatear código
mypy src                               # Type checking
```

## Ejemplo de Implementación

### Domain Entity
```python
from dataclasses import dataclass
from datetime import datetime
from uuid import UUID
from src.domain.value_objects.slug import Slug

@dataclass
class Restaurante:
    id: UUID
    usuario_id: UUID
    nombre: str
    slug: Slug
    descripcion: str
    direccion: str
    telefono: str
    logo_url: str | None
    horarios: dict
    activo: bool
    creado_en: datetime
    actualizado_en: datetime
    
    def actualizar(self, nombre: str, descripcion: str, direccion: str, telefono: str) -> None:
        """Actualiza los datos del restaurante"""
        self.nombre = nombre
        self.descripcion = descripcion
        self.direccion = direccion
        self.telefono = telefono
        self.actualizado_en = datetime.now()
    
    def desactivar(self) -> None:
        """Desactiva el restaurante (soft delete)"""
        self.activo = False
        self.actualizado_en = datetime.now()
```

### Use Case
```python
from uuid import UUID
from src.domain.repositories.restaurante_repository import RestauranteRepository
from src.domain.services.cache_service import CacheService
from src.application.dtos.restaurante_dto import RestauranteDTO

class CreateRestauranteUseCase:
    def __init__(
        self,
        repository: RestauranteRepository,
        cache_service: CacheService
    ):
        self._repository = repository
        self._cache = cache_service
    
    def execute(self, data: dict, usuario_id: UUID) -> RestauranteDTO:
        slug = Slug.from_nombre(data['nombre'])
        
        restaurante = Restaurante(
            id=uuid4(),
            usuario_id=usuario_id,
            nombre=data['nombre'],
            slug=slug,
            descripcion=data.get('descripcion', ''),
            direccion=data.get('direccion', ''),
            telefono=data.get('telefono', ''),
            logo_url=data.get('logo_url'),
            horarios=data.get('horarios', {}),
            activo=True,
            creado_en=datetime.now(),
            actualizado_en=datetime.now()
        )
        
        self._repository.save(restaurante)
        self._cache.invalidate('restaurantes:*')
        
        return RestauranteDTO.from_entity(restaurante)
```

### Controller
```python
from flask import Blueprint, request, jsonify
from src.adapters.http.middleware.auth_middleware import require_auth
from src.application.use_cases.restaurante.create_restaurante_use_case import CreateRestauranteUseCase

restaurante_bp = Blueprint('restaurantes', __name__)

@restaurante_bp.route('/restaurantes', methods=['POST'])
@require_auth
def create_restaurante():
    """Crea un nuevo restaurante"""
    usuario_id = request.usuario_id  # Inyectado por middleware
    data = request.get_json()
    
    use_case = CreateRestauranteUseCase(
        repository=get_restaurante_repository(),
        cache_service=get_cache_service()
    )
    
    dto = use_case.execute(data, usuario_id)
    
    return jsonify(dto.to_dict()), 201
```

## Integración Redis

```python
import redis
import json
from typing import Optional, Any
from src.domain.services.cache_service import CacheService

class RedisCacheService(CacheService):
    def __init__(self, redis_client: redis.Redis):
        self._client = redis_client
    
    def get(self, key: str) -> Optional[Any]:
        """Obtiene valor del cache"""
        value = self._client.get(key)
        return json.loads(value) if value else None
    
    def set(self, key: str, value: Any, ttl: int = 3600) -> None:
        """Guarda valor en cache con TTL"""
        self._client.setex(key, ttl, json.dumps(value))
    
    def invalidate(self, pattern: str) -> None:
        """Invalida claves que coinciden con el patrón"""
        keys = self._client.keys(pattern)
        if keys:
            self._client.delete(*keys)
```

## Integración S3

```python
import boto3
from typing import BinaryIO
from src.domain.services.storage_service import StorageService

class S3StorageService(StorageService):
    def __init__(self, s3_client: boto3.client, bucket_name: str):
        self._client = s3_client
        self._bucket = bucket_name
    
    def upload_image(self, file: BinaryIO, key: str, content_type: str) -> str:
        """Sube imagen a S3"""
        self._client.upload_fileobj(
            file,
            self._bucket,
            key,
            ExtraArgs={'ContentType': content_type}
        )
        
        return f"https://{self._bucket}.s3.amazonaws.com/{key}"
    
    def delete_image(self, key: str) -> None:
        """Elimina imagen de S3"""
        self._client.delete_object(Bucket=self._bucket, Key=key)
```

## Logging

```python
import logging
import json
from datetime import datetime

class JSONFormatter(logging.Formatter):
    def format(self, record):
        log_data = {
            'timestamp': datetime.utcnow().isoformat(),
            'level': record.levelname,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName
        }
        
        if record.exc_info:
            log_data['exception'] = self.formatException(record.exc_info)
        
        return json.dumps(log_data)

# Usage in use case
logger = logging.getLogger(__name__)

class CreateRestauranteUseCase:
    def execute(self, data: dict, usuario_id: UUID) -> RestauranteDTO:
        logger.info(f"Creating restaurante: {data['nombre']}")
        
        try:
            restaurante = self._repository.save(restaurante)
            logger.info(f"Restaurante created", extra={
                'id': str(restaurante.id),
                'slug': str(restaurante.slug)
            })
            return RestauranteDTO.from_entity(restaurante)
        except Exception as e:
            logger.error(f"Error creating restaurante", exc_info=True)
            raise
```

## Docker

```bash
docker build -t livemenu/menu-service-python .
docker run -p 3000:3000 \
  --env-file .env \
  livemenu/menu-service-python
```

## Buenas Prácticas de Python Flask

### 1. **Type Hints y Dataclasses**
```python
from dataclasses import dataclass
from typing import Optional, List
from uuid import UUID

@dataclass
class Restaurante:
    id: UUID
    nombre: str
    categorias: List['Categoria'] = None
    
    def actualizar(self, nombre: str) -> None:
        self.nombre = nombre
```

### 2. **Dependency Injection con Factory Pattern**
```python
from dependency_injector import containers, providers

class Container(containers.DeclarativeContainer):
    config = providers.Configuration()
    
    database = providers.Singleton(Database, db_url=config.database_url)
    
    restaurante_repository = providers.Factory(
        PostgresRestauranteRepository,
        session=database.provided.session
    )
    
    create_restaurante_use_case = providers.Factory(
        CreateRestauranteUseCase,
        repository=restaurante_repository
    )
```

### 3. **Context Managers para Transacciones**
```python
from contextlib import contextmanager

@contextmanager
def transaction():
    """Context manager para transacciones"""
    try:
        yield
        db.session.commit()
    except Exception:
        db.session.rollback()
        raise

# Usage
with transaction():
    repository.save(restaurante)
    cache.invalidate('restaurantes:*')
```

### 4. **Decoradores para Validación**
```python
from functools import wraps
from flask import request, jsonify

def validate_schema(schema):
    """Valida request con schema"""
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            errors = schema().validate(request.get_json())
            if errors:
                return jsonify({'errors': errors}), 400
            return f(*args, **kwargs)
        return wrapper
    return decorator

@restaurante_bp.route('/restaurantes', methods=['POST'])
@validate_schema(CreateRestauranteSchema)
def create_restaurante():
    # Request ya validado
    pass
```

### 5. **Error Handling Global**
```python
from flask import Flask, jsonify

app = Flask(__name__)

@app.errorhandler(NotFoundException)
def handle_not_found(error):
    return jsonify({'error': str(error)}), 404

@app.errorhandler(ValidationException)
def handle_validation(error):
    return jsonify({'error': str(error)}), 400

@app.errorhandler(Exception)
def handle_generic_error(error):
    logger.error(f"Unhandled exception", exc_info=True)
    return jsonify({'error': 'Internal server error'}), 500
```

### 6. **Blueprints para Organización**
```python
from flask import Blueprint

# En controllers/restaurante_controller.py
restaurante_bp = Blueprint('restaurantes', __name__, url_prefix='/restaurantes')

@restaurante_bp.route('', methods=['GET'])
def list_restaurantes():
    pass

# En app.py
app.register_blueprint(restaurante_bp)
app.register_blueprint(categoria_bp)
app.register_blueprint(plato_bp)
```

### 7. **Testing con Pytest**
```python
import pytest
from src.app import create_app

@pytest.fixture
def app():
    app = create_app({'TESTING': True})
    yield app

@pytest.fixture
def client(app):
    return app.test_client()

def test_create_restaurante(client, mocker):
    mocker.patch('src.application.use_cases.create_restaurante_use_case.CreateRestauranteUseCase.execute')
    
    response = client.post('/restaurantes', json={
        'nombre': 'Test Restaurant'
    }, headers={'Authorization': 'Bearer test-token'})
    
    assert response.status_code == 201
    assert response.json['nombre'] == 'Test Restaurant'
```

### 8. **Environment Configuration**
```python
from pydantic import BaseSettings

class Settings(BaseSettings):
    database_url: str
    redis_host: str
    redis_port: int = 6379
    jwt_secret: str
    aws_region: str = 'us-east-1'
    
    class Config:
        env_file = '.env'

settings = Settings()
```

### 9. **Async Support con asyncio**
```python
from flask import Flask
import asyncio
from asgiref.wsgi import WsgiToAsgi

app = Flask(__name__)
asgi_app = WsgiToAsgi(app)

# Para operaciones async
async def upload_to_s3_async(file_data: bytes, key: str):
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, s3_client.upload, file_data, key)
    return result
```

### 10. **Logging Estructurado**
```python
import structlog

logger = structlog.get_logger()

class CreateRestauranteUseCase:
    def execute(self, data: dict, usuario_id: UUID) -> RestauranteDTO:
        logger.info("creating_restaurante", 
                   nombre=data['nombre'],
                   usuario_id=str(usuario_id))
        
        try:
            restaurante = self._repository.save(restaurante)
            logger.info("restaurante_created",
                       restaurante_id=str(restaurante.id),
                       slug=str(restaurante.slug))
            return RestauranteDTO.from_entity(restaurante)
        except Exception as e:
            logger.error("restaurante_creation_failed",
                        error=str(e),
                        exc_info=True)
            raise
```

## Recursos Adicionales

- [Flask Documentation](https://flask.palletsprojects.com/)
- [SQLAlchemy ORM](https://docs.sqlalchemy.org/)
- [Redis Python Client](https://redis-py.readthedocs.io/)
- [Boto3 (AWS SDK)](https://boto3.amazonaws.com/v1/documentation/api/latest/index.html)
- [Python Type Hints](https://docs.python.org/3/library/typing.html)

---

**Versión**: 1.0  
**Última actualización**: 24 de enero de 2026
