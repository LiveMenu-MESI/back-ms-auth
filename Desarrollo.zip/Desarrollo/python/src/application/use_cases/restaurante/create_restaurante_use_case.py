from uuid import UUID, uuid4
from datetime import datetime
from typing import Dict
from src.domain.entities.restaurante import Restaurante
from src.domain.value_objects.slug import Slug
from src.domain.repositories.restaurante_repository import RestauranteRepository
from src.domain.services.cache_service import CacheService
from src.domain.exceptions.domain_exception import ValidationException

class CreateRestauranteUseCase:
    """Caso de uso para crear un restaurante"""
    
    def __init__(
        self,
        restaurante_repository: RestauranteRepository,
        cache_service: CacheService
    ):
        self._repository = restaurante_repository
        self._cache = cache_service
    
    async def execute(self, data: Dict, usuario_id: UUID) -> Dict:
        """
        Ejecuta el caso de uso de creación de restaurante
        
        Args:
            data: Datos del restaurante a crear
            usuario_id: ID del usuario propietario
            
        Returns:
            DTO del restaurante creado
        """
        slug = Slug.from_nombre(data['nombre'])
        
        # Verificar que el slug no exista
        existing = await self._repository.find_by_slug(str(slug))
        if existing:
            raise ValidationException("Ya existe un restaurante con ese nombre")
        
        restaurante = Restaurante(
            id=uuid4(),
            usuario_id=usuario_id,
            nombre=data['nombre'],
            slug=str(slug),
            descripcion=data.get('descripcion', ''),
            direccion=data.get('direccion', ''),
            telefono=data.get('telefono', ''),
            logo_url=data.get('logo_url'),
            horarios=data.get('horarios', {}),
            activo=True,
            creado_en=datetime.now(),
            actualizado_en=datetime.now()
        )
        
        saved = await self._repository.save(restaurante)
        
        # Invalidar cache
        await self._cache.invalidate_pattern('restaurantes:*')
        await self._cache.delete(f'usuario:{usuario_id}:restaurantes')
        
        return self._to_dict(saved)
    
    def _to_dict(self, restaurante: Restaurante) -> Dict:
        """Convierte entidad a diccionario"""
        return {
            'id': str(restaurante.id),
            'usuarioId': str(restaurante.usuario_id),
            'nombre': restaurante.nombre,
            'slug': restaurante.slug,
            'descripcion': restaurante.descripcion,
            'direccion': restaurante.direccion,
            'telefono': restaurante.telefono,
            'logoUrl': restaurante.logo_url,
            'horarios': restaurante.horarios,
            'activo': restaurante.activo,
            'creadoEn': restaurante.creado_en.isoformat(),
            'actualizadoEn': restaurante.actualizado_en.isoformat()
        }
