from flask import Flask, jsonify
from src.adapters.http.controllers.restaurante_controller import restaurante_bp
import os

def create_app():
    """Factory para crear la aplicación Flask"""
    app = Flask(__name__)
    
    # Configuración
    app.config['JSON_SORT_KEYS'] = False
    
    # Registrar blueprints
    app.register_blueprint(restaurante_bp)
    
    # Health check
    @app.route('/health')
    def health():
        return jsonify({'status': 'ok', 'service': 'menu-service'}), 200
    
    # Error handler global
    @app.errorhandler(Exception)
    def handle_error(error):
        return jsonify({
            'error': 'Internal Server Error',
            'message': str(error) if os.getenv('FLASK_ENV') == 'development' else 'An error occurred'
        }), 500
    
    return app

if __name__ == '__main__':
    app = create_app()
    port = int(os.getenv('PORT', 3000))
    app.run(host='0.0.0.0', port=port, debug=os.getenv('FLASK_ENV') == 'development')
