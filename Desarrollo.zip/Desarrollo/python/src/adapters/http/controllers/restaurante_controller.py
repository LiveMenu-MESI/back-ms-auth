from flask import Blueprint, request, jsonify
from functools import wraps
from uuid import UUID
from src.application.use_cases.restaurante.create_restaurante_use_case import CreateRestauranteUseCase
from src.domain.exceptions.domain_exception import (
    NotFoundException, ValidationException, UnauthorizedException
)

restaurante_bp = Blueprint('restaurantes', __name__, url_prefix='/restaurantes')

# Dependencias (en producción usar Dependency Injection)
from src.infrastructure.persistence.database import PostgresConnection
from src.infrastructure.repositories.postgres_restaurante_repository import PostgresRestauranteRepository
from src.infrastructure.cache.redis_cache_service import RedisCacheService

db = PostgresConnection()
restaurante_repo = PostgresRestauranteRepository(db)
cache_service = RedisCacheService()

def require_auth(f):
    """Middleware de autenticación"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        auth_header = request.headers.get('Authorization')
        if not auth_header or not auth_header.startswith('Bearer '):
            raise UnauthorizedException('Token no proporcionado')
        
        # TODO: Validar JWT y extraer usuario_id
        # Por ahora simulamos el usuario_id
        request.usuario_id = UUID('12345678-1234-1234-1234-123456789012')
        
        return f(*args, **kwargs)
    return decorated_function

@restaurante_bp.route('', methods=['POST'])
@require_auth
async def create_restaurante():
    """Crea un nuevo restaurante"""
    data = request.get_json()
    
    use_case = CreateRestauranteUseCase(restaurante_repo, cache_service)
    dto = await use_case.execute(data, request.usuario_id)
    
    return jsonify(dto), 201

@restaurante_bp.errorhandler(NotFoundException)
def handle_not_found(error):
    return jsonify({'error': 'Not Found', 'message': str(error)}), 404

@restaurante_bp.errorhandler(ValidationException)
def handle_validation(error):
    return jsonify({'error': 'Validation Error', 'message': str(error)}), 400

@restaurante_bp.errorhandler(UnauthorizedException)
def handle_unauthorized(error):
    return jsonify({'error': 'Unauthorized', 'message': str(error)}), 401
