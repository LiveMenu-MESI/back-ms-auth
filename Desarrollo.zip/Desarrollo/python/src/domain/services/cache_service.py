from abc import ABC, abstractmethod
from typing import Optional, Any

class CacheService(ABC):
    """Interface del servicio de cache (Port)"""
    
    @abstractmethod
    async def get(self, key: str) -> Optional[Any]:
        pass
    
    @abstractmethod
    async def set(self, key: str, value: Any, ttl: int = 3600) -> None:
        pass
    
    @abstractmethod
    async def delete(self, key: str) -> None:
        pass
    
    @abstractmethod
    async def invalidate_pattern(self, pattern: str) -> None:
        pass
