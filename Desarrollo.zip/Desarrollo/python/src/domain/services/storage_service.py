from abc import ABC, abstractmethod

class StorageService(ABC):
    """Interface del servicio de almacenamiento (Port)"""
    
    @abstractmethod
    async def upload_image(self, file: bytes, key: str, content_type: str) -> str:
        pass
    
    @abstractmethod
    async def delete_image(self, key: str) -> None:
        pass
    
    @abstractmethod
    def generate_key(self, prefix: str, filename: str) -> str:
        pass
