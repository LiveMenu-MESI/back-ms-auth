class DomainException(Exception):
    """Excepción base del dominio"""
    pass


class NotFoundException(DomainException):
    """Excepción cuando una entidad no se encuentra"""
    
    def __init__(self, entity: str, id: str):
        super().__init__(f"{entity} with id {id} not found")
        self.entity = entity
        self.id = id


class ValidationException(DomainException):
    """Excepción de validación de negocio"""
    pass


class UnauthorizedException(DomainException):
    """Excepción de autorización"""
    
    def __init__(self, message: str = "Unauthorized"):
        super().__init__(message)
