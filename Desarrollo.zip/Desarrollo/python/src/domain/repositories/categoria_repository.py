from abc import ABC, abstractmethod
from typing import List, Optional
from uuid import UUID
from src.domain.entities.categoria import Categoria

class CategoriaRepository(ABC):
    """Interface del repositorio de Categoria (Port)"""
    
    @abstractmethod
    async def find_by_id(self, id: UUID) -> Optional[Categoria]:
        pass
    
    @abstractmethod
    async def find_by_restaurante_id(self, restaurante_id: UUID) -> List[Categoria]:
        pass
    
    @abstractmethod
    async def save(self, categoria: Categoria) -> Categoria:
        pass
    
    @abstractmethod
    async def update(self, categoria: Categoria) -> Categoria:
        pass
    
    @abstractmethod
    async def delete(self, id: UUID) -> None:
        pass
