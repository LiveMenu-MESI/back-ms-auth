from abc import ABC, abstractmethod
from typing import List, Optional
from uuid import UUID
from src.domain.entities.restaurante import Restaurante

class RestauranteRepository(ABC):
    """Interface del repositorio de Restaurante (Port)"""
    
    @abstractmethod
    async def find_by_id(self, id: UUID) -> Optional[Restaurante]:
        pass
    
    @abstractmethod
    async def find_by_slug(self, slug: str) -> Optional[Restaurante]:
        pass
    
    @abstractmethod
    async def find_by_usuario_id(self, usuario_id: UUID) -> List[Restaurante]:
        pass
    
    @abstractmethod
    async def find_all(self) -> List[Restaurante]:
        pass
    
    @abstractmethod
    async def save(self, restaurante: Restaurante) -> Restaurante:
        pass
    
    @abstractmethod
    async def update(self, restaurante: Restaurante) -> Restaurante:
        pass
    
    @abstractmethod
    async def delete(self, id: UUID) -> None:
        pass
