from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from uuid import UUID
from typing import Optional

@dataclass
class Plato:
    """Entidad de dominio Plato"""
    id: UUID
    categoria_id: UUID
    nombre: str
    descripcion: str
    precio: Decimal
    imagen_url: Optional[str]
    disponible: bool
    orden: int
    activo: bool
    creado_en: datetime
    actualizado_en: datetime
    
    def actualizar(
        self,
        nombre: str,
        descripcion: str,
        precio: Decimal,
        disponible: bool,
        orden: int
    ) -> None:
        """Actualiza los datos del plato"""
        self.nombre = nombre
        self.descripcion = descripcion
        self.precio = precio
        self.disponible = disponible
        self.orden = orden
        self.actualizado_en = datetime.now()
    
    def actualizar_imagen(self, imagen_url: str) -> None:
        """Actualiza la URL de la imagen"""
        self.imagen_url = imagen_url
        self.actualizado_en = datetime.now()
    
    def desactivar(self) -> None:
        """Desactiva el plato (soft delete)"""
        self.activo = False
        self.actualizado_en = datetime.now()
