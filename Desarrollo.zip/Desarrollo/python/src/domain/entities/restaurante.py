from dataclasses import dataclass
from datetime import datetime
from uuid import UUID
from typing import Optional

@dataclass
class Restaurante:
    """
    Entidad de dominio Restaurante
    Representa el Aggregate Root en el contexto de Menú
    """
    id: UUID
    usuario_id: UUID
    nombre: str
    slug: str
    descripcion: str
    direccion: str
    telefono: str
    logo_url: Optional[str]
    horarios: dict
    activo: bool
    creado_en: datetime
    actualizado_en: datetime
    
    def actualizar(
        self,
        nombre: str,
        descripcion: str,
        direccion: str,
        telefono: str
    ) -> None:
        """Actualiza los datos del restaurante"""
        self.nombre = nombre
        self.descripcion = descripcion
        self.direccion = direccion
        self.telefono = telefono
        self.actualizado_en = datetime.now()
    
    def desactivar(self) -> None:
        """Desactiva el restaurante (soft delete)"""
        self.activo = False
        self.actualizado_en = datetime.now()
    
    def activar(self) -> None:
        """Activa el restaurante"""
        self.activo = True
        self.actualizado_en = datetime.now()
    
    def pertenece_a(self, usuario_id: UUID) -> bool:
        """Verifica si el restaurante pertenece al usuario"""
        return self.usuario_id == usuario_id
