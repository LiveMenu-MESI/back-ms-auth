from dataclasses import dataclass
from datetime import datetime
from uuid import UUID

@dataclass
class Categoria:
    """Entidad de dominio Categoria"""
    id: UUID
    restaurante_id: UUID
    nombre: str
    descripcion: str
    orden: int
    activo: bool
    creado_en: datetime
    actualizado_en: datetime
    
    def actualizar(self, nombre: str, descripcion: str, orden: int) -> None:
        """Actualiza los datos de la categoría"""
        self.nombre = nombre
        self.descripcion = descripcion
        self.orden = orden
        self.actualizado_en = datetime.now()
    
    def desactivar(self) -> None:
        """Desactiva la categoría (soft delete)"""
        self.activo = False
        self.actualizado_en = datetime.now()
