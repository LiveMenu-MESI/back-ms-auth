import re
import unicodedata

class Slug:
    """Value Object para slug normalizado"""
    
    def __init__(self, value: str):
        if not self._is_valid(value):
            raise ValueError(f"Invalid slug format: {value}")
        self._value = value
    
    @classmethod
    def from_string(cls, value: str) -> 'Slug':
        """Crea un Slug desde un string normalizándolo"""
        normalized = cls._normalize(value)
        return cls(normalized)
    
    @classmethod
    def from_nombre(cls, nombre: str) -> 'Slug':
        """Crea un Slug desde un nombre"""
        return cls.from_string(nombre)
    
    @staticmethod
    def _normalize(input_str: str) -> str:
        """Normaliza el string a formato slug"""
        # Remove accents
        nfkd = unicodedata.normalize('NFKD', input_str)
        normalized = ''.join([c for c in nfkd if not unicodedata.combining(c)])
        
        # Convert to lowercase and replace non-alphanumeric with hyphens
        normalized = normalized.lower()
        normalized = re.sub(r'[^a-z0-9]+', '-', normalized)
        normalized = re.sub(r'^-+|-+$', '', normalized)  # Remove leading/trailing hyphens
        
        return normalized
    
    @staticmethod
    def _is_valid(value: str) -> bool:
        """Valida el formato del slug"""
        pattern = r'^[a-z0-9]+(?:-[a-z0-9]+)*$'
        return bool(re.match(pattern, value))
    
    @property
    def value(self) -> str:
        return self._value
    
    def __str__(self) -> str:
        return self._value
    
    def __eq__(self, other):
        if isinstance(other, Slug):
            return self._value == other._value
        return False
    
    def __hash__(self):
        return hash(self._value)
