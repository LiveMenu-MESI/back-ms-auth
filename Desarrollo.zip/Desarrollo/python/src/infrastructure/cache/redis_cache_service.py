import redis.asyncio as redis
import json
from typing import Optional, Any
import os
from src.domain.services.cache_service import CacheService

class RedisCacheService(CacheService):
    """Implementación Redis del servicio de cache"""
    
    def __init__(self):
        self._client = redis.Redis(
            host=os.getenv('REDIS_HOST', 'localhost'),
            port=int(os.getenv('REDIS_PORT', '6379')),
            decode_responses=True
        )
    
    async def get(self, key: str) -> Optional[Any]:
        """Obtiene valor del cache"""
        try:
            value = await self._client.get(key)
            return json.loads(value) if value else None
        except Exception as e:
            print(f"Cache get error: {e}")
            return None
    
    async def set(self, key: str, value: Any, ttl: int = 3600) -> None:
        """Guarda valor en cache con TTL"""
        try:
            await self._client.setex(key, ttl, json.dumps(value))
        except Exception as e:
            print(f"Cache set error: {e}")
    
    async def delete(self, key: str) -> None:
        """Elimina una clave del cache"""
        try:
            await self._client.delete(key)
        except Exception as e:
            print(f"Cache delete error: {e}")
    
    async def invalidate_pattern(self, pattern: str) -> None:
        """Invalida claves que coinciden con el patrón"""
        try:
            keys = await self._client.keys(pattern)
            if keys:
                await self._client.delete(*keys)
        except Exception as e:
            print(f"Cache invalidate pattern error: {e}")
    
    async def close(self):
        """Cierra la conexión"""
        await self._client.close()
