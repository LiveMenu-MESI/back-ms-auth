import boto3
from uuid import uuid4
import os
from src.domain.services.storage_service import StorageService

class S3StorageService(StorageService):
    """Implementación S3 del servicio de almacenamiento"""
    
    def __init__(self):
        self._client = boto3.client(
            's3',
            region_name=os.getenv('AWS_REGION', 'us-east-1'),
            aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
            aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY')
        )
        self._bucket = os.getenv('S3_BUCKET_NAME', 'livemenu-images')
    
    async def upload_image(self, file: bytes, key: str, content_type: str) -> str:
        """Sube imagen a S3"""
        self._client.put_object(
            Bucket=self._bucket,
            Key=key,
            Body=file,
            ContentType=content_type,
            ACL='public-read'
        )
        
        return f"https://{self._bucket}.s3.amazonaws.com/{key}"
    
    async def delete_image(self, key: str) -> None:
        """Elimina imagen de S3"""
        self._client.delete_object(
            Bucket=self._bucket,
            Key=key
        )
    
    def generate_key(self, prefix: str, filename: str) -> str:
        """Genera una clave única para el archivo"""
        ext = filename.split('.')[-1]
        unique_id = str(uuid4())
        return f"{prefix}/{unique_id}.{ext}"
