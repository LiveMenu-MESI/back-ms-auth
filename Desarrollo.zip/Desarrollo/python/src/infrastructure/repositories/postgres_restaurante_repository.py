from typing import List, Optional
from uuid import UUID
import json
from datetime import datetime
from src.domain.entities.restaurante import Restaurante
from src.domain.repositories.restaurante_repository import RestauranteRepository
from src.infrastructure.persistence.database import PostgresConnection

class PostgresRestauranteRepository(RestauranteRepository):
    """Implementación PostgreSQL del repositorio de Restaurante"""
    
    def __init__(self, db: PostgresConnection):
        self._db = db
    
    async def find_by_id(self, id: UUID) -> Optional[Restaurante]:
        conn = self._db.get_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT * FROM restaurantes 
                    WHERE id = %s AND activo = true
                    """,
                    (str(id),)
                )
                row = cursor.fetchone()
                return self._map_to_entity(row) if row else None
        finally:
            self._db.return_connection(conn)
    
    async def find_by_slug(self, slug: str) -> Optional[Restaurante]:
        conn = self._db.get_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT * FROM restaurantes 
                    WHERE slug = %s AND activo = true
                    """,
                    (slug,)
                )
                row = cursor.fetchone()
                return self._map_to_entity(row) if row else None
        finally:
            self._db.return_connection(conn)
    
    async def find_by_usuario_id(self, usuario_id: UUID) -> List[Restaurante]:
        conn = self._db.get_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT * FROM restaurantes 
                    WHERE usuario_id = %s AND activo = true
                    ORDER BY creado_en DESC
                    """,
                    (str(usuario_id),)
                )
                rows = cursor.fetchall()
                return [self._map_to_entity(row) for row in rows]
        finally:
            self._db.return_connection(conn)
    
    async def find_all(self) -> List[Restaurante]:
        conn = self._db.get_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT * FROM restaurantes 
                    WHERE activo = true
                    ORDER BY creado_en DESC
                    """
                )
                rows = cursor.fetchall()
                return [self._map_to_entity(row) for row in rows]
        finally:
            self._db.return_connection(conn)
    
    async def save(self, restaurante: Restaurante) -> Restaurante:
        conn = self._db.get_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    """
                    INSERT INTO restaurantes (
                        id, usuario_id, nombre, slug, descripcion, direccion,
                        telefono, logo_url, horarios, activo, creado_en, actualizado_en
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    RETURNING *
                    """,
                    (
                        str(restaurante.id),
                        str(restaurante.usuario_id),
                        restaurante.nombre,
                        restaurante.slug,
                        restaurante.descripcion,
                        restaurante.direccion,
                        restaurante.telefono,
                        restaurante.logo_url,
                        json.dumps(restaurante.horarios),
                        restaurante.activo,
                        restaurante.creado_en,
                        restaurante.actualizado_en
                    )
                )
                conn.commit()
                row = cursor.fetchone()
                return self._map_to_entity(row)
        finally:
            self._db.return_connection(conn)
    
    async def update(self, restaurante: Restaurante) -> Restaurante:
        conn = self._db.get_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    """
                    UPDATE restaurantes 
                    SET nombre = %s, descripcion = %s, direccion = %s, telefono = %s,
                        logo_url = %s, horarios = %s, activo = %s, actualizado_en = %s
                    WHERE id = %s
                    RETURNING *
                    """,
                    (
                        restaurante.nombre,
                        restaurante.descripcion,
                        restaurante.direccion,
                        restaurante.telefono,
                        restaurante.logo_url,
                        json.dumps(restaurante.horarios),
                        restaurante.activo,
                        restaurante.actualizado_en,
                        str(restaurante.id)
                    )
                )
                conn.commit()
                row = cursor.fetchone()
                return self._map_to_entity(row)
        finally:
            self._db.return_connection(conn)
    
    async def delete(self, id: UUID) -> None:
        conn = self._db.get_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    """
                    UPDATE restaurantes 
                    SET activo = false, actualizado_en = NOW()
                    WHERE id = %s
                    """,
                    (str(id),)
                )
                conn.commit()
        finally:
            self._db.return_connection(conn)
    
    def _map_to_entity(self, row) -> Restaurante:
        """Mapea una fila de BD a entidad de dominio"""
        horarios = row[8] if isinstance(row[8], dict) else json.loads(row[8])
        
        return Restaurante(
            id=UUID(row[0]),
            usuario_id=UUID(row[1]),
            nombre=row[2],
            slug=row[3],
            descripcion=row[4],
            direccion=row[5],
            telefono=row[6],
            logo_url=row[7],
            horarios=horarios,
            activo=row[9],
            creado_en=row[10],
            actualizado_en=row[11]
        )
