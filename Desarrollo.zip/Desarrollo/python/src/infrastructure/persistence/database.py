import psycopg2
from psycopg2.extras import RealDictCursor
from psycopg2.pool import SimpleConnectionPool
from typing import Optional
import os

class PostgresConnection:
    """Singleton para la conexión a PostgreSQL"""
    
    _instance: Optional['PostgresConnection'] = None
    _pool: Optional[SimpleConnectionPool] = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if self._pool is None:
            self._pool = SimpleConnectionPool(
                minconn=1,
                maxconn=20,
                host=os.getenv('DATABASE_HOST', 'localhost'),
                port=int(os.getenv('DATABASE_PORT', '5432')),
                database=os.getenv('DATABASE_NAME', 'livemenu'),
                user=os.getenv('DATABASE_USER', 'livemenu'),
                password=os.getenv('DATABASE_PASSWORD', 'livemenu_pass')
            )
    
    def get_connection(self):
        """Obtiene una conexión del pool"""
        return self._pool.getconn()
    
    def return_connection(self, conn):
        """Devuelve la conexión al pool"""
        self._pool.putconn(conn)
    
    def close_all(self):
        """Cierra todas las conexiones"""
        if self._pool:
            self._pool.closeall()
