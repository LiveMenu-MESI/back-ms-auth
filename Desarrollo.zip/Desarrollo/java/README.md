# LiveMenu Menu Service - Java Spring Boot

## Arquitectura Hexagonal Implementada

Microservicio Java con Spring Boot 3.x implementando patrón Hexagonal (Ports & Adapters).

## Estructura del Proyecto

```
java/
├── src/main/java/com/livemenu/menuservice/
│   ├── domain/                    # Capa de Dominio
│   │   ├── model/
│   │   │   ├── Restaurante.java
│   │   │   ├── Categoria.java
│   │   │   └── Plato.java
│   │   ├── vo/                    # Value Objects
│   │   │   ├── Slug.java
│   │   │   └── Precio.java
│   │   ├── repository/            # Ports (Interfaces)
│   │   │   ├── RestauranteRepository.java
│   │   │   ├── CategoriaRepository.java
│   │   │   └── PlatoRepository.java
│   │   ├── service/
│   │   │   ├── CacheService.java
│   │   │   └── StorageService.java
│   │   └── exception/
│   │       ├── DomainException.java
│   │       ├── NotFoundException.java
│   │       └── ValidationException.java
│   │
│   ├── application/               # Casos de Uso
│   │   ├── usecase/
│   │   │   ├── restaurante/
│   │   │   │   ├── CreateRestauranteUseCase.java
│   │   │   │   ├── GetRestauranteUseCase.java
│   │   │   │   └── UpdateRestauranteUseCase.java
│   │   │   ├── categoria/
│   │   │   │   └── CreateCategoriaUseCase.java
│   │   │   └── plato/
│   │   │       └── CreatePlatoUseCase.java
│   │   └── dto/
│   │       ├── RestauranteDTO.java
│   │       ├── CategoriaDTO.java
│   │       └── PlatoDTO.java
│   │
│   ├── infrastructure/            # Adaptadores
│   │   ├── persistence/
│   │   │   ├── jpa/
│   │   │   │   ├── entity/
│   │   │   │   │   ├── RestauranteEntity.java
│   │   │   │   │   ├── CategoriaEntity.java
│   │   │   │   │   └── PlatoEntity.java
│   │   │   │   └── JpaRestauranteRepository.java
│   │   │   └── adapter/
│   │   │       └── PostgresRestauranteRepositoryAdapter.java
│   │   ├── cache/
│   │   │   └── RedisCacheServiceAdapter.java
│   │   └── storage/
│   │       └── S3StorageServiceAdapter.java
│   │
│   ├── adapter/                   # HTTP Adapter
│   │   └── rest/
│   │       ├── controller/
│   │       │   ├── RestauranteController.java
│   │       │   ├── CategoriaController.java
│   │       │   └── PlatoController.java
│   │       ├── request/
│   │       │   ├── CreateRestauranteRequest.java
│   │       │   └── UpdateRestauranteRequest.java
│   │       ├── response/
│   │       │   └── RestauranteResponse.java
│   │       └── exception/
│   │           └── GlobalExceptionHandler.java
│   │
│   ├── config/                    # Configuración
│   │   ├── DatabaseConfig.java
│   │   ├── RedisConfig.java
│   │   ├── S3Config.java
│   │   └── SecurityConfig.java
│   │
│   └── MenuServiceApplication.java
│
├── src/main/resources/
│   ├── application.yml
│   └── logback-spring.xml
│
├── src/test/java/
│   ├── domain/
│   ├── usecase/
│   └── integration/
│
├── pom.xml
├── Dockerfile
└── README.md
```

## Instalación

```bash
./mvnw clean install
```

## Configuración

Archivo `application.yml`:

```yaml
server:
  port: 3000

spring:
  application:
    name: menu-service
  datasource:
    url: jdbc:postgresql://localhost:5432/livemenu
    username: livemenu
    password: livemenu_pass
    driver-class-name: org.postgresql.Driver
  jpa:
    hibernate:
      ddl-auto: validate
    show-sql: false
    properties:
      hibernate:
        format_sql: true
  data:
    redis:
      host: localhost
      port: 6379
      timeout: 2000ms

# AWS S3
aws:
  region: us-east-1
  s3:
    bucket: livemenu-images
  credentials:
    access-key: ${AWS_ACCESS_KEY_ID}
    secret-key: ${AWS_SECRET_ACCESS_KEY}

# JWT
jwt:
  secret: ${JWT_SECRET}
  expiration: 3600000

# Logging
logging:
  level:
    root: INFO
    com.livemenu: DEBUG
  pattern:
    console: "%d{yyyy-MM-dd HH:mm:ss} - %msg%n"
    file: "%d{yyyy-MM-dd HH:mm:ss} [%thread] %-5level %logger{36} - %msg%n"
```

## Ejecutar en Desarrollo

```bash
./mvnw spring-boot:run
```

## Comandos Disponibles

```bash
./mvnw clean install      # Compilar y empaquetar
./mvnw spring-boot:run    # Ejecutar en desarrollo
./mvnw test               # Tests unitarios
./mvnw verify             # Tests de integración
./mvnw package            # Generar JAR
```

## Ejemplo de Implementación

### Domain Entity
```java
@Getter
@AllArgsConstructor
public class Restaurante {
    private final UUID id;
    private final UUID usuarioId;
    @Setter private String nombre;
    private final Slug slug;
    @Setter private String descripcion;
    @Setter private String logoUrl;
    private final LocalDateTime creadoEn;
    @Setter private LocalDateTime actualizadoEn;
    
    public void actualizar(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.actualizadoEn = LocalDateTime.now();
    }
}
```

### Use Case
```java
@Service
@RequiredArgsConstructor
public class CreateRestauranteUseCase {
    private final RestauranteRepository repository;
    private final CacheService cacheService;
    
    @Transactional
    public RestauranteDTO execute(CreateRestauranteRequest request, UUID usuarioId) {
        Slug slug = Slug.fromNombre(request.getNombre());
        
        Restaurante restaurante = new Restaurante(
            UUID.randomUUID(),
            usuarioId,
            request.getNombre(),
            slug,
            request.getDescripcion(),
            request.getLogoUrl(),
            LocalDateTime.now(),
            LocalDateTime.now()
        );
        
        repository.save(restaurante);
        cacheService.invalidate("restaurantes:*");
        
        return RestauranteMapper.toDTO(restaurante);
    }
}
```

### Controller
```java
@RestController
@RequestMapping("/restaurantes")
@RequiredArgsConstructor
public class RestauranteController {
    private final CreateRestauranteUseCase createUseCase;
    
    @PostMapping
    public ResponseEntity<RestauranteResponse> create(
        @Valid @RequestBody CreateRestauranteRequest request,
        @AuthenticationPrincipal UserDetails user
    ) {
        UUID usuarioId = UUID.fromString(user.getUsername());
        RestauranteDTO dto = createUseCase.execute(request, usuarioId);
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(RestauranteResponse.from(dto));
    }
}
```

## Integración Redis

```java
@Service
@RequiredArgsConstructor
public class RedisCacheServiceAdapter implements CacheService {
    private final RedisTemplate<String, Object> redisTemplate;
    
    @Override
    public <T> Optional<T> get(String key, Class<T> type) {
        Object value = redisTemplate.opsForValue().get(key);
        return Optional.ofNullable(value).map(type::cast);
    }
    
    @Override
    public void set(String key, Object value, Duration ttl) {
        redisTemplate.opsForValue().set(key, value, ttl);
    }
    
    @Override
    public void invalidate(String pattern) {
        Set<String> keys = redisTemplate.keys(pattern);
        if (keys != null && !keys.isEmpty()) {
            redisTemplate.delete(keys);
        }
    }
}
```

## Integración S3

```java
@Service
@RequiredArgsConstructor
public class S3StorageServiceAdapter implements StorageService {
    private final S3Client s3Client;
    @Value("${aws.s3.bucket}") private String bucketName;
    
    @Override
    public String uploadImage(byte[] data, String key, String contentType) {
        PutObjectRequest request = PutObjectRequest.builder()
            .bucket(bucketName)
            .key(key)
            .contentType(contentType)
            .build();
        
        s3Client.putObject(request, RequestBody.fromBytes(data));
        
        return String.format("https://%s.s3.amazonaws.com/%s", bucketName, key);
    }
}
```

## Logging

```java
@Slf4j
@Service
public class CreateRestauranteUseCase {
    public RestauranteDTO execute(CreateRestauranteRequest request, UUID usuarioId) {
        log.info("Creating restaurante: {}", request.getNombre());
        
        try {
            Restaurante restaurante = // ...
            repository.save(restaurante);
            
            log.info("Restaurante created successfully", 
                Map.of("id", restaurante.getId(), "slug", restaurante.getSlug()));
            
            return RestauranteMapper.toDTO(restaurante);
        } catch (Exception e) {
            log.error("Error creating restaurante", e);
            throw new ApplicationException("Failed to create restaurante", e);
        }
    }
}
```

## Docker

```bash
docker build -t livemenu/menu-service-java .
docker run -p 3000:3000 \
  -e SPRING_DATASOURCE_URL=... \
  -e SPRING_DATA_REDIS_HOST=... \
  livemenu/menu-service-java
```

## Buenas Prácticas de Java Spring Boot

### 1. **Inmutabilidad con Lombok**
```java
@Value // Genera constructor, getters, equals, hashCode
@Builder
public class Restaurante {
    UUID id;
    String nombre;
    Slug slug;
}
```

### 2. **Validación con Bean Validation**
```java
public class CreateRestauranteRequest {
    @NotBlank
    @Size(min = 2, max = 100)
    private String nombre;
    
    @Email
    private String contacto;
    
    @Valid // Validación anidada
    private HorariosDTO horarios;
}
```

### 3. **Manejo de Transacciones**
```java
@Transactional(isolation = Isolation.READ_COMMITTED)
public void updateRestaurante(UUID id, UpdateRequest request) {
    Restaurante restaurante = repository.findById(id)
        .orElseThrow(() -> new NotFoundException("Restaurante not found"));
    restaurante.actualizar(request);
    repository.save(restaurante);
}
```

### 4. **Dependency Injection con Constructor**
```java
@Service
@RequiredArgsConstructor // Lombok genera constructor
public class CreateRestauranteUseCase {
    private final RestauranteRepository repository;
    private final CacheService cacheService;
    // No necesita @Autowired
}
```

### 5. **Exception Handling Global**
```java
@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(NotFoundException.class)
    public ResponseEntity<ErrorResponse> handleNotFound(NotFoundException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
            .body(new ErrorResponse(ex.getMessage()));
    }
}
```

### 6. **Profiles para Ambientes**
```yaml
spring:
  profiles:
    active: ${SPRING_PROFILE:dev}
---
spring:
  config:
    activate:
      on-profile: dev
  datasource:
    url: jdbc:postgresql://localhost:5432/livemenu
---
spring:
  config:
    activate:
      on-profile: prod
  datasource:
    url: ${DATABASE_URL}
```

### 7. **Testing con Spring Boot Test**
```java
@SpringBootTest
@AutoConfigureMockMvc
class RestauranteControllerTest {
    @Autowired
    private MockMvc mockMvc;
    
    @MockBean
    private CreateRestauranteUseCase createUseCase;
    
    @Test
    void shouldCreateRestaurante() throws Exception {
        when(createUseCase.execute(any(), any()))
            .thenReturn(new RestauranteDTO(...));
        
        mockMvc.perform(post("/restaurantes")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"nombre\":\"Test\"}"))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.nombre").value("Test"));
    }
}
```

### 8. **Actuator para Monitoreo**
```yaml
management:
  endpoints:
    web:
      exposure:
        include: health,metrics,info
  endpoint:
    health:
      show-details: when-authorized
```

### 9. **Retry y Circuit Breaker (Resilience4j)**
```java
@Retry(name = "s3Upload", fallbackMethod = "uploadFallback")
@CircuitBreaker(name = "s3Upload")
public String uploadImage(byte[] data, String key) {
    return s3Client.uploadImage(data, key);
}

public String uploadFallback(Exception e) {
    log.error("S3 upload failed", e);
    throw new ServiceUnavailableException("Image upload temporarily unavailable");
}
```

### 10. **Mappers con MapStruct**
```java
@Mapper(componentModel = "spring")
public interface RestauranteMapper {
    RestauranteDTO toDTO(Restaurante entity);
    Restaurante toDomain(RestauranteEntity entity);
    
    @Mapping(target = "categorias", ignore = true)
    RestauranteEntity toEntity(Restaurante domain);
}
```

## Recursos Adicionales

- [Spring Boot Reference](https://docs.spring.io/spring-boot/docs/current/reference/html/)
- [Spring Data JPA](https://spring.io/projects/spring-data-jpa)
- [Spring Data Redis](https://spring.io/projects/spring-data-redis)
- [AWS SDK for Java 2.x](https://docs.aws.amazon.com/sdk-for-java/latest/developer-guide/)

---

**Versión**: 1.0  
**Última actualización**: 24 de enero de 2026
