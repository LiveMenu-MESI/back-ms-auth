package com.livemenu.menuservice.domain.repository;

import com.livemenu.menuservice.domain.model.Restaurante;
import com.livemenu.menuservice.domain.vo.Slug;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface RestauranteRepository {
    
    Optional<Restaurante> findById(UUID id);
    
    Optional<Restaurante> findBySlug(Slug slug);
    
    List<Restaurante> findByUsuarioId(UUID usuarioId);
    
    List<Restaurante> findAll();
    
    Restaurante save(Restaurante restaurante);
    
    Restaurante update(Restaurante restaurante);
    
    void delete(UUID id);
}
