package com.livemenu.menuservice.infrastructure.persistence.jpa.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

@Entity
@Table(name = "restaurantes")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RestauranteEntity {
    
    @Id
    @Column(columnDefinition = "UUID")
    private UUID id;
    
    @Column(name = "usuario_id", columnDefinition = "UUID", nullable = false)
    private UUID usuarioId;
    
    @Column(nullable = false, length = 100)
    private String nombre;
    
    @Column(nullable = false, unique = true, length = 100)
    private String slug;
    
    @Column(columnDefinition = "TEXT")
    private String descripcion;
    
    private String direccion;
    
    private String telefono;
    
    @Column(name = "logo_url")
    private String logoUrl;
    
    @Column(columnDefinition = "jsonb")
    @Type(value = io.hypersistence.utils.hibernate.type.json.JsonBinaryType.class)
    private Map<String, Object> horarios;
    
    @Column(nullable = false)
    private Boolean activo = true;
    
    @Column(name = "creado_en", nullable = false)
    private LocalDateTime creadoEn;
    
    @Column(name = "actualizado_en", nullable = false)
    private LocalDateTime actualizadoEn;
    
    @PrePersist
    protected void onCreate() {
        creadoEn = LocalDateTime.now();
        actualizadoEn = LocalDateTime.now();
    }
    
    @PreUpdate
    protected void onUpdate() {
        actualizadoEn = LocalDateTime.now();
    }
}
