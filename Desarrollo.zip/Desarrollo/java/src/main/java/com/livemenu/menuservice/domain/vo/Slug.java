package com.livemenu.menuservice.domain.vo;

import lombok.EqualsAndHashCode;
import lombok.Getter;

import java.text.Normalizer;
import java.util.regex.Pattern;

@Getter
@EqualsAndHashCode
public class Slug {
    
    private final String value;
    private static final Pattern VALID_PATTERN = Pattern.compile("^[a-z0-9]+(?:-[a-z0-9]+)*$");
    
    private Slug(String value) {
        if (!isValid(value)) {
            throw new IllegalArgumentException("Invalid slug format: " + value);
        }
        this.value = value;
    }
    
    public static Slug fromString(String value) {
        String normalized = normalize(value);
        return new Slug(normalized);
    }
    
    public static Slug fromNombre(String nombre) {
        return fromString(nombre);
    }
    
    private static String normalize(String input) {
        // Remove accents
        String normalized = Normalizer.normalize(input, Normalizer.Form.NFD)
            .replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
        
        // Convert to lowercase and replace non-alphanumeric with hyphens
        normalized = normalized.toLowerCase()
            .replaceAll("[^a-z0-9]+", "-")
            .replaceAll("^-+|-+$", ""); // Remove leading/trailing hyphens
        
        return normalized;
    }
    
    private static boolean isValid(String value) {
        return VALID_PATTERN.matcher(value).matches();
    }
    
    @Override
    public String toString() {
        return value;
    }
}
