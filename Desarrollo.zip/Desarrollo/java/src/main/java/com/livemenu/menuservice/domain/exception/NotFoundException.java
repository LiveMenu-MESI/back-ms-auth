package com.livemenu.menuservice.domain.exception;

public class NotFoundException extends DomainException {
    
    public NotFoundException(String entity, String id) {
        super(String.format("%s with id %s not found", entity, id));
    }
}
