package com.livemenu.menuservice.domain.model;

import com.livemenu.menuservice.domain.vo.Slug;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Entidad de dominio Restaurante
 * Representa el Aggregate Root en el contexto de Menú
 */
@Getter
@AllArgsConstructor
public class Restaurante {
    
    private final UUID id;
    private final UUID usuarioId;
    
    @Setter
    private String nombre;
    
    private final Slug slug;
    
    @Setter
    private String descripcion;
    
    @Setter
    private String direccion;
    
    @Setter
    private String telefono;
    
    @Setter
    private String logoUrl;
    
    @Setter
    private String horarios; // JSON string
    
    @Setter
    private Boolean activo;
    
    private final LocalDateTime creadoEn;
    
    @Setter
    private LocalDateTime actualizadoEn;
    
    /**
     * Actualiza los datos del restaurante
     */
    public void actualizar(String nombre, String descripcion, String direccion, String telefono) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.direccion = direccion;
        this.telefono = telefono;
        this.actualizadoEn = LocalDateTime.now();
    }
    
    /**
     * Desactiva el restaurante (soft delete)
     */
    public void desactivar() {
        this.activo = false;
        this.actualizadoEn = LocalDateTime.now();
    }
    
    /**
     * Activa el restaurante
     */
    public void activar() {
        this.activo = true;
        this.actualizadoEn = LocalDateTime.now();
    }
    
    /**
     * Verifica si el restaurante pertenece al usuario
     */
    public boolean perteneceA(UUID usuarioId) {
        return this.usuarioId.equals(usuarioId);
    }
}
