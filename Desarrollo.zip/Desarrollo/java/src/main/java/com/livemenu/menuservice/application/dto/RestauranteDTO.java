package com.livemenu.menuservice.application.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RestauranteDTO {
    private UUID id;
    private UUID usuarioId;
    private String nombre;
    private String slug;
    private String descripcion;
    private String direccion;
    private String telefono;
    private String logoUrl;
    private Map<String, Object> horarios;
    private Boolean activo;
    private LocalDateTime creadoEn;
    private LocalDateTime actualizadoEn;
}
