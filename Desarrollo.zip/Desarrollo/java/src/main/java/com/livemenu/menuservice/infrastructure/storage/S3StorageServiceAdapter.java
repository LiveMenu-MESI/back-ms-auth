package com.livemenu.menuservice.infrastructure.storage;

import com.livemenu.menuservice.domain.service.StorageService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.DeleteObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class S3StorageServiceAdapter implements StorageService {
    
    private final S3Client s3Client;
    
    @Value("${aws.s3.bucket}")
    private String bucketName;
    
    @Override
    public String uploadImage(byte[] file, String key, String contentType) {
        PutObjectRequest request = PutObjectRequest.builder()
            .bucket(bucketName)
            .key(key)
            .contentType(contentType)
            .build();
        
        s3Client.putObject(request, RequestBody.fromBytes(file));
        
        return String.format("https://%s.s3.amazonaws.com/%s", bucketName, key);
    }
    
    @Override
    public void deleteImage(String key) {
        DeleteObjectRequest request = DeleteObjectRequest.builder()
            .bucket(bucketName)
            .key(key)
            .build();
        
        s3Client.deleteObject(request);
    }
    
    @Override
    public String generateKey(String prefix, String filename) {
        String ext = filename.substring(filename.lastIndexOf("."));
        return prefix + "/" + UUID.randomUUID() + ext;
    }
}
