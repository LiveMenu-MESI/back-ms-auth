package com.livemenu.menuservice.domain.exception;

public class ValidationException extends DomainException {
    
    public ValidationException(String message) {
        super(message);
    }
}
