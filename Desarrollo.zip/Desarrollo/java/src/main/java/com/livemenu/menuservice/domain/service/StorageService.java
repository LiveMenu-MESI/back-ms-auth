package com.livemenu.menuservice.domain.service;

public interface StorageService {
    
    String uploadImage(byte[] file, String key, String contentType);
    
    void deleteImage(String key);
    
    String generateKey(String prefix, String filename);
}
