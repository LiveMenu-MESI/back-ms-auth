package com.livemenu.menuservice.domain.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@AllArgsConstructor
public class Plato {
    
    private final UUID id;
    private final UUID categoriaId;
    
    @Setter
    private String nombre;
    
    @Setter
    private String descripcion;
    
    @Setter
    private BigDecimal precio;
    
    @Setter
    private String imagenUrl;
    
    @Setter
    private Boolean disponible;
    
    @Setter
    private Integer orden;
    
    @Setter
    private Boolean activo;
    
    private final LocalDateTime creadoEn;
    
    @Setter
    private LocalDateTime actualizadoEn;
    
    public void actualizar(String nombre, String descripcion, BigDecimal precio, Boolean disponible, Integer orden) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.disponible = disponible;
        this.orden = orden;
        this.actualizadoEn = LocalDateTime.now();
    }
    
    public void actualizarImagen(String imagenUrl) {
        this.imagenUrl = imagenUrl;
        this.actualizadoEn = LocalDateTime.now();
    }
    
    public void desactivar() {
        this.activo = false;
        this.actualizadoEn = LocalDateTime.now();
    }
}
