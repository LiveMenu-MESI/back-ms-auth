package com.livemenu.menuservice.infrastructure.persistence.jpa;

import com.livemenu.menuservice.infrastructure.persistence.jpa.entity.RestauranteEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface JpaRestauranteRepository extends JpaRepository<RestauranteEntity, UUID> {
    
    Optional<RestauranteEntity> findBySlug(String slug);
    
    List<RestauranteEntity> findByUsuarioIdAndActivoTrue(UUID usuarioId);
    
    List<RestauranteEntity> findByActivoTrue();
}
