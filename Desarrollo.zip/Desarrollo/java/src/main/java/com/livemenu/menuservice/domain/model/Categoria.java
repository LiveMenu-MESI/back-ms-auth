package com.livemenu.menuservice.domain.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@AllArgsConstructor
public class Categoria {
    
    private final UUID id;
    private final UUID restauranteId;
    
    @Setter
    private String nombre;
    
    @Setter
    private String descripcion;
    
    @Setter
    private Integer orden;
    
    @Setter
    private Boolean activo;
    
    private final LocalDateTime creadoEn;
    
    @Setter
    private LocalDateTime actualizadoEn;
    
    public void actualizar(String nombre, String descripcion, Integer orden) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.orden = orden;
        this.actualizadoEn = LocalDateTime.now();
    }
    
    public void desactivar() {
        this.activo = false;
        this.actualizadoEn = LocalDateTime.now();
    }
    
    public void activar() {
        this.activo = true;
        this.actualizadoEn = LocalDateTime.now();
    }
}
