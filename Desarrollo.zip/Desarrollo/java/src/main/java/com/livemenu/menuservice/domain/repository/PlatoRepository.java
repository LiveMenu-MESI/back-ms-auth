package com.livemenu.menuservice.domain.repository;

import com.livemenu.menuservice.domain.model.Plato;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface PlatoRepository {
    
    Optional<Plato> findById(UUID id);
    
    List<Plato> findByCategoriaId(UUID categoriaId);
    
    Plato save(Plato plato);
    
    Plato update(Plato plato);
    
    void delete(UUID id);
}
