package com.livemenu.menuservice.infrastructure.persistence.adapter;

import com.livemenu.menuservice.domain.model.Restaurante;
import com.livemenu.menuservice.domain.repository.RestauranteRepository;
import com.livemenu.menuservice.domain.vo.Slug;
import com.livemenu.menuservice.infrastructure.persistence.jpa.JpaRestauranteRepository;
import com.livemenu.menuservice.infrastructure.persistence.jpa.entity.RestauranteEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class PostgresRestauranteRepositoryAdapter implements RestauranteRepository {
    
    private final JpaRestauranteRepository jpaRepository;
    
    @Override
    public Optional<Restaurante> findById(UUID id) {
        return jpaRepository.findById(id)
            .map(this::toDomain);
    }
    
    @Override
    public Optional<Restaurante> findBySlug(Slug slug) {
        return jpaRepository.findBySlug(slug.toString())
            .map(this::toDomain);
    }
    
    @Override
    public List<Restaurante> findByUsuarioId(UUID usuarioId) {
        return jpaRepository.findByUsuarioIdAndActivoTrue(usuarioId).stream()
            .map(this::toDomain)
            .collect(Collectors.toList());
    }
    
    @Override
    public List<Restaurante> findAll() {
        return jpaRepository.findByActivoTrue().stream()
            .map(this::toDomain)
            .collect(Collectors.toList());
    }
    
    @Override
    public Restaurante save(Restaurante restaurante) {
        RestauranteEntity entity = toEntity(restaurante);
        RestauranteEntity saved = jpaRepository.save(entity);
        return toDomain(saved);
    }
    
    @Override
    public Restaurante update(Restaurante restaurante) {
        return save(restaurante);
    }
    
    @Override
    public void delete(UUID id) {
        jpaRepository.findById(id).ifPresent(entity -> {
            entity.setActivo(false);
            jpaRepository.save(entity);
        });
    }
    
    private Restaurante toDomain(RestauranteEntity entity) {
        return new Restaurante(
            entity.getId(),
            entity.getUsuarioId(),
            entity.getNombre(),
            Slug.fromString(entity.getSlug()),
            entity.getDescripcion(),
            entity.getDireccion(),
            entity.getTelefono(),
            entity.getLogoUrl(),
            entity.getHorarios(),
            entity.getActivo(),
            entity.getCreadoEn(),
            entity.getActualizadoEn()
        );
    }
    
    private RestauranteEntity toEntity(Restaurante domain) {
        return new RestauranteEntity(
            domain.getId(),
            domain.getUsuarioId(),
            domain.getNombre(),
            domain.getSlug().toString(),
            domain.getDescripcion(),
            domain.getDireccion(),
            domain.getTelefono(),
            domain.getLogoUrl(),
            domain.getHorarios(),
            domain.getActivo(),
            domain.getCreadoEn(),
            domain.getActualizadoEn()
        );
    }
}
