package com.livemenu.menuservice.domain.exception;

public class UnauthorizedException extends DomainException {
    
    public UnauthorizedException(String message) {
        super(message);
    }
    
    public UnauthorizedException() {
        super("Unauthorized");
    }
}
