package com.livemenu.menuservice.domain.repository;

import com.livemenu.menuservice.domain.model.Categoria;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface CategoriaRepository {
    
    Optional<Categoria> findById(UUID id);
    
    List<Categoria> findByRestauranteId(UUID restauranteId);
    
    Categoria save(Categoria categoria);
    
    Categoria update(Categoria categoria);
    
    void delete(UUID id);
}
