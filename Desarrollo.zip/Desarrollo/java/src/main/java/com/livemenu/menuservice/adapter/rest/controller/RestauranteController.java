package com.livemenu.menuservice.adapter.rest.controller;

import com.livemenu.menuservice.application.dto.RestauranteDTO;
import com.livemenu.menuservice.application.usecase.restaurante.CreateRestauranteUseCase;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.UUID;

@RestController
@RequestMapping("/restaurantes")
@RequiredArgsConstructor
public class RestauranteController {
    
    private final CreateRestauranteUseCase createRestauranteUseCase;
    
    @PostMapping
    public ResponseEntity<RestauranteDTO> create(
        @Valid @RequestBody CreateRestauranteUseCase.CreateRestauranteInput request,
        @AuthenticationPrincipal UserDetails userDetails
    ) {
        UUID usuarioId = UUID.fromString(userDetails.getUsername());
        RestauranteDTO dto = createRestauranteUseCase.execute(request, usuarioId);
        return ResponseEntity.status(HttpStatus.CREATED).body(dto);
    }
}
