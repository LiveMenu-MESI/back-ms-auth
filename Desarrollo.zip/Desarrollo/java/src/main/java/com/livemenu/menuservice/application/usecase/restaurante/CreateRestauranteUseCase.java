package com.livemenu.menuservice.application.usecase.restaurante;

import com.livemenu.menuservice.application.dto.RestauranteDTO;
import com.livemenu.menuservice.domain.exception.ValidationException;
import com.livemenu.menuservice.domain.model.Restaurante;
import com.livemenu.menuservice.domain.repository.RestauranteRepository;
import com.livemenu.menuservice.domain.service.CacheService;
import com.livemenu.menuservice.domain.vo.Slug;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class CreateRestauranteUseCase {
    
    private final RestauranteRepository restauranteRepository;
    private final CacheService cacheService;
    
    @Transactional
    public RestauranteDTO execute(CreateRestauranteInput input, UUID usuarioId) {
        Slug slug = Slug.fromNombre(input.getNombre());
        
        // Verificar que el slug no exista
        restauranteRepository.findBySlug(slug).ifPresent(r -> {
            throw new ValidationException("Ya existe un restaurante con ese nombre");
        });
        
        Restaurante restaurante = new Restaurante(
            UUID.randomUUID(),
            usuarioId,
            input.getNombre(),
            slug,
            input.getDescripcion(),
            input.getDireccion(),
            input.getTelefono(),
            input.getLogoUrl(),
            input.getHorarios(),
            true,
            LocalDateTime.now(),
            LocalDateTime.now()
        );
        
        Restaurante saved = restauranteRepository.save(restaurante);
        
        // Invalidar cache
        cacheService.invalidatePattern("restaurantes:*");
        cacheService.delete("usuario:" + usuarioId + ":restaurantes");
        
        return mapToDTO(saved);
    }
    
    private RestauranteDTO mapToDTO(Restaurante restaurante) {
        return new RestauranteDTO(
            restaurante.getId(),
            restaurante.getUsuarioId(),
            restaurante.getNombre(),
            restaurante.getSlug().toString(),
            restaurante.getDescripcion(),
            restaurante.getDireccion(),
            restaurante.getTelefono(),
            restaurante.getLogoUrl(),
            restaurante.getHorarios(),
            restaurante.getActivo(),
            restaurante.getCreadoEn(),
            restaurante.getActualizadoEn()
        );
    }
    
    @lombok.Data
    public static class CreateRestauranteInput {
        private String nombre;
        private String descripcion;
        private String direccion;
        private String telefono;
        private String logoUrl;
        private Map<String, Object> horarios;
    }
}
