#!/bin/bash

# =====================================================
# Script de Prueba Completa del Modelo de Datos
# LiveMenu Database Testing
# =====================================================

set -e  # Detener en caso de error

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuración de conexión (desde docker-compose.yml)
DB_HOST="localhost"
DB_PORT="5432"
DB_NAME="livemenu"
DB_USER="livemenu"
DB_PASSWORD="livemenu_pass"

# Directorio actual
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

echo -e "${BLUE}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   LiveMenu - Test del Modelo de Datos           ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════════════╝${NC}"
echo ""

# Función para ejecutar SQL
run_sql() {
    local sql_file=$1
    local description=$2
    
    echo -e "${YELLOW}▶ ${description}...${NC}"
    
    if [ -f "$sql_file" ]; then
        PGPASSWORD=$DB_PASSWORD psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -f "$sql_file" 2>&1 | grep -E "(ERROR|NOTICE|✅|📝)" || true
        
        if [ ${PIPESTATUS[0]} -eq 0 ]; then
            echo -e "${GREEN}✓ Completado${NC}\n"
            return 0
        else
            echo -e "${RED}✗ Error en: $sql_file${NC}\n"
            return 1
        fi
    else
        echo -e "${RED}✗ Archivo no encontrado: $sql_file${NC}\n"
        return 1
    fi
}

# Función para ejecutar consulta
run_query() {
    local query=$1
    local description=$2
    
    echo -e "${YELLOW}▶ ${description}${NC}"
    PGPASSWORD=$DB_PASSWORD psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -c "$query"
    echo ""
}

# Verificar que Docker esté corriendo
echo -e "${YELLOW}▶ Verificando Docker...${NC}"
if ! docker ps | grep -q "livemenu-postgres"; then
    echo -e "${RED}✗ El contenedor PostgreSQL no está corriendo${NC}"
    echo -e "${YELLOW}  Ejecuta: docker compose up -d${NC}\n"
    exit 1
fi
echo -e "${GREEN}✓ Docker OK${NC}\n"

# =====================================================
# PASO 1: ROLLBACK (Limpieza)
# =====================================================
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo -e "${BLUE}PASO 1: Ejecutar Rollback (Limpieza)${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
run_sql "$SCRIPT_DIR/rollback.sql" "Eliminando tablas existentes"

# =====================================================
# PASO 2: CREAR MODELO
# =====================================================
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo -e "${BLUE}PASO 2: Crear Modelo de Datos${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
run_sql "$SCRIPT_DIR/livemenu_database.sql" "Creando tablas, vistas, funciones y triggers"

# =====================================================
# PASO 3: INSERTAR DATOS DE PRUEBA
# =====================================================
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo -e "${BLUE}PASO 3: Insertar Datos de Prueba${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
run_sql "$SCRIPT_DIR/test_data.sql" "Insertando datos de ejemplo"

# =====================================================
# PASO 4: VERIFICACIONES
# =====================================================
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo -e "${BLUE}PASO 4: Verificaciones${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"

run_query "SELECT COUNT(*) as total_tablas FROM information_schema.tables WHERE table_schema = 'public' AND table_type = 'BASE TABLE';" "Conteo de tablas creadas"

run_query "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_type = 'BASE TABLE' ORDER BY table_name;" "Lista de tablas"

run_query "SELECT COUNT(*) as total_vistas FROM information_schema.views WHERE table_schema = 'public';" "Conteo de vistas"

run_query "SELECT 
    u.email, 
    u.nombre, 
    COUNT(r.id) as num_restaurantes
FROM usuarios u
LEFT JOIN restaurantes r ON r.usuario_id = u.id
GROUP BY u.email, u.nombre
ORDER BY u.email;" "Usuarios y sus restaurantes"

run_query "SELECT 
    r.nombre as restaurante,
    r.slug,
    COUNT(c.id) as num_categorias,
    COUNT(p.id) as num_platos
FROM restaurantes r
LEFT JOIN categorias c ON c.restaurante_id = r.id
LEFT JOIN platos p ON p.categoria_id = c.id AND p.eliminado_en IS NULL
GROUP BY r.nombre, r.slug
ORDER BY r.nombre;" "Resumen por restaurante"

run_query "SELECT 
    nombre,
    precio,
    precio_oferta,
    disponible,
    destacado,
    etiquetas
FROM platos 
WHERE eliminado_en IS NULL
ORDER BY nombre
LIMIT 10;" "Primeros 10 platos"

run_query "SELECT * FROM v_analytics_resumen;" "Vista de analytics resumido"

run_query "SELECT 
    tipo,
    COUNT(*) as cantidad
FROM imagenes
GROUP BY tipo;" "Conteo de imágenes por tipo"

# =====================================================
# PASO 5: PROBAR TRIGGERS
# =====================================================
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo -e "${BLUE}PASO 5: Probar Triggers${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"

echo -e "${YELLOW}▶ Probando trigger de slug automático...${NC}"
PGPASSWORD=$DB_PASSWORD psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME << EOF
INSERT INTO usuarios (email, password_hash, nombre) 
VALUES ('test@trigger.com', 'hash123', 'Test User')
RETURNING id \gset

INSERT INTO restaurantes (usuario_id, nombre, descripcion)
VALUES (:'id', 'Nuevo Restaurante Test', 'Probando generación de slug')
RETURNING slug;

DELETE FROM restaurantes WHERE slug LIKE 'nuevo-restaurante-test%';
DELETE FROM usuarios WHERE email = 'test@trigger.com';
EOF
echo -e "${GREEN}✓ Trigger de slug OK${NC}\n"

# =====================================================
# PASO 6: ROLLBACK FINAL (Opcional)
# =====================================================
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo -e "${BLUE}PASO 6: Rollback Final (Opcional)${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"

read -p "¿Deseas ejecutar el rollback final para limpiar todo? (s/N): " -n 1 -r
echo ""
if [[ $REPLY =~ ^[Ss]$ ]]; then
    run_sql "$SCRIPT_DIR/rollback.sql" "Rollback final"
    echo -e "${GREEN}✓ Base de datos limpia${NC}\n"
else
    echo -e "${YELLOW}⚠ Los datos de prueba permanecen en la base de datos${NC}\n"
fi

# =====================================================
# RESUMEN FINAL
# =====================================================
echo -e "${GREEN}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   ✅ Test Completado Exitosamente                ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${BLUE}Conexión a la base de datos:${NC}"
echo -e "  Host: ${DB_HOST}:${DB_PORT}"
echo -e "  Database: ${DB_NAME}"
echo -e "  User: ${DB_USER}"
echo ""
echo -e "${BLUE}Para conectarte manualmente:${NC}"
echo -e "  ${YELLOW}PGPASSWORD=${DB_PASSWORD} psql -h ${DB_HOST} -p ${DB_PORT} -U ${DB_USER} -d ${DB_NAME}${NC}"
echo ""
echo -e "${BLUE}Para acceder a PostgREST:${NC}"
echo -e "  ${YELLOW}curl http://localhost:3000/restaurantes${NC}"
echo ""
