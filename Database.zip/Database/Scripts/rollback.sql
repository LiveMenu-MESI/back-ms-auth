-- =====================================================
-- LiveMenu - Script de Rollback
-- Elimina todas las tablas, vistas, funciones y roles
-- =====================================================

-- Eliminar vistas
DROP VIEW IF EXISTS v_analytics_por_hora CASCADE;
DROP VIEW IF EXISTS v_analytics_resumen CASCADE;
DROP VIEW IF EXISTS v_menu_completo CASCADE;

-- Eliminar tablas (en orden inverso por dependencias)
DROP TABLE IF EXISTS eventos_escaneo CASCADE;
DROP TABLE IF EXISTS tokens_refresh CASCADE;
DROP TABLE IF EXISTS imagenes CASCADE;
DROP TABLE IF EXISTS platos CASCADE;
DROP TABLE IF EXISTS categorias CASCADE;
DROP TABLE IF EXISTS restaurantes CASCADE;
DROP TABLE IF EXISTS usuarios CASCADE;

-- Eliminar funciones
DROP FUNCTION IF EXISTS trigger_generar_slug() CASCADE;
DROP FUNCTION IF EXISTS generar_slug(TEXT) CASCADE;
DROP FUNCTION IF EXISTS update_actualizado_en() CASCADE;

-- Eliminar rol anon (solo si existe)
DO $$
BEGIN
    IF EXISTS (SELECT FROM pg_roles WHERE rolname = 'anon') THEN
        REASSIGN OWNED BY anon TO livemenu;
        DROP OWNED BY anon;
        DROP ROLE anon;
    END IF;
END$$;

-- Mensaje de confirmación
DO $$
BEGIN
    RAISE NOTICE '✅ Rollback completado: todas las tablas, vistas, funciones y roles eliminados';
END$$;
