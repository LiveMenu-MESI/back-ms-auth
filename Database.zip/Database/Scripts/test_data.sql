-- =====================================================
-- LiveMenu - Datos de Prueba
-- Inserta datos de ejemplo en todas las tablas
-- =====================================================

-- Limpiar datos existentes (opcional)
-- TRUNCATE TABLE eventos_escaneo, tokens_refresh, imagenes, platos, categorias, restaurantes, usuarios CASCADE;

DO $$
BEGIN
    RAISE NOTICE '📝 Insertando datos de prueba...';
END$$;

-- =====================================================
-- USUARIOS
-- =====================================================
INSERT INTO usuarios (id, email, password_hash, nombre, activo) VALUES
    ('11111111-1111-1111-1111-111111111111', 'juan@example.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/X4.', 'Juan Pérez', TRUE),
    ('22222222-2222-2222-2222-222222222222', 'maria@example.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/X4.', 'María García', TRUE),
    ('33333333-3333-3333-3333-333333333333', 'carlos@example.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/X4.', 'Carlos López', FALSE)
ON CONFLICT (id) DO NOTHING;

-- =====================================================
-- RESTAURANTES
-- =====================================================
INSERT INTO restaurantes (id, usuario_id, nombre, slug, descripcion, logo_url, telefono, direccion, horarios, activo) VALUES
    ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 
     '11111111-1111-1111-1111-111111111111', 
     'La Trattoria', 
     'la-trattoria',
     'Auténtica comida italiana en el corazón de la ciudad',
     'https://storage.example.com/logos/trattoria.jpg',
     '+34 912 345 678',
     'Calle Mayor 15, Madrid',
     '{"lunes": {"abre": "13:00", "cierra": "23:00"}, "martes": {"abre": "13:00", "cierra": "23:00"}, "miercoles": {"abre": "13:00", "cierra": "23:00"}, "jueves": {"abre": "13:00", "cierra": "23:00"}, "viernes": {"abre": "13:00", "cierra": "00:00"}, "sabado": {"abre": "13:00", "cierra": "00:00"}, "domingo": {"abre": "13:00", "cierra": "23:00"}}'::jsonb,
     TRUE),
    ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 
     '22222222-2222-2222-2222-222222222222', 
     'Sushi Master', 
     'sushi-master',
     'Sushi fresco y rollos gourmet',
     'https://storage.example.com/logos/sushi.jpg',
     '+34 913 456 789',
     'Calle Serrano 42, Madrid',
     '{"lunes": {"abre": "19:00", "cierra": "23:30"}, "martes": {"abre": "19:00", "cierra": "23:30"}, "miercoles": {"abre": "19:00", "cierra": "23:30"}, "jueves": {"abre": "19:00", "cierra": "23:30"}, "viernes": {"abre": "19:00", "cierra": "01:00"}, "sabado": {"abre": "13:00", "cierra": "01:00"}, "domingo": {"abre": "13:00", "cierra": "23:30"}}'::jsonb,
     TRUE),
    ('cccccccc-cccc-cccc-cccc-cccccccccccc', 
     '33333333-3333-3333-3333-333333333333', 
     'Burger House', 
     'burger-house',
     'Las mejores hamburguesas artesanales',
     NULL,
     '+34 914 567 890',
     'Calle Goya 88, Madrid',
     NULL,
     FALSE)
ON CONFLICT (id) DO NOTHING;

-- =====================================================
-- CATEGORIAS
-- =====================================================
INSERT INTO categorias (id, restaurante_id, nombre, descripcion, posicion, activa) VALUES
    -- La Trattoria
    ('ca111111-1111-1111-1111-111111111111', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Antipasti', 'Entradas italianas', 0, TRUE),
    ('ca111111-1111-1111-1111-111111111112', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Pasta', 'Pastas frescas hechas en casa', 1, TRUE),
    ('ca111111-1111-1111-1111-111111111113', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Pizza', 'Pizzas en horno de leña', 2, TRUE),
    ('ca111111-1111-1111-1111-111111111114', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Dolci', 'Postres italianos', 3, TRUE),
    -- Sushi Master
    ('ca222222-2222-2222-2222-222222222221', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'Entrantes', 'Aperitivos japoneses', 0, TRUE),
    ('ca222222-2222-2222-2222-222222222222', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'Nigiri', 'Sushi tradicional', 1, TRUE),
    ('ca222222-2222-2222-2222-222222222223', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'Rolls', 'Makis y rolls especiales', 2, TRUE),
    ('ca222222-2222-2222-2222-222222222224', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'Postres', 'Dulces japoneses', 3, TRUE)
ON CONFLICT (id) DO NOTHING;

-- =====================================================
-- PLATOS
-- =====================================================
INSERT INTO platos (categoria_id, nombre, descripcion, precio, precio_oferta, imagen_url, disponible, destacado, etiquetas, posicion, eliminado_en) VALUES
    -- Antipasti
    ('ca111111-1111-1111-1111-111111111111', 'Bruschetta al Pomodoro', 'Pan tostado con tomate fresco, albahaca y aceite de oliva', 8.50, NULL, 'https://storage.example.com/dishes/bruschetta.jpg', TRUE, TRUE, ARRAY['vegetariano'], 0, NULL),
    ('ca111111-1111-1111-1111-111111111111', 'Carpaccio di Manzo', 'Finas láminas de ternera con rúcula y parmesano', 14.90, 12.90, 'https://storage.example.com/dishes/carpaccio.jpg', TRUE, FALSE, ARRAY[]::text[], 1, NULL),
    
    -- Pasta
    ('ca111111-1111-1111-1111-111111111112', 'Spaghetti Carbonara', 'Pasta con huevo, panceta y queso pecorino', 12.50, NULL, 'https://storage.example.com/dishes/carbonara.jpg', TRUE, TRUE, ARRAY[]::text[], 0, NULL),
    ('ca111111-1111-1111-1111-111111111112', 'Penne all Arrabbiata', 'Pasta con salsa de tomate picante', 11.00, NULL, NULL, TRUE, FALSE, ARRAY['vegetariano', 'picante'], 1, NULL),
    ('ca111111-1111-1111-1111-111111111112', 'Ravioli di Ricotta', 'Raviolis rellenos de ricotta y espinacas', 13.50, NULL, 'https://storage.example.com/dishes/ravioli.jpg', FALSE, FALSE, ARRAY['vegetariano'], 2, NULL),
    
    -- Pizza
    ('ca111111-1111-1111-1111-111111111113', 'Margherita', 'Tomate, mozzarella y albahaca fresca', 10.00, NULL, 'https://storage.example.com/dishes/margherita.jpg', TRUE, TRUE, ARRAY['vegetariano'], 0, NULL),
    ('ca111111-1111-1111-1111-111111111113', 'Quattro Formaggi', 'Cuatro quesos italianos', 13.50, 11.50, 'https://storage.example.com/dishes/4formaggi.jpg', TRUE, FALSE, ARRAY['vegetariano'], 1, NULL),
    ('ca111111-1111-1111-1111-111111111113', 'Diavola', 'Tomate, mozzarella y salami picante', 12.00, NULL, NULL, TRUE, FALSE, ARRAY['picante'], 2, NULL),
    
    -- Dolci
    ('ca111111-1111-1111-1111-111111111114', 'Tiramisù', 'Postre clásico italiano con café y mascarpone', 6.50, NULL, 'https://storage.example.com/dishes/tiramisu.jpg', TRUE, TRUE, ARRAY[]::text[], 0, NULL),
    ('ca111111-1111-1111-1111-111111111114', 'Panna Cotta', 'Crema italiana con frutos rojos', 5.90, NULL, 'https://storage.example.com/dishes/pannacotta.jpg', TRUE, FALSE, ARRAY[]::text[], 1, NULL),
    
    -- Entrantes Sushi
    ('ca222222-2222-2222-2222-222222222221', 'Edamame', 'Vainas de soja al vapor con sal marina', 4.50, NULL, 'https://storage.example.com/dishes/edamame.jpg', TRUE, FALSE, ARRAY['vegano', 'sin_gluten'], 0, NULL),
    ('ca222222-2222-2222-2222-222222222221', 'Gyozas de Pollo', '6 empanadillas japonesas al vapor', 7.90, NULL, 'https://storage.example.com/dishes/gyozas.jpg', TRUE, TRUE, ARRAY[]::text[], 1, NULL),
    
    -- Nigiri
    ('ca222222-2222-2222-2222-222222222222', 'Nigiri Salmón', '2 piezas de salmón fresco', 5.50, NULL, 'https://storage.example.com/dishes/nigiri-salmon.jpg', TRUE, TRUE, ARRAY[]::text[], 0, NULL),
    ('ca222222-2222-2222-2222-222222222222', 'Nigiri Atún', '2 piezas de atún rojo', 6.50, NULL, 'https://storage.example.com/dishes/nigiri-tuna.jpg', TRUE, TRUE, ARRAY[]::text[], 1, NULL),
    ('ca222222-2222-2222-2222-222222222222', 'Nigiri Gamba', '2 piezas de gamba dulce', 5.90, NULL, NULL, FALSE, FALSE, ARRAY[]::text[], 2, NULL),
    
    -- Rolls
    ('ca222222-2222-2222-2222-222222222223', 'California Roll', '8 piezas con cangrejo, aguacate y sésamo', 11.50, 9.90, 'https://storage.example.com/dishes/california.jpg', TRUE, TRUE, ARRAY[]::text[], 0, NULL),
    ('ca222222-2222-2222-2222-222222222223', 'Spicy Tuna Roll', '8 piezas de atún picante', 12.90, NULL, 'https://storage.example.com/dishes/spicy-tuna.jpg', TRUE, FALSE, ARRAY['picante'], 1, NULL),
    ('ca222222-2222-2222-2222-222222222223', 'Veggie Roll', '8 piezas con pepino, aguacate y zanahoria', 9.50, NULL, NULL, TRUE, FALSE, ARRAY['vegetariano', 'vegano'], 2, NULL),
    
    -- Postres Sushi
    ('ca222222-2222-2222-2222-222222222224', 'Mochi', '3 piezas de helado envuelto en masa de arroz', 5.50, NULL, 'https://storage.example.com/dishes/mochi.jpg', TRUE, TRUE, ARRAY[]::text[], 0, NULL);

-- =====================================================
-- IMAGENES
-- =====================================================
-- Nota: Las imágenes se crean sin IDs específicos ya que dependen de los platos generados automáticamente
-- En producción, estas se crearían dinámicamente cuando se suben archivos

-- =====================================================
-- EVENTOS_ESCANEO
-- =====================================================
INSERT INTO eventos_escaneo (restaurante_id, timestamp, user_agent, ip_hash, referrer) VALUES
    -- Eventos La Trattoria
    ('ev111111-1111-1111-1111-111111111111', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', NOW() - INTERVAL '5 hours', 
     'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X)', 
     'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 
     NULL),
    ('ev111111-1111-1111-1111-111111111112', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', NOW() - INTERVAL '3 hours', 
     'Mozilla/5.0 (Linux; Android 13)', 
     'b3a8e0e1f9ab1bfe3a36f231f676f78bb30a519d2b21e6c530c0eee8ebb4a5d0', 
     'https://google.com'),
    ('ev111111-1111-1111-1111-111111111113', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', NOW() - INTERVAL '1 hour', 
     'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', 
     'c555a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 
     NULL),
    
    -- Eventos Sushi Master
    ('ev222222-2222-2222-2222-222222222221', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', NOW() - INTERVAL '6 hours', 
     'Mozilla/5.0 (iPad; CPU OS 16_0 like Mac OS X)', 
     'd665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 
     'https://instagram.com'),
    ('ev222222-2222-2222-2222-222222222222', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', NOW() - INTERVAL '2 hours', 
     'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)', 
     'e665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 
     NULL),
    ('ev222222-2222-2222-2222-222222222223', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', NOW() - INTERVAL '30 minutes', 
     'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)', 
     'f665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 
     'https://tripadvisor.com')
ON CONFLICT (id) DO NOTHING;

-- ===aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', NOW() - INTERVAL '5 hours', 
     'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X)', 
     'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 
     NULL),usuario_id, token_hash, expira_en, revocado) VALUES
    ('11111111-1111-1111-1111-111111111111', 
     'a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6', 
     NOW() + INTERVAL '7 days', 
     FALSE),
    ('22222222-2222-2222-2222-222222222222', 
     'z6y5x4w3v2u1t0s9r8q7p6o5n4m3l2k1j0i9h8g7f6e5d4c3b2a1', 
     NOW() + INTERVAL '7 days', 
     FALSE),
    ('11111111-1111-1111-1111-111111111111', 
     'old_token_hash_revoked_example_1234567890abcdefghijk', 
     NOW() - INTERVAL '1 day', 
     TRUE)867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 
     'https://instagram.com'),
    ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', NOW() - INTERVAL '2 hours', 
     'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)', 
     'e665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 
     NULL),
    ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', NOW() - INTERVAL '30 minutes', 
     'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)', 
     'f665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 
     'https://tripadvisor.com')
    imagenes_count INT;
    eventos_count INT;
    tokens_count INT;
BEGIN
    SELECT COUNT(*) INTO usuarios_count FROM usuarios;
    SELECT COUNT(*) INTO restaurantes_count FROM restaurantes;
    SELECT COUNT(*) INTO categorias_count FROM categorias;
    SELECT COUNT(*) INTO platos_count FROM platos WHERE eliminado_en IS NULL;
    SELECT COUNT(*) INTO imagenes_count FROM imagenes;
    SELECT COUNT(*) INTO eventos_count FROM eventos_escaneo;
    SELECT COUNT(*) INTO tokens_count FROM tokens_refresh;
    
    RAISE NOTICE '✅ Datos de prueba insertados correctamente:';
    RAISE NOTICE '   - Usuarios: %', usuarios_count;
    RAISE NOTICE '   - Restaurantes: %', restaurantes_count;
    RAISE NOTICE '   - Categorías: %', categorias_count;
    RAISE NOTICE '   - Platos: %', platos_count;
    RAISE NOTICE '   - Imágenes: %', imagenes_count;
    RAISE NOTICE '   - Eventos: %', eventos_count;
    RAISE NOTICE '   - Tokens: %', tokens_count;
END$$;
