-- =====================================================
-- LiveMenu - Script de Base de Datos PostgreSQL
-- Sistema de Gestión de Menús Digitales para Restaurantes
-- =====================================================
-- Versión: 1.0
-- Fecha: 2026-01-23
-- Base de Datos: PostgreSQL 15+
-- =====================================================

-- Conectar a la base de datos livemenu (cuando se ejecute con psql)
-- \c livemenu

-- Habilitar extensiones necesarias
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
-- Opcional para búsquedas de texto: habilitar pg_trgm si se usará el índice GIN de nombre
-- CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- =====================================================
-- ROLES Y PERMISOS (necesarios para PostgREST)
-- =====================================================
-- Rol anónimo para las rutas públicas de PostgREST
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'anon') THEN
        CREATE ROLE anon NOLOGIN;
    END IF;
END$$;

-- Permisos de lectura para rol anon sobre el esquema public
GRANT USAGE ON SCHEMA public TO anon;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO anon;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO anon;


-- =====================================================
-- LIMPIEZA (solo para desarrollo/testing)
-- =====================================================
-- DROP TABLE IF EXISTS eventos_escaneo CASCADE;
-- DROP TABLE IF EXISTS tokens_refresh CASCADE;
-- DROP TABLE IF EXISTS imagenes CASCADE;
-- DROP TABLE IF EXISTS platos CASCADE;
-- DROP TABLE IF EXISTS categorias CASCADE;
-- DROP TABLE IF EXISTS restaurantes CASCADE;
-- DROP TABLE IF EXISTS usuarios CASCADE;

-- =====================================================
-- TABLA: usuarios
-- Descripción: Almacena propietarios/administradores
-- =====================================================
CREATE TABLE IF NOT EXISTS usuarios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    nombre VARCHAR(100),
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    creado_en TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT uq_usuarios_email UNIQUE (email),
    CONSTRAINT chk_usuarios_email_format CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')
);

-- Índices
CREATE INDEX IF NOT EXISTS idx_usuarios_email ON usuarios(email);
CREATE INDEX IF NOT EXISTS idx_usuarios_activo ON usuarios(activo) WHERE activo = TRUE;

-- Comentarios
COMMENT ON TABLE usuarios IS 'Tabla de usuarios propietarios/administradores de restaurantes';
COMMENT ON COLUMN usuarios.email IS 'Email único usado para autenticación';
COMMENT ON COLUMN usuarios.password_hash IS 'Hash bcrypt de la contraseña';

-- =====================================================
-- TABLA: restaurantes
-- Descripción: Perfil del restaurante
-- =====================================================
CREATE TABLE IF NOT EXISTS restaurantes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    usuario_id UUID NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    slug VARCHAR(120) NOT NULL,
    descripcion TEXT,
    logo_url VARCHAR(500),
    telefono VARCHAR(20),
    direccion VARCHAR(255),
    horarios JSONB,
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    creado_en TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT fk_restaurantes_usuario FOREIGN KEY (usuario_id) 
        REFERENCES usuarios(id) ON DELETE CASCADE,
    CONSTRAINT uq_restaurantes_slug UNIQUE (slug),
    CONSTRAINT chk_restaurantes_nombre_length CHECK (LENGTH(nombre) >= 2 AND LENGTH(nombre) <= 100),
    CONSTRAINT chk_restaurantes_descripcion_length CHECK (descripcion IS NULL OR LENGTH(descripcion) <= 500),
    CONSTRAINT chk_restaurantes_slug_format CHECK (slug ~* '^[a-z0-9]+(-[a-z0-9]+)*$')
);

-- Índices
CREATE INDEX IF NOT EXISTS idx_restaurantes_usuario_id ON restaurantes(usuario_id);
CREATE INDEX IF NOT EXISTS idx_restaurantes_slug ON restaurantes(slug);
CREATE INDEX IF NOT EXISTS idx_restaurantes_activo ON restaurantes(activo) WHERE activo = TRUE;

-- Comentarios
COMMENT ON TABLE restaurantes IS 'Tabla de restaurantes registrados en la plataforma';
COMMENT ON COLUMN restaurantes.slug IS 'Slug único para URL amigable, generado desde el nombre';
COMMENT ON COLUMN restaurantes.horarios IS 'Horarios de atención en formato JSON';

-- =====================================================
-- TABLA: categorias
-- Descripción: Categorías para organizar el menú
-- =====================================================
CREATE TABLE IF NOT EXISTS categorias (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurante_id UUID NOT NULL,
    nombre VARCHAR(50) NOT NULL,
    descripcion TEXT,
    posicion INTEGER NOT NULL DEFAULT 0,
    activa BOOLEAN NOT NULL DEFAULT TRUE,
    creado_en TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT fk_categorias_restaurante FOREIGN KEY (restaurante_id) 
        REFERENCES restaurantes(id) ON DELETE CASCADE,
    CONSTRAINT chk_categorias_nombre_length CHECK (LENGTH(nombre) >= 2 AND LENGTH(nombre) <= 50),
    CONSTRAINT chk_categorias_posicion CHECK (posicion >= 0)
);

-- Índices
CREATE INDEX IF NOT EXISTS idx_categorias_restaurante_id ON categorias(restaurante_id);
CREATE INDEX IF NOT EXISTS idx_categorias_posicion ON categorias(restaurante_id, posicion);
CREATE INDEX IF NOT EXISTS idx_categorias_activa ON categorias(activa) WHERE activa = TRUE;

-- Comentarios
COMMENT ON TABLE categorias IS 'Categorías para organizar platos del menú';
COMMENT ON COLUMN categorias.posicion IS 'Posición para ordenamiento visual en el menú';

-- =====================================================
-- TABLA: platos
-- Descripción: Platos/productos del menú
-- =====================================================
CREATE TABLE IF NOT EXISTS platos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    categoria_id UUID NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    precio DECIMAL(10,2) NOT NULL,
    precio_oferta DECIMAL(10,2),
    imagen_url VARCHAR(500),
    disponible BOOLEAN NOT NULL DEFAULT TRUE,
    destacado BOOLEAN NOT NULL DEFAULT FALSE,
    etiquetas TEXT[] DEFAULT '{}',
    posicion INTEGER NOT NULL DEFAULT 0,
    creado_en TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    eliminado_en TIMESTAMP WITH TIME ZONE,
    
    -- Constraints
    CONSTRAINT fk_platos_categoria FOREIGN KEY (categoria_id) 
        REFERENCES categorias(id) ON DELETE CASCADE,
    CONSTRAINT chk_platos_nombre_length CHECK (LENGTH(nombre) >= 2 AND LENGTH(nombre) <= 100),
    CONSTRAINT chk_platos_descripcion_length CHECK (descripcion IS NULL OR LENGTH(descripcion) <= 300),
    CONSTRAINT chk_platos_precio_positivo CHECK (precio > 0),
    CONSTRAINT chk_platos_precio_oferta CHECK (precio_oferta IS NULL OR (precio_oferta > 0 AND precio_oferta < precio)),
    CONSTRAINT chk_platos_posicion CHECK (posicion >= 0)
);

-- Índices
CREATE INDEX IF NOT EXISTS idx_platos_categoria_id ON platos(categoria_id);
CREATE INDEX IF NOT EXISTS idx_platos_disponible ON platos(disponible) WHERE disponible = TRUE;
CREATE INDEX IF NOT EXISTS idx_platos_destacado ON platos(destacado) WHERE destacado = TRUE;
CREATE INDEX IF NOT EXISTS idx_platos_posicion ON platos(categoria_id, posicion);
CREATE INDEX IF NOT EXISTS idx_platos_no_eliminados ON platos(eliminado_en) WHERE eliminado_en IS NULL;
CREATE INDEX IF NOT EXISTS idx_platos_etiquetas ON platos USING GIN(etiquetas);

-- Comentarios
COMMENT ON TABLE platos IS 'Platos/productos del menú del restaurante';
COMMENT ON COLUMN platos.precio_oferta IS 'Precio de oferta opcional, debe ser menor al precio regular';
COMMENT ON COLUMN platos.etiquetas IS 'Array de etiquetas: vegetariano, vegano, sin_gluten, picante, etc.';
COMMENT ON COLUMN platos.eliminado_en IS 'Timestamp de soft delete, NULL si no está eliminado';

-- =====================================================
-- TABLA: imagenes
-- Descripción: Referencias a imágenes procesadas
-- Soporta: logos de restaurante e imágenes de platos
-- =====================================================
CREATE TABLE IF NOT EXISTS imagenes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurante_id UUID NOT NULL,
    plato_id UUID,
    tipo VARCHAR(20) NOT NULL,
    nombre_original VARCHAR(255) NOT NULL,
    url_thumbnail VARCHAR(500) NOT NULL,
    url_medium VARCHAR(500) NOT NULL,
    url_large VARCHAR(500) NOT NULL,
    tipo_mime VARCHAR(50) NOT NULL,
    tamanio_bytes INTEGER NOT NULL,
    creado_en TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT fk_imagenes_restaurante FOREIGN KEY (restaurante_id) 
        REFERENCES restaurantes(id) ON DELETE CASCADE,
    CONSTRAINT fk_imagenes_plato FOREIGN KEY (plato_id) 
        REFERENCES platos(id) ON DELETE CASCADE,
    CONSTRAINT chk_imagenes_tamanio CHECK (tamanio_bytes > 0 AND tamanio_bytes <= 5242880), -- 5MB máximo
    CONSTRAINT chk_imagenes_tipo_mime CHECK (tipo_mime IN ('image/jpeg', 'image/png', 'image/webp')),
    CONSTRAINT chk_imagenes_tipo CHECK (tipo IN ('logo_restaurante', 'imagen_plato')),
    -- Si es logo_restaurante, plato_id debe ser NULL; si es imagen_plato, plato_id es requerido
    CONSTRAINT chk_imagenes_tipo_plato CHECK (
        (tipo = 'logo_restaurante' AND plato_id IS NULL) OR
        (tipo = 'imagen_plato' AND plato_id IS NOT NULL)
    )
);

-- Índices
CREATE INDEX IF NOT EXISTS idx_imagenes_restaurante_id ON imagenes(restaurante_id);
CREATE INDEX IF NOT EXISTS idx_imagenes_plato_id ON imagenes(plato_id);
CREATE INDEX IF NOT EXISTS idx_imagenes_tipo ON imagenes(tipo);
CREATE INDEX IF NOT EXISTS idx_imagenes_creado_en ON imagenes(creado_en);
-- Índice para obtener logo del restaurante rápidamente
CREATE INDEX IF NOT EXISTS idx_imagenes_logo_restaurante ON imagenes(restaurante_id) 
    WHERE tipo = 'logo_restaurante';

-- Comentarios
COMMENT ON TABLE imagenes IS 'Referencias a imágenes procesadas en Object Storage (logos y platos)';
COMMENT ON COLUMN imagenes.plato_id IS 'ID del plato asociado, NULL si es logo de restaurante';
COMMENT ON COLUMN imagenes.tipo IS 'Tipo de imagen: logo_restaurante o imagen_plato';
COMMENT ON COLUMN imagenes.url_thumbnail IS 'URL de imagen en tamaño thumbnail (150x150)';
COMMENT ON COLUMN imagenes.url_medium IS 'URL de imagen en tamaño medium (400x400)';
COMMENT ON COLUMN imagenes.url_large IS 'URL de imagen en tamaño large (800x800)';

-- =====================================================
-- TABLA: eventos_escaneo
-- Descripción: Eventos de visualización para analytics
-- =====================================================
CREATE TABLE IF NOT EXISTS eventos_escaneo (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurante_id UUID NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    user_agent VARCHAR(500),
    ip_hash VARCHAR(64),
    referrer VARCHAR(500),
    
    -- Constraints
    CONSTRAINT fk_eventos_restaurante FOREIGN KEY (restaurante_id) 
        REFERENCES restaurantes(id) ON DELETE CASCADE
);

-- Índices para queries de analytics
CREATE INDEX IF NOT EXISTS idx_eventos_restaurante_id ON eventos_escaneo(restaurante_id);
CREATE INDEX IF NOT EXISTS idx_eventos_timestamp ON eventos_escaneo(timestamp);
CREATE INDEX IF NOT EXISTS idx_eventos_restaurante_timestamp ON eventos_escaneo(restaurante_id, timestamp);

-- Comentarios
COMMENT ON TABLE eventos_escaneo IS 'Eventos de visualización del menú para analytics';
COMMENT ON COLUMN eventos_escaneo.ip_hash IS 'Hash anonimizado de la IP del cliente';

-- =====================================================
-- TABLA: tokens_refresh (Opcional)
-- Descripción: Tokens de refresh para renovación de JWT
-- =====================================================
CREATE TABLE IF NOT EXISTS tokens_refresh (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    usuario_id UUID NOT NULL,
    token_hash VARCHAR(255) NOT NULL,
    expira_en TIMESTAMP WITH TIME ZONE NOT NULL,
    creado_en TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    revocado BOOLEAN NOT NULL DEFAULT FALSE,
    
    -- Constraints
    CONSTRAINT fk_tokens_usuario FOREIGN KEY (usuario_id) 
        REFERENCES usuarios(id) ON DELETE CASCADE,
    CONSTRAINT uq_tokens_token_hash UNIQUE (token_hash)
);

-- Índices
CREATE INDEX IF NOT EXISTS idx_tokens_usuario_id ON tokens_refresh(usuario_id);
CREATE INDEX IF NOT EXISTS idx_tokens_expira_en ON tokens_refresh(expira_en);
CREATE INDEX IF NOT EXISTS idx_tokens_no_revocados ON tokens_refresh(revocado) WHERE revocado = FALSE;

-- Comentarios
COMMENT ON TABLE tokens_refresh IS 'Tokens de refresh para renovación de JWT';
COMMENT ON COLUMN tokens_refresh.token_hash IS 'Hash del token de refresh para seguridad';

-- =====================================================
-- FUNCIONES Y TRIGGERS
-- =====================================================

-- Función para actualizar timestamp de actualización
CREATE OR REPLACE FUNCTION update_actualizado_en()
RETURNS TRIGGER AS $$
BEGIN
    NEW.actualizado_en = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Función para generar slug desde nombre
CREATE OR REPLACE FUNCTION generar_slug(nombre TEXT)
RETURNS TEXT AS $$
DECLARE
    slug TEXT;
    contador INTEGER := 0;
    slug_base TEXT;
    slug_final TEXT;
BEGIN
    -- Convertir a minúsculas, reemplazar espacios y caracteres especiales
    slug := LOWER(nombre);
    slug := TRANSLATE(slug, 'áéíóúàèìòùäëïöüâêîôûñç', 'aeiouaeiouaeiouaeiouanc');
    slug := REGEXP_REPLACE(slug, '[^a-z0-9\s-]', '', 'g');
    slug := REGEXP_REPLACE(slug, '\s+', '-', 'g');
    slug := REGEXP_REPLACE(slug, '-+', '-', 'g');
    slug := TRIM(BOTH '-' FROM slug);
    
    slug_base := slug;
    slug_final := slug;
    
    -- Verificar unicidad y agregar sufijo si es necesario
    WHILE EXISTS (SELECT 1 FROM restaurantes WHERE restaurantes.slug = slug_final) LOOP
        contador := contador + 1;
        slug_final := slug_base || '-' || contador;
    END LOOP;
    
    RETURN slug_final;
END;
$$ LANGUAGE plpgsql;

-- Triggers para actualizar timestamp
CREATE OR REPLACE TRIGGER trigger_usuarios_actualizado_en
    BEFORE UPDATE ON usuarios
    FOR EACH ROW
    EXECUTE FUNCTION update_actualizado_en();

CREATE OR REPLACE TRIGGER trigger_restaurantes_actualizado_en
    BEFORE UPDATE ON restaurantes
    FOR EACH ROW
    EXECUTE FUNCTION update_actualizado_en();

CREATE OR REPLACE TRIGGER trigger_categorias_actualizado_en
    BEFORE UPDATE ON categorias
    FOR EACH ROW
    EXECUTE FUNCTION update_actualizado_en();

CREATE OR REPLACE TRIGGER trigger_platos_actualizado_en
    BEFORE UPDATE ON platos
    FOR EACH ROW
    EXECUTE FUNCTION update_actualizado_en();

-- Trigger para generar slug automáticamente
CREATE OR REPLACE FUNCTION trigger_generar_slug()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.slug IS NULL OR NEW.slug = '' THEN
        NEW.slug := generar_slug(NEW.nombre);
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER trigger_restaurantes_slug
    BEFORE INSERT ON restaurantes
    FOR EACH ROW
    EXECUTE FUNCTION trigger_generar_slug();

-- =====================================================
-- VISTAS ÚTILES
-- =====================================================

-- Vista: Menú completo de un restaurante (para cache)
CREATE OR REPLACE VIEW v_menu_completo AS
SELECT 
    r.id AS restaurante_id,
    r.nombre AS restaurante_nombre,
    r.slug,
    r.descripcion AS restaurante_descripcion,
    r.logo_url,
    r.telefono,
    r.direccion,
    r.horarios,
    c.id AS categoria_id,
    c.nombre AS categoria_nombre,
    c.descripcion AS categoria_descripcion,
    c.posicion AS categoria_posicion,
    p.id AS plato_id,
    p.nombre AS plato_nombre,
    p.descripcion AS plato_descripcion,
    p.precio,
    p.precio_oferta,
    p.imagen_url AS plato_imagen_url,
    p.disponible,
    p.destacado,
    p.etiquetas,
    p.posicion AS plato_posicion
FROM restaurantes r
LEFT JOIN categorias c ON c.restaurante_id = r.id AND c.activa = TRUE
LEFT JOIN platos p ON p.categoria_id = c.id AND p.disponible = TRUE AND p.eliminado_en IS NULL
WHERE r.activo = TRUE
ORDER BY r.id, c.posicion, p.posicion;

-- Vista: Analytics resumido por restaurante
CREATE OR REPLACE VIEW v_analytics_resumen AS
SELECT 
    restaurante_id,
    COUNT(*) AS total_escaneos,
    COUNT(*) FILTER (WHERE timestamp >= CURRENT_DATE) AS escaneos_hoy,
    COUNT(*) FILTER (WHERE timestamp >= CURRENT_DATE - INTERVAL '7 days') AS escaneos_semana,
    COUNT(*) FILTER (WHERE timestamp >= CURRENT_DATE - INTERVAL '30 days') AS escaneos_mes,
    MIN(timestamp) AS primer_escaneo,
    MAX(timestamp) AS ultimo_escaneo
FROM eventos_escaneo
GROUP BY restaurante_id;

-- Vista: Distribución de escaneos por hora
CREATE OR REPLACE VIEW v_analytics_por_hora AS
SELECT 
    restaurante_id,
    EXTRACT(HOUR FROM timestamp) AS hora,
    COUNT(*) AS cantidad
FROM eventos_escaneo
WHERE timestamp >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY restaurante_id, EXTRACT(HOUR FROM timestamp)
ORDER BY restaurante_id, hora;

-- =====================================================
-- DATOS DE EJEMPLO (Opcional - para desarrollo)
-- =====================================================

-- Insertar usuario de ejemplo
-- INSERT INTO usuarios (email, password_hash, nombre) VALUES
-- ('admin@livemenu.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/X4.', 'Admin Demo');

-- =====================================================
-- PERMISOS (Ajustar según ambiente)
-- =====================================================

-- Crear rol para la aplicación
-- CREATE ROLE livemenu_app WITH LOGIN PASSWORD 'secure_password';
-- GRANT CONNECT ON DATABASE livemenu TO livemenu_app;
-- GRANT USAGE ON SCHEMA public TO livemenu_app;
-- GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO livemenu_app;
-- GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO livemenu_app;

-- =====================================================
-- ÍNDICES ADICIONALES PARA PERFORMANCE
-- =====================================================

-- Índice para búsqueda de texto en platos (requiere pg_trgm)
-- Descomentar la extensión al inicio del script y este índice si se necesita búsqueda de texto
-- CREATE INDEX IF NOT EXISTS idx_platos_nombre_trgm ON platos USING GIN (nombre gin_trgm_ops);

-- =====================================================
-- POLÍTICAS DE RETENCIÓN (Opcional)
-- =====================================================

-- Para limpiar eventos antiguos (ejecutar periódicamente)
-- DELETE FROM eventos_escaneo WHERE timestamp < CURRENT_DATE - INTERVAL '1 year';

-- =====================================================
-- FIN DEL SCRIPT
-- =====================================================
