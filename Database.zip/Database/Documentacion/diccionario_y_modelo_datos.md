# LiveMenu - Diccionario y Modelo de Datos

## Información General

**Sistema:** LiveMenu - Gestión de Menús Digitales para Restaurantes  
**Versión:** 1.0  
**Fecha:** 23 de enero de 2026  
**Base de Datos:** PostgreSQL 15+  
**Extensiones:** pgcrypto (para generación de UUIDs)

---

## 1. DICCIONARIO DE DATOS

### 1.1. Tabla: `usuarios`

**Descripción:** Almacena usuarios propietarios/administradores de restaurantes.

| Campo | Tipo | Nulo | Defecto | Descripción |
|-------|------|------|---------|-------------|
| `id` | UUID | NO | gen_random_uuid() | Identificador único del usuario |
| `email` | VARCHAR(255) | NO | - | Email único usado para autenticación |
| `password_hash` | VARCHAR(255) | NO | - | Hash bcrypt de la contraseña |
| `nombre` | VARCHAR(100) | SI | - | Nombre completo del usuario |
| `activo` | BOOLEAN | NO | TRUE | Estado del usuario (activo/inactivo) |
| `creado_en` | TIMESTAMP WITH TIME ZONE | NO | CURRENT_TIMESTAMP | Fecha de creación del registro |
| `actualizado_en` | TIMESTAMP WITH TIME ZONE | NO | CURRENT_TIMESTAMP | Fecha de última actualización |

**Constraints:**
- `PRIMARY KEY`: id
- `UNIQUE`: email
- `CHECK`: email debe tener formato válido (regex)

**Índices:**
- `idx_usuarios_email`: email
- `idx_usuarios_activo`: activo (WHERE activo = TRUE)

---

### 1.2. Tabla: `restaurantes`

**Descripción:** Perfil completo de cada restaurante registrado en la plataforma.

| Campo | Tipo | Nulo | Defecto | Descripción |
|-------|------|------|---------|-------------|
| `id` | UUID | NO | gen_random_uuid() | Identificador único del restaurante |
| `usuario_id` | UUID | NO | - | FK a usuarios (propietario) |
| `nombre` | VARCHAR(100) | NO | - | Nombre del restaurante |
| `slug` | VARCHAR(120) | NO | - | URL amigable generada desde el nombre |
| `descripcion` | TEXT | SI | - | Descripción breve del restaurante (max 500 chars) |
| `logo_url` | VARCHAR(500) | SI | - | URL del logo del restaurante |
| `telefono` | VARCHAR(20) | SI | - | Teléfono de contacto |
| `direccion` | VARCHAR(255) | SI | - | Dirección física |
| `horarios` | JSONB | SI | - | Horarios de atención en formato JSON |
| `activo` | BOOLEAN | NO | TRUE | Estado del restaurante |
| `creado_en` | TIMESTAMP WITH TIME ZONE | NO | CURRENT_TIMESTAMP | Fecha de creación |
| `actualizado_en` | TIMESTAMP WITH TIME ZONE | NO | CURRENT_TIMESTAMP | Fecha de última actualización |

**Constraints:**
- `PRIMARY KEY`: id
- `FOREIGN KEY`: usuario_id → usuarios(id) ON DELETE CASCADE
- `UNIQUE`: slug
- `CHECK`: nombre entre 2 y 100 caracteres
- `CHECK`: descripcion máximo 500 caracteres
- `CHECK`: slug formato válido (solo letras minúsculas, números y guiones)

**Índices:**
- `idx_restaurantes_usuario_id`: usuario_id
- `idx_restaurantes_slug`: slug
- `idx_restaurantes_activo`: activo (WHERE activo = TRUE)

**Formato JSONB horarios:**
```json
{
  "lunes": {"abre": "13:00", "cierra": "23:00"},
  "martes": {"abre": "13:00", "cierra": "23:00"},
  "miercoles": {"abre": "13:00", "cierra": "23:00"},
  "jueves": {"abre": "13:00", "cierra": "23:00"},
  "viernes": {"abre": "13:00", "cierra": "00:00"},
  "sabado": {"abre": "13:00", "cierra": "00:00"},
  "domingo": {"abre": "13:00", "cierra": "23:00"}
}
```

---

### 1.3. Tabla: `categorias`

**Descripción:** Categorías para organizar los platos del menú (Entradas, Principales, Postres, etc.).

| Campo | Tipo | Nulo | Defecto | Descripción |
|-------|------|------|---------|-------------|
| `id` | UUID | NO | gen_random_uuid() | Identificador único de la categoría |
| `restaurante_id` | UUID | NO | - | FK a restaurantes |
| `nombre` | VARCHAR(50) | NO | - | Nombre de la categoría |
| `descripcion` | TEXT | SI | - | Descripción opcional de la categoría |
| `posicion` | INTEGER | NO | 0 | Orden de visualización en el menú |
| `activa` | BOOLEAN | NO | TRUE | Estado de la categoría |
| `creado_en` | TIMESTAMP WITH TIME ZONE | NO | CURRENT_TIMESTAMP | Fecha de creación |
| `actualizado_en` | TIMESTAMP WITH TIME ZONE | NO | CURRENT_TIMESTAMP | Fecha de última actualización |

**Constraints:**
- `PRIMARY KEY`: id
- `FOREIGN KEY`: restaurante_id → restaurantes(id) ON DELETE CASCADE
- `CHECK`: nombre entre 2 y 50 caracteres
- `CHECK`: posicion >= 0

**Índices:**
- `idx_categorias_restaurante_id`: restaurante_id
- `idx_categorias_posicion`: restaurante_id, posicion
- `idx_categorias_activa`: activa (WHERE activa = TRUE)

---

### 1.4. Tabla: `platos`

**Descripción:** Platos/productos del menú con información completa y soporte para soft delete.

| Campo | Tipo | Nulo | Defecto | Descripción |
|-------|------|------|---------|-------------|
| `id` | UUID | NO | gen_random_uuid() | Identificador único del plato |
| `categoria_id` | UUID | NO | - | FK a categorias |
| `nombre` | VARCHAR(100) | NO | - | Nombre del plato |
| `descripcion` | TEXT | SI | - | Descripción del plato (max 300 chars) |
| `precio` | DECIMAL(10,2) | NO | - | Precio regular del plato |
| `precio_oferta` | DECIMAL(10,2) | SI | - | Precio de oferta (debe ser menor al precio regular) |
| `imagen_url` | VARCHAR(500) | SI | - | URL de la imagen del plato |
| `disponible` | BOOLEAN | NO | TRUE | Disponibilidad del plato |
| `destacado` | BOOLEAN | NO | FALSE | Si el plato está destacado en el menú |
| `etiquetas` | TEXT[] | NO | {} | Array de etiquetas (vegetariano, vegano, sin_gluten, etc.) |
| `posicion` | INTEGER | NO | 0 | Orden de visualización dentro de la categoría |
| `creado_en` | TIMESTAMP WITH TIME ZONE | NO | CURRENT_TIMESTAMP | Fecha de creación |
| `actualizado_en` | TIMESTAMP WITH TIME ZONE | NO | CURRENT_TIMESTAMP | Fecha de última actualización |
| `eliminado_en` | TIMESTAMP WITH TIME ZONE | SI | - | Timestamp de soft delete (NULL si no está eliminado) |

**Constraints:**
- `PRIMARY KEY`: id
- `FOREIGN KEY`: categoria_id → categorias(id) ON DELETE CASCADE
- `CHECK`: nombre entre 2 y 100 caracteres
- `CHECK`: descripcion máximo 300 caracteres
- `CHECK`: precio > 0
- `CHECK`: precio_oferta < precio (si existe)
- `CHECK`: posicion >= 0

**Índices:**
- `idx_platos_categoria_id`: categoria_id
- `idx_platos_disponible`: disponible (WHERE disponible = TRUE)
- `idx_platos_destacado`: destacado (WHERE destacado = TRUE)
- `idx_platos_posicion`: categoria_id, posicion
- `idx_platos_no_eliminados`: eliminado_en (WHERE eliminado_en IS NULL)
- `idx_platos_etiquetas`: etiquetas (GIN index)

**Etiquetas comunes:**
- vegetariano
- vegano
- sin_gluten
- picante
- nuevo
- popular

---

### 1.5. Tabla: `imagenes`

**Descripción:** Referencias a imágenes procesadas en Object Storage. Soporta logos de restaurante e imágenes de platos con múltiples tamaños.

| Campo | Tipo | Nulo | Defecto | Descripción |
|-------|------|------|---------|-------------|
| `id` | UUID | NO | gen_random_uuid() | Identificador único de la imagen |
| `restaurante_id` | UUID | NO | - | FK a restaurantes (propietario de la imagen) |
| `plato_id` | UUID | SI | - | FK a platos (NULL si es logo de restaurante) |
| `tipo` | VARCHAR(20) | NO | - | Tipo: 'logo_restaurante' o 'imagen_plato' |
| `nombre_original` | VARCHAR(255) | NO | - | Nombre original del archivo |
| `url_thumbnail` | VARCHAR(500) | NO | - | URL de imagen tamaño thumbnail (150x150) |
| `url_medium` | VARCHAR(500) | NO | - | URL de imagen tamaño medium (400x400) |
| `url_large` | VARCHAR(500) | NO | - | URL de imagen tamaño large (800x800) |
| `tipo_mime` | VARCHAR(50) | NO | - | Tipo MIME: image/jpeg, image/png, image/webp |
| `tamanio_bytes` | INTEGER | NO | - | Tamaño del archivo original en bytes |
| `creado_en` | TIMESTAMP WITH TIME ZONE | NO | CURRENT_TIMESTAMP | Fecha de creación |

**Constraints:**
- `PRIMARY KEY`: id
- `FOREIGN KEY`: restaurante_id → restaurantes(id) ON DELETE CASCADE
- `FOREIGN KEY`: plato_id → platos(id) ON DELETE CASCADE
- `CHECK`: tamanio_bytes entre 1 y 5242880 (5MB máximo)
- `CHECK`: tipo_mime en ('image/jpeg', 'image/png', 'image/webp')
- `CHECK`: tipo en ('logo_restaurante', 'imagen_plato')
- `CHECK`: Si tipo='logo_restaurante' entonces plato_id IS NULL
- `CHECK`: Si tipo='imagen_plato' entonces plato_id IS NOT NULL

**Índices:**
- `idx_imagenes_restaurante_id`: restaurante_id
- `idx_imagenes_plato_id`: plato_id
- `idx_imagenes_tipo`: tipo
- `idx_imagenes_creado_en`: creado_en
- `idx_imagenes_logo_restaurante`: restaurante_id (WHERE tipo = 'logo_restaurante')

---

### 1.6. Tabla: `eventos_escaneo`

**Descripción:** Registra eventos de visualización del menú para análisis y métricas.

| Campo | Tipo | Nulo | Defecto | Descripción |
|-------|------|------|---------|-------------|
| `id` | UUID | NO | gen_random_uuid() | Identificador único del evento |
| `restaurante_id` | UUID | NO | - | FK a restaurantes |
| `timestamp` | TIMESTAMP WITH TIME ZONE | NO | CURRENT_TIMESTAMP | Fecha y hora del evento |
| `user_agent` | VARCHAR(500) | SI | - | User agent del navegador |
| `ip_hash` | VARCHAR(64) | SI | - | Hash anonimizado de la IP del cliente |
| `referrer` | VARCHAR(500) | SI | - | URL de referencia |

**Constraints:**
- `PRIMARY KEY`: id
- `FOREIGN KEY`: restaurante_id → restaurantes(id) ON DELETE CASCADE

**Índices:**
- `idx_eventos_restaurante_id`: restaurante_id
- `idx_eventos_timestamp`: timestamp
- `idx_eventos_restaurante_timestamp`: restaurante_id, timestamp

**Notas:**
- La IP se almacena hasheada por privacidad
- Útil para métricas de popularidad y horarios pico

---

### 1.7. Tabla: `tokens_refresh`

**Descripción:** Almacena tokens de refresh para renovación de JWT en el sistema de autenticación.

| Campo | Tipo | Nulo | Defecto | Descripción |
|-------|------|------|---------|-------------|
| `id` | UUID | NO | gen_random_uuid() | Identificador único del token |
| `usuario_id` | UUID | NO | - | FK a usuarios |
| `token_hash` | VARCHAR(255) | NO | - | Hash del token de refresh |
| `expira_en` | TIMESTAMP WITH TIME ZONE | NO | - | Fecha de expiración del token |
| `creado_en` | TIMESTAMP WITH TIME ZONE | NO | CURRENT_TIMESTAMP | Fecha de creación |
| `revocado` | BOOLEAN | NO | FALSE | Indica si el token fue revocado |

**Constraints:**
- `PRIMARY KEY`: id
- `FOREIGN KEY`: usuario_id → usuarios(id) ON DELETE CASCADE
- `UNIQUE`: token_hash

**Índices:**
- `idx_tokens_usuario_id`: usuario_id
- `idx_tokens_expira_en`: expira_en
- `idx_tokens_no_revocados`: revocado (WHERE revocado = FALSE)

---

## 2. MODELO DE DATOS

### 2.1. Diagrama de Relaciones

```
usuarios (1) ──────< (N) restaurantes
                           │
                           ├──< (N) categorias
                           │         │
                           │         └──< (N) platos
                           │                   │
                           ├───────────────────┘
                           │                   │
                           ├──< (N) imagenes ──┤
                           │
                           └──< (N) eventos_escaneo

usuarios (1) ──────< (N) tokens_refresh
```

### 2.2. Relaciones Detalladas

#### 2.2.1. Usuario → Restaurante
- **Cardinalidad:** 1:N
- **Tipo:** Propietario
- **Eliminación:** CASCADE (eliminar usuario elimina sus restaurantes)

#### 2.2.2. Restaurante → Categoría
- **Cardinalidad:** 1:N
- **Tipo:** Composición
- **Eliminación:** CASCADE
- **Ordenamiento:** Por campo `posicion`

#### 2.2.3. Categoría → Plato
- **Cardinalidad:** 1:N
- **Tipo:** Composición
- **Eliminación:** CASCADE (soft delete en platos)
- **Ordenamiento:** Por campo `posicion`

#### 2.2.4. Restaurante → Imagen
- **Cardinalidad:** 1:N
- **Tipo:** Asociación
- **Eliminación:** CASCADE
- **Nota:** Una imagen puede ser logo (plato_id NULL) o imagen de plato (plato_id NOT NULL)

#### 2.2.5. Plato → Imagen
- **Cardinalidad:** 1:N
- **Tipo:** Asociación opcional
- **Eliminación:** CASCADE
- **Nota:** Solo cuando tipo='imagen_plato'

#### 2.2.6. Restaurante → Evento Escaneo
- **Cardinalidad:** 1:N
- **Tipo:** Logs/Analytics
- **Eliminación:** CASCADE

#### 2.2.7. Usuario → Token Refresh
- **Cardinalidad:** 1:N
- **Tipo:** Autenticación
- **Eliminación:** CASCADE

---

## 3. FUNCIONES Y TRIGGERS

### 3.1. Función: `update_actualizado_en()`

**Propósito:** Actualizar automáticamente el campo `actualizado_en` en cada UPDATE.

**Lenguaje:** PL/pgSQL

**Tablas que la usan:**
- usuarios
- restaurantes
- categorias
- platos

**Implementación:**
```sql
CREATE OR REPLACE FUNCTION update_actualizado_en()
RETURNS TRIGGER AS $$
BEGIN
    NEW.actualizado_en = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
```

---

### 3.2. Función: `generar_slug(nombre TEXT)`

**Propósito:** Generar un slug único URL-friendly desde un nombre.

**Transformaciones:**
1. Convertir a minúsculas
2. Reemplazar caracteres acentuados por equivalentes sin acento
3. Eliminar caracteres especiales (solo permitir a-z, 0-9, -)
4. Reemplazar espacios por guiones
5. Eliminar guiones duplicados
6. Verificar unicidad (agregar sufijo numérico si es necesario)

**Lenguaje:** PL/pgSQL

**Ejemplo:**
- Input: "La Trattoria Italiana"
- Output: "la-trattoria-italiana"
- Si existe: "la-trattoria-italiana-1"

---

### 3.3. Función: `trigger_generar_slug()`

**Propósito:** Generar automáticamente el slug si no se proporciona en INSERT.

**Tabla:** restaurantes

**Lenguaje:** PL/pgSQL

---

### 3.4. Triggers Activos

| Trigger | Tabla | Evento | Función | Descripción |
|---------|-------|--------|---------|-------------|
| `trigger_usuarios_actualizado_en` | usuarios | BEFORE UPDATE | update_actualizado_en() | Actualiza timestamp |
| `trigger_restaurantes_actualizado_en` | restaurantes | BEFORE UPDATE | update_actualizado_en() | Actualiza timestamp |
| `trigger_categorias_actualizado_en` | categorias | BEFORE UPDATE | update_actualizado_en() | Actualiza timestamp |
| `trigger_platos_actualizado_en` | platos | BEFORE UPDATE | update_actualizado_en() | Actualiza timestamp |
| `trigger_restaurantes_slug` | restaurantes | BEFORE INSERT | trigger_generar_slug() | Genera slug automático |

---

## 4. VISTAS

### 4.1. Vista: `v_menu_completo`

**Propósito:** Obtener el menú completo de un restaurante con todas sus categorías y platos en un solo query.

**Uso:** Cache de menú para visualización pública.

**Filtros aplicados:**
- Solo restaurantes activos
- Solo categorías activas
- Solo platos disponibles
- Solo platos no eliminados (soft delete)

**Ordenamiento:**
- Por restaurante
- Por posición de categoría
- Por posición de plato

**Campos:**
```
restaurante_id, restaurante_nombre, slug, restaurante_descripcion,
logo_url, telefono, direccion, horarios,
categoria_id, categoria_nombre, categoria_descripcion, categoria_posicion,
plato_id, plato_nombre, plato_descripcion, precio, precio_oferta,
plato_imagen_url, disponible, destacado, etiquetas, plato_posicion
```

**Ejemplo de consulta:**
```sql
SELECT * FROM v_menu_completo WHERE slug = 'la-trattoria';
```

---

### 4.2. Vista: `v_analytics_resumen`

**Propósito:** Métricas resumidas de visualizaciones por restaurante.

**Agregaciones:**
- Total de escaneos (histórico)
- Escaneos hoy
- Escaneos últimos 7 días
- Escaneos últimos 30 días
- Primer escaneo (fecha)
- Último escaneo (fecha)

**Agrupamiento:** Por restaurante_id

**Ejemplo de consulta:**
```sql
SELECT * FROM v_analytics_resumen WHERE restaurante_id = 'uuid...';
```

---

### 4.3. Vista: `v_analytics_por_hora`

**Propósito:** Distribución de visualizaciones por hora del día (últimos 30 días).

**Datos:**
- restaurante_id
- hora (0-23)
- cantidad de escaneos

**Uso:** Identificar horarios pico de visualización.

**Ejemplo de consulta:**
```sql
SELECT * FROM v_analytics_por_hora 
WHERE restaurante_id = 'uuid...' 
ORDER BY hora;
```

---

## 5. ROLES Y PERMISOS

### 5.1. Rol: `anon`

**Tipo:** NOLOGIN (usado por PostgREST)

**Permisos:**
- USAGE en schema public
- SELECT en todas las tablas
- SELECT en vistas

**Propósito:** Acceso público de solo lectura para visualización de menús.

---

## 6. CARACTERÍSTICAS ESPECIALES

### 6.1. Soft Delete (Platos)

Los platos no se eliminan físicamente, se marcan con timestamp en `eliminado_en`.

**Ventajas:**
- Historial completo
- Recuperación posible
- Análisis de platos descontinuados

**Implementación:**
```sql
-- Eliminar (soft delete)
UPDATE platos SET eliminado_en = NOW() WHERE id = 'uuid...';

-- Restaurar
UPDATE platos SET eliminado_en = NULL WHERE id = 'uuid...';
```

### 6.2. JSONB para Horarios

Horarios flexibles almacenados en formato JSONB para fácil consulta y actualización.

**Ventajas:**
- Estructura flexible
- Indexable (GIN index opcional)
- Fácil serialización/deserialización

### 6.3. Arrays para Etiquetas

Etiquetas de platos en array TEXT[] con índice GIN para búsquedas eficientes.

**Ejemplo:**
```sql
-- Buscar platos vegetarianos
SELECT * FROM platos WHERE 'vegetariano' = ANY(etiquetas);
```

### 6.4. Generación Automática de Slugs

Los slugs se generan automáticamente desde el nombre del restaurante mediante trigger.

**Características:**
- URL-friendly
- Único (sufijo numérico si hay colisión)
- Sin acentos ni caracteres especiales

### 6.5. Versionado de Imágenes

Cada imagen se procesa en 3 tamaños para optimizar carga:
- Thumbnail: 150x150 (listados)
- Medium: 400x400 (vista de menú)
- Large: 800x800 (vista detallada)

---

## 7. ÍNDICES PARA PERFORMANCE

### 7.1. Índices por Tabla

**usuarios:**
- Búsqueda por email (login)
- Filtro de usuarios activos

**restaurantes:**
- Lookup por slug (URL pública)
- Búsqueda por usuario
- Filtro de restaurantes activos

**categorias:**
- Lookup por restaurante
- Ordenamiento por posición
- Filtro de categorías activas

**platos:**
- Lookup por categoría
- Filtro de disponibles/destacados
- Ordenamiento por posición
- Búsqueda en etiquetas (GIN)
- Filtro de no eliminados

**imagenes:**
- Lookup por restaurante
- Lookup por plato
- Filtro por tipo
- Lookup específico de logos

**eventos_escaneo:**
- Agrupación por restaurante
- Filtros por rango de fechas
- Queries de analytics

**tokens_refresh:**
- Lookup por usuario
- Limpieza de tokens expirados
- Filtro de tokens válidos

---

## 8. CONSIDERACIONES DE SEGURIDAD

### 8.1. Passwords
- Almacenados con bcrypt (hash unidireccional)
- Campo: `password_hash`

### 8.2. Tokens
- Refresh tokens hasheados antes de almacenar
- Expiracion configurable
- Soporte para revocación

### 8.3. IPs
- Hasheadas para anonimizar analytics
- No se almacenan IPs en texto plano

### 8.4. Acceso Público
- Rol `anon` solo tiene permisos de lectura
- Sin acceso a datos sensibles (passwords, tokens)

---

## 9. MANTENIMIENTO

### 9.1. Limpieza de Eventos Antiguos

Ejecutar periódicamente para mantener tamaño de tabla:
```sql
DELETE FROM eventos_escaneo 
WHERE timestamp < CURRENT_DATE - INTERVAL '1 year';
```

### 9.2. Limpieza de Tokens Expirados

```sql
DELETE FROM tokens_refresh 
WHERE expira_en < CURRENT_TIMESTAMP OR revocado = TRUE;
```

### 9.3. Análisis de Platos Eliminados

```sql
SELECT COUNT(*) FROM platos WHERE eliminado_en IS NOT NULL;
```

---

## 10. EXTENSIONES FUTURAS

### 10.1. Búsqueda de Texto Completo (pg_trgm)

Descomentar en el script para habilitar:
```sql
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE INDEX idx_platos_nombre_trgm ON platos USING GIN (nombre gin_trgm_ops);
```

### 10.2. Particionamiento de Eventos

Para alto volumen de tráfico, considerar particionamiento por fecha de `eventos_escaneo`.

### 10.3. Tabla de Reservas

Extensión futura para gestión de reservas en línea.

### 10.4. Sistema de Reviews

Tabla adicional para reseñas y calificaciones de platos.

---

## 11. INTEGRACIÓN CON POSTGREST

### 11.1. Endpoints Automáticos

PostgREST genera automáticamente endpoints REST para todas las tablas y vistas:

**Tablas:**
- GET/POST/PATCH/DELETE `/usuarios`
- GET/POST/PATCH/DELETE `/restaurantes`
- GET/POST/PATCH/DELETE `/categorias`
- GET/POST/PATCH/DELETE `/platos`
- GET/POST/PATCH/DELETE `/imagenes`
- GET/POST/PATCH/DELETE `/eventos_escaneo`
- GET/POST/PATCH/DELETE `/tokens_refresh`

**Vistas:**
- GET `/v_menu_completo`
- GET `/v_analytics_resumen`
- GET `/v_analytics_por_hora`

### 11.2. Ejemplos de Queries

**Obtener menú por slug:**
```
GET /v_menu_completo?slug=eq.la-trattoria
```

**Platos vegetarianos disponibles:**
```
GET /platos?etiquetas=cs.{vegetariano}&disponible=eq.true
```

**Analytics de un restaurante:**
```
GET /v_analytics_resumen?restaurante_id=eq.uuid...
```

---

**Documento generado:** 24 de enero de 2026  
**Versión del esquema:** 1.0
